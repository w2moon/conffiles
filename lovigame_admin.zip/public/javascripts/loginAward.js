

$(document).ready(function(){
	(function(){
		
		var table = document.getElementById("tableBox");
		$("#modify .add").click(function(){
			var day= table.querySelectorAll("tr:not(.th)").length+1;//获取所有记录
			var oTr=document.createElement("tr");
			for (var i = 0; i < 4; i++) {
				var otd=document.createElement("td");
				var html;
				switch(i){
					case 0:
						html="第"+day+"天";
					break;
					case 1:
						html='<div><p class="itemlisth"><span class="l">物品ID</span><span class="r">数量</span>'+
						'</p><p class="itemlistd"><span class="l"></span><span class="r"></span></p>'+
						'</div><input class="payPre" type="button" name="" value="添加/修改">';
					break;
					case 2:
						html='<div><p class="itemlisth"><span class="l">物品ID</span><span class="r">数量</span>'+
						'</p><p class="itemlistd"><span class="l"></span><span class="r"></span></p>'+
						'</div><input class="payAft" type="button" name="" value="添加/修改">';
					break;
					case 3:
						html='<select>'+
	                    '<option value="1">是</option>'+
	                    '<option value="0">否</option>'+
	                  	'</select>'
					break;
				}
				otd.innerHTML=html;
				oTr.appendChild(otd);
			}
			oTr.className=day;
			table.appendChild(oTr);
		})
		$("#modify .remove").click(function(){
			var flog=confirm("确定删除最后一天吗？");
				if (flog){
					var id=$("#tableBox tr:last").attr("class");
					var data={
						id:id
					}
					$.ajax({
					type:'POST',
					url:'loginAward/remove',
					data:data,
					success:function(result){
						if (result){
							alert("删除成功");
							$("#tableBox tr:last").remove();
						}else{
							alert("修改失败");
						}
					}
				})
					
				}
		})

		$(document).on("click","input.payPre",function(){
			document.getElementById("updateTable").innerHTML='<caption id="upCap" style="margin-bottom: 10px;font-size: 18px;"></caption>'+
         	'<tr class="upTh"><th>物品ID</th><th>数量</th><th><span>删除</span></th></tr>';
			$("#screenBox").css("display","block");
			var upTab=document.getElementById("updateTable");
			var thisTr=this.parentNode.parentNode;
			var dayTxt=thisTr.children[0].innerHTML;
			var tab=thisTr.children[1].children[0].children;
			$("#updateTable").attr("class",thisTr.className);
			$("#prompt").attr("class",thisTr.children[3].children[0].value);
			$("#updateTable caption").attr("class",this.className);
			$("#updateTable caption").html(dayTxt+"(未充值奖励)");
			for (var i = 1; i < tab.length; i++) {
				var otr=document.createElement("tr");
				console.log(tab[i]);
				console.log(tab[i].children[0].innerHTML);
				for (var j = 0; j < 3; j++) {
					var otd=document.createElement("td");
					var html;
					switch(j){
						case 0:
							html=tab[i].children[0].innerHTML;
						break;
						case 1:
							html=tab[i].children[1].innerHTML;
						break;
						case 2:
							html="<span>删除</span>";
							otd.className="del";
						break;
					}
					otd.innerHTML=html;
					otr.appendChild(otd);
				}
				upTab.appendChild(otr);
			}

		})

		
		$(document).on("click","input.payAft",function(){
			document.getElementById("updateTable").innerHTML='<caption id="upCap" style="margin-bottom: 10px;font-size: 18px;"></caption>'+
          	'<tr class="upTh"><th>物品ID</th><th>数量</th><th><span>删除</span></th></tr>';
			$("#screenBox").css("display","block");
			var upTab=document.getElementById("updateTable");
			var thisTr=this.parentNode.parentNode;
			var dayTxt=thisTr.children[0].innerHTML;
			var tab=thisTr.children[2].children[0].children;
			$("#updateTable").attr("class",thisTr.className);
			$("#prompt").attr("class",thisTr.children[3].children[0].value);
			$("#updateTable caption").attr("class",this.className);
			$("#updateTable caption").html(dayTxt+"(充值后奖励)");
			for (var i = 1; i < tab.length; i++) {
				var otr=document.createElement("tr");
				console.log(tab[i]);
				console.log(tab[i].children[0].innerHTML);
				for (var j = 0; j < 3; j++) {
					var otd=document.createElement("td");
					var html;
					switch(j){
						case 0:
							html=tab[i].children[0].innerHTML;
						break;
						case 1:
							html=tab[i].children[1].innerHTML;
						break;
						case 2:
							html="<span>删除</span>";
							otd.className="del";
						break;
					}
					otd.innerHTML=html;
					otr.appendChild(otd);
				}
				upTab.appendChild(otr);
			}
		})

		$("#edit").click(function(){
			var upTab_tr=$("#updateTable tr");
			$("#updateTable tr:not(:first) td:not(.del)").attr("contenteditable","true");
		})
		$("#addUp").click(function(){
			var upTab=document.getElementById("updateTable");
			var oTr=document.createElement("tr");
			for (var i = 0; i < 3; i++) {
				var otd=document.createElement("td");
				var html;
				switch(i){
					case 0:
						html='';
					break;
					case 1:
						html='';
					break;
					case 2:
						html='<span>删除</span>';
						otd.className="del";
					break;
				}
				otd.innerHTML=html;
				oTr.appendChild(otd);
			}
			upTab.appendChild(oTr);
			$("#updateTable tr td.del").css("cursor","pointer");
			$("#updateTable tr:not(:first) td:not(.del)").attr("contenteditable","true");

		})

		$(document).on("click","td.del",function(){
			if(confirm("确定删除吗？")){
				this.parentNode.remove(this);
			}
		})

		$("#preUp").click(function(){
			var upTable=document.getElementById("updateTable");
			var payIf=document.getElementById("upCap").className;
			var oTr=upTable.querySelectorAll("tr:not(.upTh)");
			var id=upTable.className;
			var prompt=document.getElementById("prompt").className;
			var gifList=[];
			$("#screenBox").css("display","none");
			console.log(id+"  "+payIf)
			if(id && payIf){
				for (var i = 0; i < oTr.length; i++) {
					var obj={
						gifId:oTr[i].children[0].innerHTML,
						gifNum:oTr[i].children[1].innerHTML
					}
					gifList.push(obj);
				}
				gifStr=JSON.stringify(gifList);
				var data={
					id:id,
					payIf:payIf,
					gifList:gifStr,
					payPrompt:prompt
				}
				console.log("data",data);
				$.ajax({
					type:'POST',
					url:'loginAward/save',
					data:data,
					success:function(result){
						if (result){
							alert("修改成功");
							window.location.reload();
						}else{
							alert("修改失败");
						}
					}
				})
			}else{
				alert("操作失败");
			}
		})

		$(document).on("change","td select",function(){
			var day=this.parentNode.parentNode.className;
			var payPrompt=this.value;
				if(day){
					var data={
						id:day,
						payPrompt:payPrompt
					}
					$.ajax({
					type:'POST',
					url:'loginAward/pt',
					data:data,
					success:function(result){
						if (result){
							alert("修改成功");
							window.location.reload();
						}else{
							alert("修改失败");
						}
					}
				})
				}else{
					alert("修改失败");
				}
		})

	})()
	
})