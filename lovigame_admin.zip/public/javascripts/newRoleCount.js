$(document).ready(function(){
	(function(){
		$("#search").bind("click",function(){
			var vn=$("#vn").val();
			var startDate=$("#startDate").val();
			var endDate=$("#endDate").val();
			if(!startDate){
				alert("请输入开始时间");
			}else if(!endDate){
				alert("请输入结束时间")
			}else if(startDate>endDate){
				alert("开始时间不能大于结束时间");
			}else{
				var startTime=new Date(startDate).getTime()-28800000;
				var endTime=new Date(endDate).getTime()+57599999;
				var platform=vn?vn:null;
				$.ajax({
					type:"POST",
					url:"/newRoleCount",
					data:{
						startTime:startTime,
						endTime:endTime,
						platform:platform
					},
					success:function(data){
						console.log(data);
						if(data){
							var arr=[];
							var hash={};
							var date=[];
							var index=0;
							for (var i = 0; i < data.length; i++) {
								var dataTime=getLocalTime(new Date(data[i].time));
								if(hash[dataTime]){
									hash[dataTime]++;
								}else{
									hash[dataTime]=1;
								}
							}

							for (var t = startTime; t < endTime; t+=86400000) {
								var times=getLocalTime(new Date(t));
									date[index]=times;
									index++;

							}
							for (var i = 0; i < date.length; i++) {
								arr[i]=new Array();
								if(hash[date[i]]){
									arr[i][0]="";
									arr[i][1]=hash[date[i]];
								}else{
									arr[i][0]="";
									arr[i][1]=0;
								}
							}


							if(arr.length<=10){
								for (var i = 0; i < arr.length; i++) {
									arr[i][0]=date[i];
								}
							}else{
								arr[0][0]=date[0];
								arr[arr.length-1][0]=date[arr.length-1];
							}
							var logTable = new JSChart('graph', 'line');
							logTable.setDataArray(arr);
							logTable.setTitle('New role statistics');
							logTable.setTitleColor('#8E8E8E');
							logTable.setTitleFontSize(18);
							logTable.setAxisNameX('Time');
							logTable.setAxisNameY('New Roles');
							logTable.setAxisNameColor('#8E8E8E')
							logTable.setAxisColor('#000');
							logTable.setAxisValuesColor('#f00');
							logTable.setAxisPaddingLeft(60);
							logTable.setAxisPaddingRight(80);
							logTable.setAxisPaddingTop(60);
							logTable.setAxisPaddingBottom(50);
							logTable.setAxisValuesDecimals(0);
							logTable.setAxisValuesNumberX(20);//x轴点的距离
							logTable.setShowXValues(false);
							logTable.setGridColor('#C5A2DE');
							logTable.setLineColor('#9D12FD');//线的颜色
							logTable.setLineWidth(2);
							logTable.setFlagColor('#9D12FD');//圈的颜色
							logTable.setFlagRadius(0.5);
							// logTable.setLabelRotationAngle(20);
							logTable.setTooltipOffset(5)
							for (var i = 0; i < arr.length; i++) {
								logTable.setTooltip([arr[i][0],date[i]+" 新增 "+arr[i][1]+" 人"]);
							}
							logTable.setSize(1100, 700);
							logTable.draw();
						}
					}
				})
			}
		})

		function toTwo(num){
        	return num<10?"0"+num:num;
    		}
		function getLocalTime(date) {     
       			return date.getFullYear()+"-"+toTwo(date.getMonth()+1)+"-"+toTwo(date.getDate());     
    		}
	})()
})