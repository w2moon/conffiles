$(document).ready(function(){
	(function(){
		var table = document.getElementById("table"),
			totalPage = document.getElementById("spanTotalPage"),//总页数
			pageNum = document.getElementById("spanPageNum"), //获取当前页<span> 
			spanPre = document.getElementById("spanPre"),//获取上一页<span> 
			spanNext = document.getElementById("spanNext"),//获取下一页<span> 
			numberRowsInTable = table.querySelectorAll("tr"),//获取所有记录
			length= numberRowsInTable.length,//记录总条数
		 	pageSize = 10, //每页显示的记录条数 
		 	currentRow,
		 	maxRow,
			page = 1; //当前页，默认第一页 
			spanPre.onclick=pre;
			spanNext.onclick=next;
		function next(){
			if(page<pageCount()){
				hideTable();
				currentRow=page*pageSize;
				maxRow=currentRow+pageSize;
				if (maxRow>length) maxRow=length;
				for (var i = currentRow; i < maxRow; i++) {
					numberRowsInTable[i].style.display="";
				}
				page++;
				if (page==pageCount()) {
					nextText();
				}
			}
		
			prelLink();
			showPage();
		}
		function pre(){
			if(page>1){
				hideTable();
				page--;
				maxRow=page*pageSize;
				currentRow=maxRow-pageSize;
				if (currentRow<0) currentRow=0;
				for (var i = currentRow; i < maxRow; i++) {
					numberRowsInTable[i].style.display="";
				}
				if (currentRow==0) {
					preText();
				}
			}
		
				nextLink();
				showPage();
		
		
		}
		function prelLink(){
			spanPre.className="btn";
		}
		function preText(){
			spanPre.className="btn on";
		}
		function nextLink(){
			spanNext.className="btn";
		}
		function nextText(){
			spanNext.className="btn on";
		}
		function pageCount(){
			return Math.ceil(length/pageSize);
		}
		function hideTable(){
			for (var i = 0; i < length; i++) {
				numberRowsInTable[i].style.display="none";
			}
		}
		function showPage(){
			pageNum.innerHTML=page;
		}
		function hide(){
			for (var i = pageSize; i < length; i++){
				numberRowsInTable[i].style.display="none";
			}
			pageNum.innerHTML=1;
			totalPage.innerHTML=pageCount();
			preText();
		}
		hide();


	 $("#submit").bind("click", function () {
	 			var codeNum=$("#codenum").val();
	 			var resId=$("#resid").val();
	 			if (resId=="") {
	 				alert("请输入物品ID");
	 			}else if (codeNum=="") {
	 				alert("请输入兑换码数量");
	 			}else if(isNaN(codeNum)){
	 				alert("输入不合法");
	 			}else{
	 				$.ajax({
				    type: 'POST',
				    url: '/createCode',
				    data: 'codeNum='+codeNum+'&resId='+resId,
				    // contentType: 'application/json',
				    dataType: 'json',
					success:function(data){
						var table=document.getElementById("table");
						var tr=document.createElement("tr");
						var td1=document.createElement("td");
						var td2=document.createElement("td");
						var td3=document.createElement("td");
							td1.innerHTML=data.nowDate;
							tr.appendChild(td1);
							td2.innerHTML=data.resNum;
							tr.appendChild(td2);
							td3.className=data.result["id"];
							td3.innerHTML="下载";
							tr.appendChild(td3);
							table.insertBefore(tr,table.firstChild);
						numberRowsInTable = table.querySelectorAll("tr"),//获取所有记录
						length= numberRowsInTable.length,//记录总条数
							hide();
							downAjax(data.result["id"]);
							download();
							// splitStr(data.path,function(file){
							// 	downloadFile(file.fileName,file.dir);
							// });
					}
			});
	 	}
             
     });
    		download();
    		function download(){
    			var otd=document.querySelectorAll("#table tr td:last-child");
    				for (var i = 0; i < otd.length; i++) {
    					otd[i].onclick=function(){
    						downAjax(this.className);
    					}
    				}
    		}

    		function downAjax(name){
    			$.ajax({
    				type: 'GET',
				    url: '/downfile',
				    data: 'name='+name,
				    success:function(){
				    	 window.open("downfile?name="+name+"");
				    }
    			})
    			
    		}

    		
	})()
})