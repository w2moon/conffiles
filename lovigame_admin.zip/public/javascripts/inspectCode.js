$(document).ready(function(){
	(function(){
		var table = document.getElementById("table"),
			totalPage = document.getElementById("spanTotalPage"),//总页数
			pageNum = document.getElementById("spanPageNum"), //获取当前页<span> 
			spanPre = document.getElementById("spanPre"),//获取上一页<span> 
			spanNext = document.getElementById("spanNext"),//获取下一页<span> 
			numberRowsInTable = table.querySelectorAll("tr"),//获取所有记录
			length= numberRowsInTable.length,//记录总条数
		 	pageSize = 9, //每页显示的记录条数 
		 	currentRow,
		 	maxRow,
			page = 1; //当前页，默认第一页 
			spanPre.onclick=pre;
			spanNext.onclick=next;
		function next(){
			if(page<pageCount()){
				hideTable();
				currentRow=page*pageSize;
				maxRow=currentRow+pageSize;
				if (maxRow>length) maxRow=length;
				for (var i = currentRow; i < maxRow; ++i) {
					numberRowsInTable[i].style.display="";
				}
				page++;
				if (page==pageCount()) {
					nextText();
				}
			}
		
			prelLink();
			showPage();
		}
		function pre(){
			if(page>1){
				hideTable();
				page--;
				maxRow=page*pageSize;
				currentRow=maxRow-pageSize;
				if (currentRow<0) currentRow=0;
				for (var i = currentRow; i < maxRow; i++) {
					numberRowsInTable[i].style.display="";
				}
				if (currentRow==0) {
					preText();
				}
			}
		
				nextLink();
				showPage();
		
		
		}
		function prelLink(){
			spanPre.className="btn";
		}
		function preText(){
			spanPre.className="btn on";
		}
		function nextLink(){
			spanNext.className="btn";
		}
		function nextText(){
			spanNext.className="btn on";
		}
		function pageCount(){
			return Math.ceil(length/pageSize);
		}
		function hideTable(){
			for (var i = 0; i < length; i++) {
				numberRowsInTable[i].style.display="none";
			}
		}
		function showPage(){
			pageNum.innerHTML=page;
		}
		function hide(){
			for (var i = pageSize; i < length; i++){
				numberRowsInTable[i].style.display="none";
			}
			pageNum.innerHTML=1;
			totalPage.innerHTML=pageCount();
			preText();
		}
		hide();
		var index;
		function check(){
			for (var i = 0; i < length; i++) {
				numberRowsInTable[i].index=i;
				numberRowsInTable[i].onclick=function(){
					index=this.index;
					for (var i = 0; i <length; i++) {
						numberRowsInTable[i].style.backgroundColor="#9faaae";
					}
					this.style.backgroundColor="#dbdfe1";
				}
			}
		}
		check();
		function removeNineBorder(){
			var oTr=document.querySelectorAll("#table tbody tr"),
				nineTr=[],
				j=0;
			for (var i = 0; i < oTr.length; i++) {
				if (((i+1)%9)==0) {
					oTr[i].style.border="none";
				}
				
			}
		}
		removeNineBorder();
		search();
		function search(){
			var searchBtn=$("#searchBtn");
			searchBtn.click(function(){
			var searchKey=$("#searchKey").val();
			 if (searchKey=="") {
			 	alert("请输入要查询兑换码");
			 } else {
			 	$.ajax({
			 		type:"POST",
			 		url:'/inspectCode',
			 		data:'key='+searchKey,
			 		success:function(data){
						var td1=document.getElementById("td1");
						var td2=document.getElementById("td2");
						var td3=document.getElementById("td3"); 
						td1.innerHTML=data.status;
						td2.innerHTML=data.user;
						td3.innerHTML=data.address;
			 		}
			 	})
			 }
			})
		}
	})()

})