$(document).ready(function(){
	(function(){
		
		$("#button").bind("click",function(){
			var time=$("#time").val();
			var days=$("#days").val();
			if (!time){
				alert("请输入时间");
			}else if(!days){
				alert("请输入天数");
			}else{
				var dateTime=new Date(time).getTime();
				$.ajax({
					type:"POST",
					url:"/loginSituation",
					data:"dateTime="+dateTime+"&days="+days,
					success:function(result){
						if (result){
							var percent=(result.percent*100).toFixed(2)+"%";
							$("#searchBox .search .percent .p .tt").val(getLocalTime(new Date(time)));
							$("#searchBox .search .percent .p .dd").val(days);
							$("#percent").val(percent);
						}else{
							$("#percent").val("0");
						}
					}
				})

			}
		})

		function toTwo(num){
        	return num<10?"0"+num:num;
    		}
		function getLocalTime(date) {     
	   			return date.getFullYear()+"-"+toTwo(date.getMonth()+1)+"-"+toTwo(date.getDate());     
			}


	})()
})