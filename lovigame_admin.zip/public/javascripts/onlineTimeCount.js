$(document).ready(function(){
	(function(){
		$("#search").bind("click",function(){
			var vn=$("#vn").val();
			var startDate=$("#startDate").val();
			var endDate=$("#endDate").val();
			if(!startDate){
				alert("请输入开始时间");
			}else if(!endDate){
				alert("请输入结束时间")
			}else if(startDate>endDate){
				alert("开始时间不能大于结束时间");
			}else{
				var startTime=new Date(startDate).getTime()-28800000;
				var endTime=new Date(endDate).getTime()+57599999;
				var platform=vn?vn:null;
				$.ajax({
					type:"POST",
					url:"/onlineTimeCount",
					data:{
						startTime:startTime,
						endTime:endTime,
						platform:platform
					},
					success:function(data){
						if(data){
							var arr=[];
							var hash={};
							var dayCount={};
							var index=0;
							var totalDay=totalDays(startTime,endTime);
							for (var i = 0; i < data.length; i++) {
								hash[data[i].id]=totalDays(data[i].startLogin,data[i].endLogin).toString();
								console.log(totalDays(data[i].startLogin,data[i].endLogin).toString());
							}
							for(var atr in hash){
								if(dayCount[hash[atr]]){
									dayCount[hash[atr]]++;
								}else{
									dayCount[hash[atr]]=1;
								}
							}
							for (var i = 0; i < totalDay; i++) {
								arr[i]=new Array();
								var d=(i+1).toString();
								if(dayCount[d]){
									arr[i][0]="";
									arr[i][1]=dayCount[d];
								}else{
									arr[i][0]="";
									arr[i][1]=0;
								}
							}
							if(arr.length<=20){
								for (var j = 0; j < arr.length; j++) {
									arr[j][0]=(j+1)+" day";
								}
							}else{
								arr[0][0]="1 day";
								arr[arr.length-1][0]=arr.length+" day";
							}
							var logTable = new JSChart('graph', 'line');
							logTable.setDataArray(arr);
							logTable.setTitle('Login Time Statistics       people '+data.length+' 人');
							logTable.setTitleColor('#8E8E8E');
							logTable.setTitleFontSize(18);
							logTable.setAxisNameX('Number Of Days');
							logTable.setAxisNameY('Number Of People');
							logTable.setAxisNameColor('#8E8E8E')
							logTable.setAxisColor('#000');
							logTable.setAxisValuesColor('#f00');
							logTable.setAxisPaddingLeft(60);
							logTable.setAxisPaddingRight(80);
							logTable.setAxisPaddingTop(60);
							logTable.setAxisPaddingBottom(60);
							logTable.setAxisValuesDecimals(0);
							logTable.setAxisValuesNumberX(20);//x轴点的距离
							logTable.setShowXValues(false);
							logTable.setGridColor('#C5A2DE');
							logTable.setLineColor('#9D12FD');//线的颜色
							logTable.setLineWidth(2);
							logTable.setFlagColor('#9D12FD');//圈的颜色
							logTable.setFlagRadius(0.5);
							logTable.setTooltipOffset(5)
							for (var i = 0; i < arr.length; i++) {
								logTable.setTooltip([arr[i][0],"登录 "+(i+1)+" 天 "+arr[i][1]+" 人 所占比例"+((arr[i][1]/data.length)*100).toFixed(2)+"%"]);
							}
							logTable.setSize(1100, 700);
							logTable.draw();



						}
					}
				})
			}
		})

		function toTwo(num){
        	return num<10?"0"+num:num;
    		}
		function getLocalTime(date) {     
       		return date.getFullYear()+"-"+toTwo(date.getMonth()+1)+"-"+toTwo(date.getDate());     
    		}
    	function sortNumber(a,b){
    		return a-b;
    	}
    	function totalDays(start,end){
    		var days_min=getLocalTime(new Date(start));
			var days_max=getLocalTime(new Date(end));
			var d=((new Date(days_max).getTime()-new Date(days_min).getTime())/86400000)+1;
			return d;
    	}
	})()
})