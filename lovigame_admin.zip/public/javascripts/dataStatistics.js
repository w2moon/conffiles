$(document).ready(function(){
	(function(){

		var table = document.getElementById("table"),
			totalPage = document.getElementById("spanTotalPage"),//总页数
			pageNum = document.getElementById("spanPageNum"), //获取当前页<span> 
			spanPre = document.getElementById("spanPre"),//获取上一页<span> 
			spanNext = document.getElementById("spanNext"),//获取下一页<span> 
			numberRowsInTable = table.querySelectorAll("tr:not(.h)"),//获取所有记录
			length= numberRowsInTable.length,//记录总条数
		 	pageSize = 10, //每页显示的记录条数 
		 	currentRow,
		 	maxRow,
			page = 1; //当前页，默认第一页 
			spanPre.onclick=pre;
			spanNext.onclick=next;
		function next(){
			if(page<pageCount()){
				hideTable();
				currentRow=page*pageSize;
				maxRow=currentRow+pageSize;
				if (maxRow>length) maxRow=length;
				for (var i = currentRow; i < maxRow; i++) {
					numberRowsInTable[i].style.display="";
				}
				page++;
				if (page==pageCount()) {
					nextText();
				}else{
					nextLink();
				}
			}
		
			prelLink();
			showPage();
		}
		function pre(){
			if(page>1){
				hideTable();
				page--;
				maxRow=page*pageSize;
				currentRow=maxRow-pageSize;
				if (currentRow<0) currentRow=0;
				for (var i = currentRow; i < maxRow; i++) {
					numberRowsInTable[i].style.display="";
				}
				if (currentRow==0) {
					preText();
				}else{
					prelLink();
				}
			}
		
				nextLink();
				showPage();
		
		
		}
		function prelLink(){
			spanPre.className="btn";
		}
		function preText(){
			spanPre.className="btn on";
		}
		function nextLink(){
			spanNext.className="btn";
		}
		function nextText(){
			spanNext.className="btn on";
		}
		function pageCount(){
			return Math.ceil(length/pageSize);
		}
		function hideTable(){
			for (var i = 0; i < length; i++) {
				numberRowsInTable[i].style.display="none";
			}
		}
		function showPage(){
			pageNum.innerHTML=page;
		}
		function hide(){
			for (var i = pageSize; i < length; i++){
				numberRowsInTable[i].style.display="none";
			}
			pageNum.innerHTML=1;
			page=1;
			totalPage.innerHTML=pageCount();
			preText();
		}
		hide();

		$("#jump").bind("click",function(){
			var jumpPage=$("#jumpPage input").val();
			hideTable();
			var tot=pageCount();
			// page=jumpPage;
			jumpPage>tot?page=tot:page=jumpPage;
			currentRow=(page-1)*pageSize;
			maxRow=currentRow+pageSize;
			if (maxRow>length) maxRow=length;
			for (var i = currentRow; i < maxRow; i++) {
				numberRowsInTable[i].style.display="";
			}
			if (page==pageCount()) {
				nextText();
			}else{
				nextLink();
			}
			if (currentRow==0) {
				preText();
			}else{
				prelLink();
			}
			showPage();

		})



		


		$("#search").bind("click",function(){
			var vn=$("#vn").val();
			var startDate=$("#startDate").val();
			var endDate=$("#endDate").val();
			var selectVal=$("#selectBox").val();
			if(!startDate){
				alert("请输入开始时间");
			}else if(!endDate){
				alert("请输入结束时间")
			}else if(startDate>endDate){
				alert("开始时间不能大于结束时间");
			}else{
				var startTime=new Date(startDate).getTime()-28800000;
				var endTime=new Date(endDate).getTime()+57599999;
				// var platform=vn?vn:null;
				if(vn=="all"){
					platform=null;
				}else{
					platform=vn;
				}
				$.ajax({
					type:"POST",
					url:"/dataStatistics",
					data:{
						startTime:startTime,
						endTime:endTime,
						platform:platform,
						selectVal:selectVal
					},
					success:function(data){
						if(data){
							var arr=data.arr;
							var date=data.date;
							var title,axisNameX,axisNameY,tip,unit;
							var tabTit,h1,h2,hArr;
							if (selectVal=="retention"){
								return;
							}else if(selectVal=="newUser"){
								var subtitle="",seriesName="people";
								title="New Users Statistics";
								axisNameY="New Users";
								unit="人"
								axisNameX=date;
								curveGraphs(title,subtitle,axisNameX,axisNameY,arr,seriesName,unit);

								table.innerHTML='<caption class="caption"></caption>';
								tabTit="新增用户统计表";
								h1="日期";
								h2="新增人数";
								showTable(tabTit,h1,h2,date,arr);
									

							}else if(selectVal=="loginUser"){
								var subtitle="",seriesName="people";
								title="User Statistics";
								axisNameY="Users";
								unit="人"
								axisNameX=date;
								curveGraphs(title,subtitle,axisNameX,axisNameY,arr,seriesName,unit);

								table.innerHTML='<caption class="caption"></caption>';
								tabTit="登录用户统计表";
								h1="日期";
								h2="用户人数";
								showTable(tabTit,h1,h2,date,arr);

							}else if(selectVal=="nextDayRemain"){
								var subtitle="",seriesName="次日留存";
								title="The Next Day Remains";
								axisNameY="Users";
								unit="%"
								axisNameX=date;
								curveGraphs(title,subtitle,axisNameX,axisNameY,arr,seriesName,unit);

								table.innerHTML='<caption class="caption"></caption>';
								tabTit="次日留存统计表";
								h1="日期";
								h2="次日留存";
								showTable(tabTit,h1,h2,date,arr);

							}else if(selectVal=="sevenDayRemain"){
								var subtitle="",seriesName="七日留存";
								title="Seven Days Remain";
								axisNameY="Users";
								unit="%"
								axisNameX=date;
								curveGraphs(title,subtitle,axisNameX,axisNameY,arr,seriesName,unit);

								table.innerHTML='<caption class="caption"></caption>';
								tabTit="七日留存统计表";
								h1="日期";
								h2="七日留存";
								showTable(tabTit,h1,h2,date,arr);

							}else if(selectVal=="activeUser"){
								var subtitle="",seriesName="people";
								title="Active Users Per Day";
								axisNameY="Users";
								unit="人"
								axisNameX=date;
								curveGraphs(title,subtitle,axisNameX,axisNameY,arr,seriesName,unit);

								table.innerHTML='<caption class="caption"></caption>';
								tabTit="活跃用户统计表";
								h1="日期";
								h2="活跃用户";
								showTable(tabTit,h1,h2,date,arr);

							}else if(selectVal=="payUser"){
								var subtitle="",seriesName="people";
								title="Paid Users";
								axisNameY="Users";
								unit="人"
								axisNameX=date;
								curveGraphs(title,subtitle,axisNameX,axisNameY,arr,seriesName,unit);

								table.innerHTML='<caption class="caption"></caption>';
								tabTit="付费用户统计表";
								h1="日期";
								h2="付费人数";
								showTable(tabTit,h1,h2,date,arr);

							}else if(selectVal=="rate"){
								var subtitle="",seriesName="Rate";
								title="Rate";
								axisNameY="Rate";
								unit="%"
								axisNameX=date;
								curveGraphs(title,subtitle,axisNameX,axisNameY,arr,seriesName,unit);

								table.innerHTML='<caption class="caption"></caption>';
								tabTit="付费率统计表";
								h1="日期";
								h2="付费率";
								showTable(tabTit,h1,h2,date,arr);

							}else if(selectVal=="averagePay"){
								var subtitle="",seriesName="Average";
								title="Average Payment";
								axisNameY="Average";
								unit="元"
								axisNameX=date;
								curveGraphs(title,subtitle,axisNameX,axisNameY,arr,seriesName,unit);

								table.innerHTML='<caption class="caption"></caption>';
								tabTit="平均付费统计表";
								h1="日期";
								h2="平均付费";
								showTable(tabTit,h1,h2,date,arr);

							}else if(selectVal=="onlineLength"){
								var subtitle="",seriesName="Online";
								title="Online Length";
								axisNameY="Online Length";
								unit="小时"
								axisNameX=date;
								curveGraphs(title,subtitle,axisNameX,axisNameY,arr,seriesName,unit);

								table.innerHTML='<caption class="caption"></caption>';
								tabTit="在线时长统计表";
								h1="日期";
								h2="在线时长";
								showTable(tabTit,h1,h2,date,arr);

							}else if(selectVal=="difficulty"){
								var subtitle="",easyArr=[],normalArr=[],hardArr=[];
									axisNameX=[];
									title="The Difficulty Of Choice";
									axisNameY="Number Of People";
									axisNameX=date;
									for (var i = 0; i < arr.length; i++) {
										easyArr.push(arr[i][0]);
										normalArr.push(arr[i][1]);
										hardArr.push(arr[i][2]);
									}
									barGraph(title,subtitle,axisNameX,axisNameY,easyArr,normalArr,hardArr);
									
									table.innerHTML='<caption class="caption"></caption>';
									hArr=["日期","简单(人)","普通(人)","困难(人)"];
									tabTit="难易度统计表";
									showTable1(tabTit,hArr,date,easyArr,normalArr,hardArr);

							}else if(selectVal=="gameDuration"){
								var subtitle="",seriesName="people";
								title="Play Game Time";
								axisNameY="Number Of People";
								unit="人";
								for (var i = 0; i < date.length; i++) {
									date[i]=date[i]+"小时";
								}
								axisNameX=date;
								curveGraphs(title,subtitle,axisNameX,axisNameY,arr,seriesName,unit);

								table.innerHTML='<caption class="caption"></caption>';
								tabTit="游戏总时长统计表";
								h1="日期";
								h2="游戏时长(人)";
								showTable(tabTit,h1,h2,date,arr);

							}else if(selectVal=="teachingCompletion"){
								var subtitle="",seriesName="people";
								title="Complete The Teaching Of Novice";
								axisNameY="Number Of People";
								unit="人";
								axisNameX=date;
								curveGraphs(title,subtitle,axisNameX,axisNameY,arr,seriesName,unit);

								table.innerHTML='<caption class="caption"></caption>';
								tabTit="新手教学完成度统计表";
								h1="步骤";
								h2="人数";
								showTable(tabTit,h1,h2,date,arr);

							}else if(selectVal=="PokedexUnlocked"){
								var subtitle="",seriesName="people";
								title="Pokedex Unlocked";
								axisNameY="Number Of People";
								unit="人";
								axisNameX=date;
								curveGraphs(title,subtitle,axisNameX,axisNameY,arr,seriesName,unit);

								table.innerHTML='<caption class="caption"></caption>';
								tabTit="图鉴解锁状态统计表";
								h1="图鉴";
								h2="人数";
								showTable(tabTit,h1,h2,date,arr);

							}else if(selectVal=="enemyKillNum"){
								$("#graph").css("display","none");
								var ratio=data.ratio;

								table.innerHTML='<caption class="caption"></caption>';
								hArr=["怪物名称","杀死次数","比例"];
								tabTit="怪物杀死玩家次数统计";
								showTable2(tabTit,hArr,date,arr,ratio);
							}else if(selectVal=="reviveNum"){

							}else if(selectVal=="exitPosition"){

							}else if(selectVal=="buyThing"){
								var subtitle="",seriesName="money";
								var goods=[],rat=[],money=[],type=[];
								title="Purchased Goods";
								axisNameY="money";
								unit="元";
								axisNameX=date;
								var buyJson=data.buyJson;
								curveGraphs(title,subtitle,axisNameX,axisNameY,arr,seriesName,unit);

								var mul=data.mul;
								var buyJson=data.buyJson;
								for (var i = 0; i < mul.length; i++) {
									goods[i]=mul[i][0];
									rat[i]=mul[i][1];
									money[i]=mul[i][2];
									type[i]=mul[i][3];
								}
								table.innerHTML='<caption class="caption"></caption>';
								hArr=["物品","交易金额","比例","备注"];
								tabTit="商品交易统计表";
								showTable3(tabTit,hArr,goods,money,rat,type,buyJson);

							}
							
						}
					}
				})
			}
		})

		$("#selectBox").change(function(){
			var select=$("#selectBox").val();
			var table1=document.getElementById("table1");
			$("#tableBox .btnbox").css("display","none");
			$("#tableBox1 .btnbox").css("display","none");
			$("#graph").css("display","block");
			$("#graph").html("");

			table.innerHTML='<caption class="caption"></caption>';
			table1.innerHTML='<caption class="caption"></caption>';

			if(select=="PokedexUnlocked"){
				$("#fileBox").css("display","block");
				$("#prompt").html("若图鉴文件有更新,需上传新的文件,文件名请用 MonsterHandbook.xlsx");
			}else if(select=="buyThing"){
				$("#fileBox").css("display","block");
				$("#prompt").html("若商品文件有更新,需上传新的文件,文件名请用 merchandise.xlsx");
			}else if(select=="enemyKillNum"){
				$("#fileBox").css("display","block");
				$("#prompt").html("若怪物文件有更新,需上传新的文件,文件名请用 MonstersList.xlsx");
			}else{
				$("#fileBox").css("display","none");
			}
		})
		$("#upfile").change(function(){
			var fileName=getFileName($("#upfile").val());
			$("#fileBox .fileName").html(fileName);
			if (fileName!="MonsterHandbook.xlsx" && fileName!="merchandise.xlsx" && fileName!="MonstersList.xlsx"){
				alert("文件名错误");
			}else{
				var myfile=$("#upfile")[0].files[0];
	            var formData = new FormData($("#myform"));
	            formData.append("avatar",myfile);
	            $.ajax({
	                type:"POST",
	                url:"/dataStatistics/upfile",
	                data:formData,
	                cache:false,
	                contentType:false,
	                processData:false,
	                success:function(result){
	                    if (result.result){
	                        alert("上传成功");
	                    }else{
	                        alert("上传失败");
	                    }
	                }
	            });
			}
			
		})




		function toTwo(num){
        	return num<10?"0"+num:num;
    		}
		function getLocalTime(date) {     
       			return date.getFullYear()+"-"+toTwo(date.getMonth()+1)+"-"+toTwo(date.getDate());     
    		}
    	function getFileName(path){
                var pos1 = path.lastIndexOf('/');
                var pos2 = path.lastIndexOf('\\');
                var pos  = Math.max(pos1, pos2)
                if( pos<0 )
                return path;
                else
                return path.substring(pos+1);
            }

    	function brokenLineGraph(arr,date,title,axisNameX,axisNameY,tip1,tip2,tip3){
    		var logTable = new JSChart('graph', 'line');
				logTable.setDataArray(arr);
				logTable.setTitle(title);
				logTable.setTitleColor('#8E8E8E');
				logTable.setTitleFontSize(18);
				logTable.setAxisNameX(axisNameX);
				logTable.setAxisNameY(axisNameY);
				logTable.setAxisNameColor('#8E8E8E')
				logTable.setAxisColor('#000');
				logTable.setAxisValuesColor('#f00');
				logTable.setAxisPaddingLeft(60);
				logTable.setAxisPaddingRight(80);
				logTable.setAxisPaddingTop(60);
				logTable.setAxisPaddingBottom(50);
				logTable.setAxisValuesDecimals(0);
				logTable.setAxisValuesNumberX(20);//x轴点的距离
				logTable.setShowXValues(false);
				logTable.setGridColor('#C5A2DE');
				logTable.setLineColor('#9D12FD');//线的颜色
				logTable.setLineWidth(2);
				logTable.setFlagColor('#9D12FD');//圈的颜色
				logTable.setFlagRadius(0.5);
				// logTable.setLabelRotationAngle(20);
				logTable.setTooltipOffset(5)
				for (var i = 0; i < arr.length; i++) {
					logTable.setTooltip([arr[i][0],tip1+date[i]+tip2+arr[i][1]+tip3]);
				}
				logTable.setSize(1100, 700);
				logTable.draw();
    	}
    	function barGraph(title,subtitle,axisNameX,axisNameY,easyArr,normalArr,hardArr){
    		Highcharts.chart('graph', {
		    chart: {
		        type: 'column'
		    },
		    title: {
		        text: title
		    },
		    subtitle: {
		        text: subtitle
		    },
		    xAxis: {
		        categories: axisNameX,
		        crosshair: true
		    },
		    yAxis: {
		        min: 0,
		        title: {
		            text: axisNameY
		        }
		    },
		    tooltip: {
		        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
		        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
		            '<td style="padding:0"><b>{point.y:f} 人</b></td></tr>',
		        footerFormat: '</table>',
		        shared: true,
		        useHTML: true
		    },
		    plotOptions: {
		        column: {
		            pointPadding: 0.1,
		            borderWidth: 0
		        }
		    },
		    series: [{
		        name: 'easy',
		        data:easyArr

		    }, {
		        name: 'normal',
		        data:normalArr

		    }, {
		        name: 'hard',
		        data:hardArr
		    }]
		});
   		}

   		function curveGraphs(title,subtitle,xAxis,yAxis,arr,seriesName,unit){
   			Highcharts.chart('graph', {
		    chart: {
		        type: 'spline'
		    },
		    title: {
		        text: title
		    },
		    subtitle: {
		        text: subtitle
		    },
		    xAxis: {
		        categories: xAxis
		    },
		    yAxis: {
		        title: {
		            text: yAxis
		        },
		        labels: {
		            formatter: function () {
		                return this.value+unit;
		            }
		        }
		    },
		    tooltip: {
		        crosshairs: true,
		        shared: true
		    },
		    plotOptions: {
		        spline: {
		            marker: {
		                radius: 2,
		                lineColor: '#666666',
		                lineWidth: 1
		            }
		        }
		    },
		    series: [{
		        name: seriesName,
		        // marker: {
		        //     symbol: 'diamond'
		        // },
		        data: arr

		    }]
		});
   		}

   		function showTable(tabTit,h1,h2,date,arr){
				$("#table .caption").html(tabTit);
				$("#tableBox .btnbox").css("display","block");
				var otr=document.createElement("tr")
				otr.className="h";
				for (var h = 0; h < 2; h++) {
				var oth=document.createElement("th");
				var text="";
					switch(h){
						case 0:
						text=h1;
						break;
						case 1:
						text=h2;
						break;
					}
					oth.innerHTML=text;
					otr.appendChild(oth);
				}
				table.appendChild(otr);

				for (var i = 0; i < date.length; i++) {
					var tr=document.createElement("tr");
					for (var j = 0; j < 2; j++) {
						var td=document.createElement("td");
						var html="";
						switch(j){
							case 0:
							html=date[i];
							break;
							case 1:
							html=arr[i];
							break;
						}
						td.innerHTML=html;
						tr.appendChild(td);
					}
					table.appendChild(tr);
					numberRowsInTable = table.querySelectorAll("tr:not(.h)"),//获取所有记录
					length= numberRowsInTable.length,//记录总条数
					hide();
				}

				nextLink();
				preText();
			}

			function showTable1(tabTit,hArr,date,arr1,arr2,arr3){
				$("#table .caption").html(tabTit);
				$("#tableBox .btnbox").css("display","block");
				var otr=document.createElement("tr")
				otr.className="h";
				for (var h = 0; h < hArr.length; h++) {
				var oth=document.createElement("th");
					oth.innerHTML=hArr[h];
					otr.appendChild(oth);
				}
				table.appendChild(otr);

				for (var i = 0; i < date.length; i++) {
					var tr=document.createElement("tr");
					for (var j = 0; j < 4; j++) {
						var td=document.createElement("td");
						var html="";
						switch(j){
							case 0:
							html=date[i];
							break;
							case 1:
							html=arr1[i];
							break;
							case 2:
							html=arr2[i];
							break;
							case 3:
							html=arr3[i];
							break;
						}
						td.innerHTML=html;
						tr.appendChild(td);
					}
					table.appendChild(tr);
					numberRowsInTable = table.querySelectorAll("tr:not(.h)"),//获取所有记录
					length= numberRowsInTable.length,//记录总条数
					hide();
				}

				nextLink();
				preText();
			}

			function showTable2(tabTit,hArr,date,arr1,arr2){
				$("#table .caption").html(tabTit);
				$("#tableBox .btnbox").css("display","block");
				var otr=document.createElement("tr")
				otr.className="h";
				for (var h = 0; h < hArr.length; h++) {
				var oth=document.createElement("th");
					oth.innerHTML=hArr[h];
					otr.appendChild(oth);
				}
				table.appendChild(otr);

				for (var i = 0; i < date.length; i++) {
					var tr=document.createElement("tr");
					for (var j = 0; j < 3; j++) {
						var td=document.createElement("td");
						var html="";
						switch(j){
							case 0:
							html=date[i];
							break;
							case 1:
							html=arr1[i];
							break;
							case 2:
							html=arr2[i];
							break;
						}
						td.innerHTML=html;
						tr.appendChild(td);
					}
					table.appendChild(tr);
					numberRowsInTable = table.querySelectorAll("tr:not(.h)"),//获取所有记录
					length= numberRowsInTable.length,//记录总条数
					hide();
				}

				nextLink();
				preText();
			}

			function showTable3(tabTit,hArr,date,arr1,arr2,type,buyJson){
				$("#table .caption").html(tabTit);
				$("#tableBox .btnbox").css("display","block");
				var otr=document.createElement("tr")
				otr.className="h";
				for (var h = 0; h < hArr.length; h++) {
				var oth=document.createElement("th");
					oth.innerHTML=hArr[h];
					otr.appendChild(oth);
				}
				table.appendChild(otr);

				for (var i = 0; i < date.length; i++) {
					var tr=document.createElement("tr");
					tr.className=type[i];
					for (var j = 0; j < 4; j++) {
						var td=document.createElement("td");
						var html="";
						switch(j){
							case 0:
							html=date[i];
							break;
							case 1:
							html=arr1[i];
							break;
							case 2:
							html=arr2[i];
							break;
							case 3:
							html='<span class="det">详情</span>';
							break;
						}
						td.innerHTML=html;
						tr.appendChild(td);
					}
					table.appendChild(tr);
					numberRowsInTable = table.querySelectorAll("tr:not(.h)"),//获取所有记录
					length= numberRowsInTable.length,//记录总条数
					hide();
				}

				nextLink();
				preText();
				details(buyJson);
			}
			
			function details(buyJson){
				var oDet=document.querySelectorAll("#table td span.det");
				for (var i = 0; i < oDet.length; i++) {
					oDet[i].onclick=function(){
						dataDeal(this.parentNode.parentNode.className,buyJson);
					}
				}
			}

			function dataDeal(type,buyJson){
				var bd=[],buy={},index=0;
				for(var bj in buyJson){
					if(buyJson[bj].type==type){
						if(buy[buyJson[bj].name]){
							buy[buyJson[bj].name].money+=buyJson[bj].money;
							buy[buyJson[bj].name].id=buy[buyJson[bj].name].id+"_"+bj;
						}else{
							buy[buyJson[bj].name]={
								id:bj,
								money:buyJson[bj].money,
								typeName:buyJson[bj].typeName
							}
						}				
					}
				}
				for(var by in buy){
					bd[index]=[];
					bd[index][0]=by;
					bd[index][1]=buy[by].money;
					bd[index][2]=buy[by].typeName;
					index++;
				}
				bd.sort(function(a,b){
					return b[1]-a[1];
				})
				table1.innerHTML='<caption class="caption"></caption>';
				tabTit=bd[0][2]+"销售统计表";
				h1=bd[0][2];
				h2="金额";
				showTable4(tabTit,h1,h2,bd);
				
			}
			
				
			

			function showTable4(tabTit,h1,h2,arr){

				var table1 = document.getElementById("table1"),
				totalPage1 = document.getElementById("spanTotalPage1"),//总页数
				pageNum1 = document.getElementById("spanPageNum1"), //获取当前页<span> 
				spanPre1 = document.getElementById("spanPre1"),//获取上一页<span> 
				spanNext1 = document.getElementById("spanNext1"),//获取下一页<span> 
				numberRowsInTable1 = table1.querySelectorAll("tr:not(.h1)"),//获取所有记录
				length1= numberRowsInTable1.length,//记录总条数
			 	pageSize1 = 10, //每页显示的记录条数 
			 	currentRow1,
			 	maxRow1,
				page1 = 1; //当前页，默认第一页 
				spanPre1.onclick=pre1;
				spanNext1.onclick=next1;
			function next1(){
				if(page1<pageCount1()){
					hideTable1();
					currentRow1=page1*pageSize1;
					maxRow1=currentRow1+pageSize1;
					if (maxRow1>length1) maxRow1=length1;
					for (var i = currentRow1; i < maxRow1; i++) {
						numberRowsInTable1[i].style.display="";
					}
					page1++;
					if (page1==pageCount1()) {
						nextText1();
					}else{
						nextLink1();
					}
				}
			
				prelLink1();
				showPage1();
			}
			function pre1(){
				if(page1>1){
					hideTable1();
					page1--;
					maxRow1=page1*pageSize1;
					currentRow1=maxRow1-pageSize1;
					if (currentRow1<0) currentRow1=0;
					for (var i = currentRow1; i < maxRow1; i++) {
						numberRowsInTable1[i].style.display="";
					}
					if (currentRow1==0) {
						preText1();
					}else{
						prelLink1();
					}
				}
			
					nextLink1();
					showPage1();
			
			
			}
			function prelLink1(){
				spanPre1.className="btn";
			}
			function preText1(){
				spanPre1.className="btn on";
			}
			function nextLink1(){
				spanNext1.className="btn";
			}
			function nextText1(){
				spanNext1.className="btn on";
			}
			function pageCount1(){
				return Math.ceil(length1/pageSize1);
			}
			function hideTable1(){
				for (var i = 0; i < length1; i++) {
					numberRowsInTable1[i].style.display="none";
				}
			}
			function showPage1(){
				pageNum1.innerHTML=page1;
			}
			function hide1(){
				for (var i = pageSize1; i < length1; i++){
					numberRowsInTable1[i].style.display="none";
				}
				pageNum1.innerHTML=1;
				page1=1;
				totalPage1.innerHTML=pageCount1();
				preText1();
			}
			hide1();

			$("#jump1").bind("click",function(){
				var jumpPage=$("#jumpPage1 input").val();
				hideTable1();
				var tot=pageCount1();
				// page=jumpPage;
				jumpPage>tot?page1=tot:page1=jumpPage;
				currentRow1=(page1-1)*pageSize1;
				maxRow1=currentRow1+pageSize1;
				if (maxRow1>length1) maxRow1=length1;
				for (var i = currentRow1; i < maxRow1; i++) {
					numberRowsInTable1[i].style.display="";
				}
				if (page1==pageCount1()) {
					nextText1();
				}else{
					nextLink1();
				}
				if (currentRow1==0) {
					preText1();
				}else{
					prelLink1();
				}
				showPage1();

			})


				$("#table1 .caption").html(tabTit);
				$("#tableBox1 .btnbox").css("display","block");
				var otr=document.createElement("tr");
				otr.className="h1";
				for (var h = 0; h < 2; h++) {
				var oth=document.createElement("th");
				var text="";
					switch(h){
						case 0:
						text=h1;
						break;
						case 1:
						text=h2;
						break;
					}
					oth.innerHTML=text;
					otr.appendChild(oth);
				}
				table1.appendChild(otr);

				for (var i = 0; i < arr.length; i++) {
					var tr=document.createElement("tr");
					for (var j = 0; j < 2; j++) {
						var td=document.createElement("td");
						var html="";
						switch(j){
							case 0:
							html=arr[i][0];
							break;
							case 1:
							html=arr[i][1];
							break;
						}
						td.innerHTML=html;
						tr.appendChild(td);
					}
					table1.appendChild(tr);
					numberRowsInTable1 = table1.querySelectorAll("tr:not(.h1)"),//获取所有记录
					length1= numberRowsInTable1.length,//记录总条数
					hide1();
				}

				nextLink1();
				preText1();
			}
   		
	})()
})