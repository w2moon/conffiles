$(document).ready(function(){
	(function(){
		$("#items .btn").click(function(){
			$("#items .btn").before('<p class="item"><input class="itemid" type="text" name=""><input class="itemnum" type="number" min="0" name=""></p>');

		})
		$("#emailSubmit").click(function(){
			var userId=$("#userId").val();
			var sendUser=$("#sendUser").val();
			var eTitle=$("#eTitle").val();
			var eContent=$("#eContent").val();
			var itemId=document.querySelectorAll("#itemBox .itemid");
			var itemNum=document.querySelectorAll("#itemBox .itemnum");
			var items=[];
			for (var i = 0; i < itemId.length; i++) {
				if (itemId[i].value && itemNum[i].value){
					var obj={
						"id":itemId[i].value,
						"num":itemNum[i].value,
						"used":false
					}
					items.push(obj);
				}
			}
			if(!sendUser){
				alert("请输入发件人");
			}else if(!userId){
				alert("请输入发件人");
			}else if(!eTitle){
				alert("请输入邮件标题");
			}else if(!eContent){
				alert("请输入邮件内容");
			}else{
				var itemsStr=JSON.stringify(items);
				$.ajax({
					type:"POST",
					url:"/sendMail",
					data:{
						sendUser:sendUser,
						to:userId,
						title:eTitle,
						content:eContent,
						items:itemsStr,
						read:false,
						SendMode:"hand"
					},
					success:function(result){
						alert(result);
						window.location.reload();
					}
				});
			}
			
		})
	})()
})