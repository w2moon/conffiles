$(document).ready(function(){
	(function(){
		var table = document.getElementById("table"),
			totalPage = document.getElementById("spanTotalPage"),//总页数
			pageNum = document.getElementById("spanPageNum"), //获取当前页<span> 
			spanPre = document.getElementById("spanPre"),//获取上一页<span> 
			spanNext = document.getElementById("spanNext"),//获取下一页<span> 
			numberRowsInTable = table.querySelectorAll("tr"),//获取所有记录
			length= numberRowsInTable.length,//记录总条数
		 	pageSize = 5, //每页显示的记录条数 
		 	currentRow,
		 	maxRow,
			page = 1; //当前页，默认第一页 
			spanPre.onclick=pre;
			spanNext.onclick=next;
		function next(){
			if(page<pageCount()){
				hideTable();
				currentRow=page*pageSize;
				maxRow=currentRow+pageSize;
				if (maxRow>length) maxRow=length;
				for (var i = currentRow; i < maxRow; i++) {
					numberRowsInTable[i].style.display="";
				}
				page++;
				if (page==pageCount()) {
					nextText();
				}
			}
		
			prelLink();
			showPage();
		}
		function pre(){
			if(page>1){
				hideTable();
				page--;
				maxRow=page*pageSize;
				currentRow=maxRow-pageSize;
				if (currentRow<0) currentRow=0;
				for (var i = currentRow; i < maxRow; i++) {
					numberRowsInTable[i].style.display="";
				}
				if (currentRow==0) {
					preText();
				}
			}
		
				nextLink();
				showPage();
		
		
		}
		function prelLink(){
			spanPre.className="btn";
		}
		function preText(){
			spanPre.className="btn on";
		}
		function nextLink(){
			spanNext.className="btn";
		}
		function nextText(){
			spanNext.className="btn on";
		}
		function pageCount(){
			return Math.ceil(length/pageSize);
		}
		function hideTable(){
			for (var i = 0; i < length; i++) {
				numberRowsInTable[i].style.display="none";
			}
		}
		function showPage(){
			pageNum.innerHTML=page;
		}
		function hide(){
			for (var i = pageSize; i < length; i++){
				numberRowsInTable[i].style.display="none";
			}
			pageNum.innerHTML=1;
			totalPage.innerHTML=pageCount();
			preText();
		}
		hide();
		
		function toTwo(num){
        	return num<10?"0"+num:num;
    		}
		function getLocalTime(date) {     
       			return date.getFullYear()+"-"+toTwo(date.getMonth()+1)+"-"+toTwo(date.getDate())+" "+toTwo(date.getHours())+":"+toTwo(date.getMinutes());     
    		}
		 $("#submit").bind("click", function () {
		 	table.innerHTML="";
		 	var num=0;
		 	var user=$("#user").val();
		 	if (!user){
		 		alert("请输入掌趣账号");
		 	}else{
		 		$.ajax({
		 			type:"POST",
		 			url:"/transactionRecord",
		 			data:"user="+user,
		 			success:function(result){
		 				if (result){
		 					console.log(result);
		 					for (var j = 0; j < result.length; j++) {
		 						var otr=document.createElement("tr");
				 				for (var i = 0; i < 6; i++) {
					 				var otd=document.createElement("td");
					 				var html;
						 				switch(i){
						 					case 0:
						 					html=++num;
						 					break;
						 					case 1:
						 					html=result[j].giftId;
						 					break;
						 					case 2:
						 					html=result[j].gifName;
						 					break;
						 					case 3:
						 					html=result[j].gifPrice;
						 					break;
						 					case 4:
						 					html=result[j].user;
						 					break;
						 					case 5:
						 					html=getLocalTime(new Date(result[j].time));
						 				}
						 				otd.innerHTML=html;
						 				otr.appendChild(otd);
					 				}
					 				table.appendChild(otr);
					 				numberRowsInTable = table.querySelectorAll("tr"),//获取所有记录
									length= numberRowsInTable.length,//记录总条数
					 				hide();
			 					}


		 				}
		 				
		 			}
		 		})
		 	}
	        
	     });
    	
	})()
})