$(document).ready(function(){
	(function(){
		var table = document.getElementById("table"),
			totalPage = document.getElementById("spanTotalPage"),//总页数
			pageNum = document.getElementById("spanPageNum"), //获取当前页<span> 
			spanPre = document.getElementById("spanPre"),//获取上一页<span> 
			spanNext = document.getElementById("spanNext"),//获取下一页<span> 
			numberRowsInTable = table.querySelectorAll("tr"),//获取所有记录
			length= numberRowsInTable.length,//记录总条数
		 	pageSize = 5, //每页显示的记录条数 
		 	currentRow,
		 	maxRow,
			page = 1; //当前页，默认第一页 
			spanPre.onclick=pre;
			spanNext.onclick=next;
		function next(){
			if(page<pageCount()){
				hideTable();
				currentRow=page*pageSize;
				maxRow=currentRow+pageSize;
				if (maxRow>length) maxRow=length;
				for (var i = currentRow; i < maxRow; i++) {
					numberRowsInTable[i].style.display="";
				}
				page++;
				if (page==pageCount()) {
					nextText();
				}
			}
		
			prelLink();
			showPage();
		}
		function pre(){
			if(page>1){
				hideTable();
				page--;
				maxRow=page*pageSize;
				currentRow=maxRow-pageSize;
				if (currentRow<0) currentRow=0;
				for (var i = currentRow; i < maxRow; i++) {
					numberRowsInTable[i].style.display="";
				}
				if (currentRow==0) {
					preText();
				}
			}
		
				nextLink();
				showPage();
		
		
		}
		function prelLink(){
			spanPre.className="btn";
		}
		function preText(){
			spanPre.className="btn on";
		}
		function nextLink(){
			spanNext.className="btn";
		}
		function nextText(){
			spanNext.className="btn on";
		}
		function pageCount(){
			return Math.ceil(length/pageSize);
		}
		function hideTable(){
			for (var i = 0; i < length; i++) {
				numberRowsInTable[i].style.display="none";
			}
		}
		function showPage(){
			pageNum.innerHTML=page;
		}
		function hide(){
			for (var i = pageSize; i < length; i++){
				numberRowsInTable[i].style.display="none";
			}
			pageNum.innerHTML=1;
			totalPage.innerHTML=pageCount();
			preText();
		}
		hide();
		

		init();
		function init(){
			var date = new Date();
			var startInit = date.getFullYear()+"-"+toTwo(date.getMonth()+1)+"-"+toTwo(date.getDate())+"T"+"00:00";
			var endInit = date.getFullYear()+"-"+toTwo(date.getMonth()+1)+"-"+toTwo(date.getDate())+"T"+toTwo(date.getHours())+":"+toTwo(date.getMinutes());
			$("#startDate").val(startInit);
			$("#endDate").val(endInit);
			$("#showTime").html($("#startDate").val().replace("T"," ")+"&nbsp; to &nbsp;"+$("#endDate").val().replace("T"," "));
		}

		function toTwo(num){
        	return num<10?"0"+num:num;
    		}
		function getLocalTime(date) {     
       			return date.getFullYear()+"-"+toTwo(date.getMonth()+1)+"-"+toTwo(date.getDate())+" "+toTwo(date.getHours())+":"+toTwo(date.getMinutes());     
    		}

		$("#search").bind("click", function () {
			 table.innerHTML="";
             var startDate=$("#startDate").val();
             var endDate=$("#endDate").val();
			 var showTime=$("#showTime");
			 var num=0;
             if (!startDate){
             	alert("请输入开始时间");
             }else if(!endDate){
             	alert("请输入结束时间");
             }else if(startDate>endDate){
             	alert("开始时间不能大于结束时间");
             }else{
             	showTime.html(startDate.replace("T"," ")+"&nbsp; to &nbsp;"+endDate.replace("T"," "));
             	var startTime=new Date(startDate).getTime();
             	var endTime=new Date(endDate).getTime();
             	var obj={
             		startTime:startTime,
             		endTime:endTime
             	}
             	$.ajax({
             		type:"POST",
             		url:"/salesDataCount",
             		data:obj,
             		success:function(result){
             			if(result){
							 for (var key in result) {
							 var otr=document.createElement("tr");
								for (var i = 0; i < 6; i++) {
									var otd=document.createElement("td");
									var html;
									switch(i){
										case 0:
										html=++num;
										break;
										case 1:
										html=result[key][0].giftId;
										break;
										case 2:
										html=result[key][0].gifName;
										break;
										case 3:
										html=result[key][0].gifPrice;
										break;
										case 4:
										html=result[key].length;
										break;
										case 5:
										html=showTime.html();
									}
									otd.innerHTML=html;
									otr.appendChild(otd);
								}
								table.appendChild(otr);
								numberRowsInTable = table.querySelectorAll("tr");//获取所有记录
								length= numberRowsInTable.length;//记录总条数
								hide();
							 }
							 
						 }
             		}
             	})
             }
	    });
    	
	})()
})