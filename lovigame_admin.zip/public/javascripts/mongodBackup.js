$(document).ready(function(){
    (function(){
        var table = document.getElementById("table"),
        totalPage = document.getElementById("spanTotalPage"),//总页数
        pageNum = document.getElementById("spanPageNum"), //获取当前页<span> 
        spanPre = document.getElementById("spanPre"),//获取上一页<span> 
        spanNext = document.getElementById("spanNext"),//获取下一页<span> 
        numberRowsInTable = table.querySelectorAll("tr"),//获取所有记录
        length= numberRowsInTable.length,//记录总条数
         pageSize = 10, //每页显示的记录条数 
         currentRow,
         maxRow,
        page = 1; //当前页，默认第一页 
        spanPre.onclick=pre;
        spanNext.onclick=next;
    function next(){
        if(page<pageCount()){
            hideTable();
            currentRow=page*pageSize;
            maxRow=currentRow+pageSize;
            if (maxRow>length) maxRow=length;
            for (var i = currentRow; i < maxRow; i++) {
                numberRowsInTable[i].style.display="";
            }
            page++;
            if (page==pageCount()) {
                nextText();
            }else{
                nextLink();
            }
        }
    
        prelLink();
        showPage();
    }
    function pre(){
        if(page>1){
            hideTable();
            page--;
            maxRow=page*pageSize;
            currentRow=maxRow-pageSize;
            if (currentRow<0) currentRow=0;
            for (var i = currentRow; i < maxRow; i++) {
                numberRowsInTable[i].style.display="";
            }
            if (currentRow==0) {
                preText();
            }else{
                prelLink();
            }
        }
    
            nextLink();
            showPage();
    
    
    }
    function prelLink(){
        spanPre.className="btn";
    }
    function preText(){
        spanPre.className="btn on";
    }
    function nextLink(){
        spanNext.className="btn";
    }
    function nextText(){
        spanNext.className="btn on";
    }
    function pageCount(){
        return Math.ceil(length/pageSize);
    }
    function hideTable(){
        for (var i = 0; i < length; i++) {
            numberRowsInTable[i].style.display="none";
        }
    }
    function showPage(){
        pageNum.innerHTML=page;
    }
    function hide(){
        for (var i = pageSize; i < length; i++){
            numberRowsInTable[i].style.display="none";
        }
        pageNum.innerHTML=1;
        totalPage.innerHTML=pageCount();
        preText();
    }
    hide();

    $("#jump").bind("click",function(){
        var jumpPage=$("#jumpPage input").val();
        hideTable();
        page=jumpPage;
        currentRow=(page-1)*pageSize;
        maxRow=currentRow+pageSize;
        if (maxRow>length) maxRow=length;
        for (var i = currentRow; i < maxRow; i++) {
            numberRowsInTable[i].style.display="";
        }
        if (page==pageCount()) {
            nextText();
        }else{
            nextLink();
        }
        if (currentRow==0) {
            preText();
        }else{
            prelLink();
        }
        showPage();

    })

        $("#submit").click(function(){
            var dataName=$("#dataName").val();
                if(!dataName){
                    alert("请输入数据库名称");
                }else{
                    $.ajax({
                        type:"POST",
                        url:"/mongodBackup",
                        data:"dataName="+dataName,
                        success:function(result){
                            if(result.result){
                                alert("备份成功");
                                numberRowsInTable = table.querySelectorAll("tr"),//获取所有记录
                                length= numberRowsInTable.length,//记录总条数
                                window.location.reload();
                                hide();
                                deleteLine();
                            }else{
                                alert("备份失败");
                            }
                        }
                    })
                }
            
        }
    )

        deleteLine();
        function deleteLine(){
        var index;
        var otd=document.querySelectorAll("#table tr td span.delete");
            for (var i = 0; i < otd.length; i++) {
                otd[i].index=i;
                otd[i].onclick=function(){
                    index=this.index;
                    var flog=confirm("确定删除吗？");
                    if (flog) {
                        deleteAjax(this.parentNode.parentNode.className,index);
                    }
                }
            }
        }
        function deleteAjax(id,index){
            $.ajax({
                type: 'POST',
                url: '/mongodBackup/delete',
                data: 'id='+id+'&table=1',
                success:function(data){
                    if (data.result) {
                        alert("删除成功");
                        window.location.reload();
                    } else {
                        alert("删除失败");
                    }
                }
            })
        
        }


        deleteLine1();
        function deleteLine1(){
        var index;
        var otd=document.querySelectorAll("#table1 tr td span.delete");
            for (var i = 0; i < otd.length; i++) {
                otd[i].index=i;
                otd[i].onclick=function(){
                    index=this.index;
                    var flog=confirm("确定删除吗？");
                    if (flog) {
                        deleteAjax1(this.parentNode.parentNode.className,index);
                    }
                }
            }
        }
        function deleteAjax1(id,index){
            $.ajax({
                type: 'POST',
                url: '/mongodBackup/delete',
                data: 'id='+id+'&table=2',
                success:function(data){
                    if (data.result) {
                        alert("删除成功");
                        window.location.reload();
                    } else {
                        alert("删除失败");
                    }
                }
            })
        
        }




        dataRecover();
        function dataRecover(){
            var index;
            var otd=document.querySelectorAll("#table tr td span.recover");
                for (var i = 0; i < otd.length; i++) {
                    otd[i].index=i;
                    otd[i].onclick=function(){
                        index=this.index;
                        var flog=confirm("确定恢复吗？");
                        if (flog) {
                            recoverAjax(this.parentNode.parentNode.className,index);
                        }
                    }
                }
            }
            function recoverAjax(id,index){
                $.ajax({
                    type: 'POST',
                    url: '/mongodBackup/recover',
                    data: 'id='+id+'&table=1',
                    success:function(data){
                        if (data.result) {
                            alert("恢复成功");
                            window.location.reload();
                        } else {
                            alert("恢复失败");
                        }
                    }
                })
            
            }


            dataRecover1();
            function dataRecover1(){
                var index;
                var otd=document.querySelectorAll("#table1 tr td span.recover");
                    for (var i = 0; i < otd.length; i++) {
                        otd[i].index=i;
                        otd[i].onclick=function(){
                            index=this.index;
                            var flog=confirm("确定恢复吗？");
                            if (flog) {
                                recoverAjax1(this.parentNode.parentNode.className,index);
                            }
                        }
                    }
                }
                function recoverAjax1(id,index){
                    $.ajax({
                        type: 'POST',
                        url: '/mongodBackup/recover',
                        data: 'id='+id+'&table=2',
                        success:function(data){
                            if (data.result) {
                                alert("恢复成功");
                                window.location.reload();
                            } else {
                                alert("恢复失败");
                            }
                        }
                    })
                
                }






            download();
                function download(){
                    var otd=document.querySelectorAll("#table tr td span.download");
                        for (var i = 0; i < otd.length; i++) {
                            otd[i].onclick=function(){
                                downloadAjax(this.parentNode.parentNode.className);
                            }
                        }
                    }
                function downloadAjax(id){
                    $.ajax({
                        type: 'GET',
                        url: '/mongodBackup/download',
                        data: 'id='+id+'&table=1',
                        success:function(){
                            window.open("mongodBackup/download?id="+id+'&table=1');
                        }
                    })
                
                }

                download1();
                function download1(){
                    var otd=document.querySelectorAll("#table1 tr td span.download");
                        for (var i = 0; i < otd.length; i++) {
                            otd[i].onclick=function(){
                                downloadAjax1(this.parentNode.parentNode.className);
                            }
                        }
                    }
                function downloadAjax1(id){
                    $.ajax({
                        type: 'GET',
                        url: '/mongodBackup/download',
                        data: 'id='+id+'&table=2',
                        success:function(){
                            window.open("mongodBackup/download?id="+id+'&table=2');
                        }
                    })
                
                }




            $("#dataFile").change(function(){
                var fileName=getFileName($("#dataFile").val());
                $("#upfile .btn").val(fileName);
            })

            $("#fileUp").click(function(){
                var myfile=$("#dataFile")[0].files[0];
                var formData = new FormData($("#myFile"));
                formData.append("avatar",myfile);
                $.ajax({
                    type:"POST",
                    url:"/mongodBackup/upLoadFile",
                    data:formData,
                    cache:false,
                    contentType:false,
                    processData:false,
                    success:function(result){
                        if (result.result){
                            alert("上传成功");
                            window.location.reload();
                        }else{
                            alert("上传失败");
                        }
                    }
                });
            })

            $("#dayBtn").click(function(){
                var time=$("#DayTime").val();
                var btnVal=$("#dayBtn").val();
                var backup;
                if(btnVal==="开始备份"){
                    if(!time){
                        alert("请输入备份时间");
                        return;
                    }else{
                        backup=true;
                    }
                }else if(btnVal==="停止备份"){
                    backup=false;
                }
                var obj={
                    work:-1,
                    time:time,
                    backup:backup
                }
                $.ajax({
                    type:"POST",
                    url:"/mongodBackup/fixTimeBackup",
                    data:obj,
                    success:function(result){
                       if(!result.result){
                            $("#dayBtn").val("开始备份");
                            $("#workBtn").val("开始备份");
                            $("#fixTime .day .dayTxt").html("");
                            $("#fixTime .work .workTxt").html("");
                       }else if(result.result==="day"){
                            $("#dayBtn").val("停止备份");
                            $("#workBtn").val("开始备份");
                            $("#fixTime .day .dayTxt").html("备份中");
                            $("#fixTime .work .workTxt").html("");
                       }else if(result.result==="work"){
                            $("#dayBtn").val("开始备份");
                            $("#workBtn").val("停止备份");
                            $("#fixTime .day .dayTxt").html("");
                            $("#fixTime .work .workTxt").html("备份中");
                       }
                       timingBackup();
                       deleteLine1();
                       download1();
                    }
                });

            })

            $("#workBtn").click(function(){
                var work=$("#work").val();
                var workTime=$("#workTime").val();
                var workBtn=$("#workBtn").val();
                var backup;
                if(workBtn==="开始备份"){
                    if(!work || !workTime){
                        alert("请输入备份时间");
                        return;
                    }else{
                        backup=true;
                    }
                }else if(workBtn==="停止备份"){
                    backup=false;
                }
                var obj={
                    work:work,
                    time:workTime,
                    backup:backup
                }
                $.ajax({
                    type:"POST",
                    url:"/mongodBackup/fixTimeBackup",
                    data:obj,
                    success:function(result){
                        if(!result.result){
                            $("#dayBtn").val("开始备份");
                            $("#workBtn").val("开始备份");
                            $("#fixTime .day .dayTxt").html("");
                            $("#fixTime .work .workTxt").html("");
                        }else if(result.result==="day"){
                            $("#dayBtn").val("停止备份");
                            $("#workBtn").val("开始备份");
                            $("#fixTime .day .dayTxt").html("备份中");
                            $("#fixTime .work .workTxt").html("");
                        }else if(result.result==="work"){
                            $("#dayBtn").val("开始备份");
                            $("#workBtn").val("停止备份");
                            $("#fixTime .day .dayTxt").html("");
                            $("#fixTime .work .workTxt").html("备份中");
                        }
                        timingBackup();
                        deleteLine1();
                        download1();
                    }
                });
            })



            $("#delBtn").click(function(){
                var delBtnVal=$("#delBtn").val();
                var delNum; 
                    if(delBtnVal==="开始运行"){
                        delNum=$("#delVal").val();
                        if(!delNum){
                            alert("请输入数据");
                            return;
                        }
                    }else if(delBtnVal==="暂停运行"){
                        delNum="-1";
                    }

                    $.ajax({
                        type:"POST",
                        url:"/mongodBackup/autoDel",
                        data:"delNum="+delNum,
                        success:function(result){
                            if(result.result<0){
                                $("#delBtn").val("开始运行");
                                $("#fixTime .fixDel .delTxt").html("");
                            }else{
                                $("#delBtn").val("暂停运行");
                                $("#fixTime .fixDel .delTxt").html("运行中");
                                
                            }
                        }
                    })
            })





            function getFileName(path){
                var pos1 = path.lastIndexOf('/');
                var pos2 = path.lastIndexOf('\\');
                var pos  = Math.max(pos1, pos2)
                if( pos<0 )
                return path;
                else
                return path.substring(pos+1);
            }

            timingBackup();
            function timingBackup(){
                var table1 = document.getElementById("table1"),
                    totalPage1 = document.getElementById("spanTotalPage1"),//总页数
                    pageNum1 = document.getElementById("spanPageNum1"), //获取当前页<span> 
                    spanPre1 = document.getElementById("spanPre1"),//获取上一页<span> 
                    spanNext1 = document.getElementById("spanNext1"),//获取下一页<span> 
                    numberRowsInTable1 = table1.querySelectorAll("tr"),//获取所有记录
                    length= numberRowsInTable1.length,//记录总条数
                    pageSize1 = 10, //每页显示的记录条数 
                    currentRow1,
                    maxRow1,
                    page = 1; //当前页，默认第一页 
                    spanPre1.onclick=pre1;
                    spanNext1.onclick=next1;
                function next1(){
                    if(page<pageCount1()){
                        hideTable1();
                        currentRow1=page*pageSize1;
                        maxRow1=currentRow1+pageSize1;
                        if (maxRow1>length) maxRow1=length;
                        for (var i = currentRow1; i < maxRow1; i++) {
                            numberRowsInTable1[i].style.display="";
                        }
                        page++;
                        if (page==pageCount1()) {
                            nextText1();
                        }else{
                            nextLink1();
                        }
                    }
                
                    prelLink1();
                    showPage1();
                }
                function pre1(){
                    if(page>1){
                        hideTable1();
                        page--;
                        maxRow1=page*pageSize1;
                        currentRow1=maxRow1-pageSize1;
                        if (currentRow1<0) currentRow1=0;
                        for (var i = currentRow1; i < maxRow1; i++) {
                            numberRowsInTable1[i].style.display="";
                        }
                        if (currentRow1==0) {
                            preText1();
                        }else{
                            prelLink1();
                        }
                    }
                
                        nextLink1();
                        showPage1();
                
                
                }
                function prelLink1(){
                    spanPre1.className="btn";
                }
                function preText1(){
                    spanPre1.className="btn on";
                }
                function nextLink1(){
                    spanNext1.className="btn";
                }
                function nextText1(){
                    spanNext1.className="btn on";
                }
                function pageCount1(){
                    return Math.ceil(length/pageSize1);
                }
                function hideTable1(){
                    for (var i = 0; i < length; i++) {
                        numberRowsInTable1[i].style.display="none";
                    }
                }
                function showPage1(){
                    pageNum1.innerHTML=page;
                }
                function hide1(){
                    for (var i = pageSize1; i < length; i++){
                        numberRowsInTable1[i].style.display="none";
                    }
                    pageNum1.innerHTML=1;
                    totalPage1.innerHTML=pageCount1();
                    preText1();
                }
                hide1();

                $("#jump1").bind("click",function(){
                    var jumpPage=$("#jumpPage1 input").val();
                    hideTable1();
                    page=jumpPage;
                    currentRow1=(page-1)*pageSize1;
                    maxRow1=currentRow1+pageSize1;
                    if (maxRow1>length) maxRow1=length;
                    for (var i = currentRow1; i < maxRow1; i++) {
                        numberRowsInTable1[i].style.display="";
                    }
                    if (page==pageCount1()) {
                        nextText1();
                    }else{
                        nextLink1();
                    }
                    if (currentRow1==0) {
                        preText1();
                    }else{
                        prelLink1();
                    }
                    showPage1();

                })
            }


            function toTwo(num){
                return num<10?"0"+num:num;
            }
            function getLocalTime(date){
                return date.getFullYear()+"-"+toTwo(date.getMonth()+1)+"-"+toTwo(date.getDate())+" "+toTwo(date.getHours())+":"+toTwo(date.getMinutes());
            }

    })()
})