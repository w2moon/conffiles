$(document).ready(function(){
	(function(){
		var table = document.getElementById("table"),
			totalPage = document.getElementById("spanTotalPage"),//总页数
			pageNum = document.getElementById("spanPageNum"), //获取当前页<span> 
			spanPre = document.getElementById("spanPre"),//获取上一页<span> 
			spanNext = document.getElementById("spanNext"),//获取下一页<span> 
			numberRowsInTable = table.querySelectorAll("tr"),//获取所有记录
			length= numberRowsInTable.length,//记录总条数
		 	pageSize = 10, //每页显示的记录条数 
		 	currentRow,
		 	maxRow,
			page = 1; //当前页，默认第一页 
			spanPre.onclick=pre;
			spanNext.onclick=next;
		function next(){
			if(page<pageCount()){
				hideTable();
				currentRow=page*pageSize;
				maxRow=currentRow+pageSize;
				if (maxRow>length) maxRow=length;
				for (var i = currentRow; i < maxRow; i++) {
					numberRowsInTable[i].style.display="";
				}
				page++;
				if (page==pageCount()) {
					nextText();
				}else{
					nextLink();
				}
			}
		
			prelLink();
			showPage();
		}
		function pre(){
			if(page>1){
				hideTable();
				page--;
				maxRow=page*pageSize;
				currentRow=maxRow-pageSize;
				if (currentRow<0) currentRow=0;
				for (var i = currentRow; i < maxRow; i++) {
					numberRowsInTable[i].style.display="";
				}
				if (currentRow==0) {
					preText();
				}else{
					prelLink();
				}
			}
		
				nextLink();
				showPage();
		
		
		}
		function prelLink(){
			spanPre.className="btn";
		}
		function preText(){
			spanPre.className="btn on";
		}
		function nextLink(){
			spanNext.className="btn";
		}
		function nextText(){
			spanNext.className="btn on";
		}
		function pageCount(){
			return Math.ceil(length/pageSize);
		}
		function hideTable(){
			for (var i = 0; i < length; i++) {
				numberRowsInTable[i].style.display="none";
			}
		}
		function showPage(){
			pageNum.innerHTML=page;
		}
		function hide(){
			for (var i = pageSize; i < length; i++){
				numberRowsInTable[i].style.display="none";
			}
			pageNum.innerHTML=1;
			totalPage.innerHTML=pageCount();
			preText();
		}
		hide();

		$("#jump").bind("click",function(){
			var jumpPage=$("#jumpPage input").val();
			hideTable();
			page=jumpPage;
			currentRow=(page-1)*pageSize;
			maxRow=currentRow+pageSize;
			if (maxRow>length) maxRow=length;
			for (var i = currentRow; i < maxRow; i++) {
				numberRowsInTable[i].style.display="";
			}
			if (page==pageCount()) {
				nextText();
			}else{
				nextLink();
			}
			if (currentRow==0) {
				preText();
			}else{
				prelLink();
			}
			showPage();

		})

		$("#submit").bind("click",function(){
			table.innerHTML="";
			var userId=$("#user").val();
			if(!userId){
				alert("请输入用户ID");
			}else{
				$.ajax({
					type:"POST",
					url:"/queryMails",
					data:"id="+userId,
					success:function(result){
						if(!result){
							console.log("null");
						}else{
							for (var i = 0; i < result.length; i++) {
								var otr=document.createElement("tr");
								for (var j = 0; j < 6; j++) {
									var otd=document.createElement("td");
									var html;
									switch(j){
										case 0:
										html="<div>"+(i+1)+"</div>";
										break;
										case 1:
										html="<div>"+result[i].id+"</div>";
										break;
										case 2:
										html="<div>"+result[i].title+"</div>";
										break;
										case 3:
										html="<div>"+result[i].content+"</div>";
										break;
										case 4:
										var itemlist=JSON.parse(result[i].items);
										var h='<p class="itemlisth"><span class="l">物品ID</span><span class="c">数量</span><span class="r">领取状态</span></p>';
										
										for (var z = itemlist.length-1; z >=0;z--) {
											var b='<p class="itemlistd"><span class="l">'+itemlist[z].id+'</span><span class="c">'+itemlist[z].num+'</span><span class="r">'+itemlist[z].used+'</span></p>';
											h+=b;
										}
										html="<div>"+h+"</div>";
										break;
										case 5:
										html="<div>"+(result[i].read?"已读":"未读")+"</div>";
										break;
									}
									otd.innerHTML=html;
									otr.appendChild(otd);
								}
								table.appendChild(otr);
								numberRowsInTable = table.querySelectorAll("tr"),//获取所有记录
								length= numberRowsInTable.length,//记录总条数
		 						hide();
							}
						}
					}
				});
			}
		})


		$("#delBtn").click(function(){
			var id=$("#delete").val();
			var to=$("#user").val();
			$.ajax({
				type:'POST',
				url:'/queryMails/delete',
				data:'id='+id+"&to="+to,
				success:function(result){
					if(result){
						alert("删除成功");
					}else{
						alert("删除失败");
					}
					window.location.reload();
				}
			})
		})


	})()
})