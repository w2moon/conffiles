$(document).ready(function(){
	(function(){
		var table = document.getElementById("table"),
			totalPage = document.getElementById("spanTotalPage"),//总页数
			pageNum = document.getElementById("spanPageNum"), //获取当前页<span> 
			spanPre = document.getElementById("spanPre"),//获取上一页<span> 
			spanNext = document.getElementById("spanNext"),//获取下一页<span> 
			numberRowsInTable = table.querySelectorAll("tr"),//获取所有记录
			length= numberRowsInTable.length,//记录总条数
		 	pageSize = 2, //每页显示的记录条数 
		 	currentRow,
		 	maxRow,
			page = 1; //当前页，默认第一页 
			spanPre.onclick=pre;
			spanNext.onclick=next;
		function next(){
			if(page<pageCount()){
				hideTable();
				currentRow=page*pageSize;
				maxRow=currentRow+pageSize;
				if (maxRow>length) maxRow=length;
				for (var i = currentRow; i < maxRow; i++) {
					numberRowsInTable[i].style.display="";
				}
				page++;
				if (page==pageCount()) {
					nextText();
				}
			}
		
			prelLink();
			showPage();
		}
		function pre(){
			if(page>1){
				hideTable();
				page--;
				maxRow=page*pageSize;
				currentRow=maxRow-pageSize;
				if (currentRow<0) currentRow=0;
				for (var i = currentRow; i < maxRow; i++) {
					numberRowsInTable[i].style.display="";
				}
				if (currentRow==0) {
					preText();
				}
			}
		
				nextLink();
				showPage();
		
		
		}
		function prelLink(){
			spanPre.className="btn";
		}
		function preText(){
			spanPre.className="btn on";
		}
		function nextLink(){
			spanNext.className="btn";
		}
		function nextText(){
			spanNext.className="btn on";
		}
		function pageCount(){
			return Math.ceil(length/pageSize);
		}
		function hideTable(){
			for (var i = 0; i < length; i++) {
				numberRowsInTable[i].style.display="none";
			}
		}
		function showPage(){
			pageNum.innerHTML=page;
		}
		function hide(){
			for (var i = pageSize; i < length; i++){
				numberRowsInTable[i].style.display="none";
			}
			pageNum.innerHTML=1;
			totalPage.innerHTML=pageCount();
			preText();
		}
		hide();
		function getLocalTime(date){
			return date.getFullYear()+"-"+toTwo(date.getMonth()+1)+"-"+toTwo(date.getDate())+" "+toTwo(date.getHours())+":"+toTwo(date.getMinutes());
		}
		function toTwo(num){
			return num<10?"0"+num:num;
		}
		$("#refurbish").click(function(){
			window.location.reload();
		});
		$("#botton").bind("click", function () {
			var activityId=$("#activityId").val(),
				platform=$("#platform").val(),
			    startTime=new Date($("#startDate").val()).getTime(),
				endTime=new Date($("#endDate").val()).getTime(),
				goldDrops=$("#goldDrops").val(),
				serum=$("#serum").val(),
				drop1=$("#drop1").val(),
				drop2=$("#drop2").val(),
				drop3=$("#drop3").val(),
				chance1=$("#chance1").val(),
				chance2=$("#chance2").val(),
				chance3=$("#chance3").val();
			if (activityId=="") {
				alert("请输入ID");
			}else if(platform==""){
				alert("请输入版本号");
			}else if(startTime==""){
				alert("请输入开始时间");
			}else if(endTime==""){
				alert("请输入结束时间");
			}else if(startTime>endTime){
				alert("开始时间不能大于结束时间");
			}else{
				$.ajax({
					type:"POST",
					url:'limitTimeCustoms/find',
					data:"startTime="+startTime+"&endTime="+endTime+"&platform="+platform,
					success:function(result){
						if(result){
							alert("活动时间与"+result+"冲突");
						}else{
							$.ajax({
							    type: 'POST',
							    url: '/limitTimeCustoms',
							    data:{
									id:activityId,
									platform:platform,
									startTime:startTime,
									endTime:endTime,
									goldDrops:goldDrops,
									serum:serum,
									drop1:drop1,
									drop2:drop2,
									drop3:drop3,
									chance1:chance1,
									chance2:chance2,
									chance3:chance3
								},
								dataType:'json',
								success:function(data){
									if (data) {
										alert("添加成功");
										data.result.startTime = getLocalTime(new Date(parseInt(data.result.startTime)));
										data.result.endTime = getLocalTime(new Date(parseInt(data.result.endTime)));
										var otr=document.createElement("tr");
										for (var i=0; i<10; i++) {
											var otd=document.createElement("td");
											var html;
											switch(i){
												case 0:
												html="<div>"+data.result.id+"</div>";
												break;
												case 1:
												html="<div>"+data.result.platform+"</div>";
												break;
												case 2:
												html="<div>"+data.result.startTime+"</div>";
												break;
												case 3:
												html="<div>"+data.result.endTime+"</div>";
												break;
												case 4:
												html="<div>"+data.result.goldDrops+"</div>";
												break;
												case 5:
												html="<div>"+data.result.serum+"</div>";
												break;
												case 6:
												html="<div>"+data.result.drop1+"<br>"+data.result.chance1+"</div>";
												break;
												case 7:
												html="<div>"+data.result.drop2+"<br>"+data.result.chance2+"</div>";
												break;
												case 8:
												html="<div>"+data.result.drop3+"<br>"+data.result.chance3+"</div>";
												break;
												case 9:
												html="<div>删除</div>";
												break;
											}
											otd.innerHTML=html;
											otr.appendChild(otd);
										}
										otr.className=data.result.id;
										table.insertBefore(otr,table.firstChild);
										numberRowsInTable = table.querySelectorAll("tr"),//获取所有记录
										length= numberRowsInTable.length,//记录总条数
										hide();
										deleteLine();
									}else if(data.fail){
										alert("与活动"+data.fail+"时间重复");
									}else{
										alert("添加失败");
									}
									

								}


							});
						}
					}
				})
				
			}
		
		})

				deleteLine();
				function deleteLine(){
				var index;
    			var otd=document.querySelectorAll("#table tr td:last-child");
    				for (var i = 0; i < otd.length; i++) {
    					otd[i].index=i;
    					otd[i].onclick=function(){
    						index=this.index;
    						var flog=confirm("确定删除吗？");
    						if (flog) {
    							deleteAjax(this.parentNode.className,index);
    						}
    					}
    				}
    			}
    			function deleteAjax(id,index){
	    			$.ajax({
	    				type: 'GET',
					    url: '/limitTimeCustoms/delete',
					    data: 'id='+id,
					    success:function(data){
					    	if (data.result) {
					    		alert("删除成功");
					    		numberRowsInTable[index].parentNode.removeChild(numberRowsInTable[index]);
					    	} else {
					    		alert("删除失败");
					    	}
					    }
	    			})
    			
    			}
	})()
})
