var express = require('express');
var router = express.Router();
var db = require('../database/db');
var cdb = require('../database/createDataBase');
var path=require('path');
var fs = require('fs');
router.get('/',function(req, res, next) {

			// var currDir = path.normalize(req.query.dir),
	  //       fileName = req.query.name,
	  //       currFile = path.join(currDir,fileName),
	  //       fReadStream;

		var name=req.query.name,fReadStream;

		function splitStr(str){
    			var strs=new Array();
    				strs=str.split("/");
    			var	dir="",fileName="";
    			var obj={};
    				for (var i = 0; i < strs.length; i++){
    					dir=strs[0]+"/"+strs[1]+"/";
    					fileName=strs[2];
    				}
    				obj={
    					fileName:fileName,
    					dir:dir
    				}
    			return obj;
    	}

    	
		cdb.getOne({id:name},function(result){
			if (result) {
				var currFile=result.download;
				var fileName=splitStr(currFile).fileName;
				console.log(fileName);
			} else {
				console.log("result not found");
			}

			fs.exists(currFile,function(exist) {
	        if(exist){
	            res.set({
	                "Content-type":"application/octet-stream",
	                "Content-Disposition":"attachment;filename="+encodeURI(fileName)
	            });
	            fReadStream = fs.createReadStream(currFile);
	            fReadStream.on("data",(chunk) => res.write(chunk,"binary"));
	            fReadStream.on("end",function () {
	                res.end();
	            });
	        }else{
	            res.set("Content-type","text/html");
	            res.send("file not exist!");
	            res.end();
	        }
	    });

	});
});


module.exports = router;