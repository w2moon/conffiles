var express = require('express');
var router = express.Router();
var filter = require('./filter');
var db=require('../database/db');
var cdb=require('../database/dataBase');
var multer = require('multer');
var path = require('path');

/* GET users listing. */
router.get('/',filter.authorize, function(req, res, next) {
	cdb.sortData("globalMail",{},{startTime:1},function(data){
		if (data){
			for (var i = 0; i < data.length; i++) {
				data[i].startTime=getLocalTime(new Date(parseInt(data[i].startTime)));
				data[i].endTime=getLocalTime(new Date(parseInt(data[i].endTime)));
				if (data[i].mailType=="gifts") {
					data[i].items=JSON.parse(data[i].items);
					data[i].type="礼包邮件";
				}else{
					data[i].type="公告邮件";
					data[i].filename=getFileName(data[i].items)
				}
				
			}
		}else{
			data=[];
		}
		console.log(data);
		res.render("globalMail",{title:"全局邮件",result:data,mongodBackup:req.session.mongodBackup,queryMails:req.session.queryMails,loginAward:req.session.loginAward,dataStatistics:req.session.dataStatistics,globalMail:req.session.globalMail,userId:req.session.userId,user:req.session.user_id,inspect:req.session.inspect,limitPass:req.session.limitPass,grantCode:req.session.grantCode,transactionRecord:req.session.transactionRecord,sendMail:req.session.sendMail});
	})
	function toTwo(num){
    	return num<10?"0"+num:num;
		}
	function getLocalTime(date) {
   			return date.getFullYear()+"-"+toTwo(date.getMonth()+1)+"-"+toTwo(date.getDate())+" "+toTwo(date.getHours())+":"+toTwo(date.getMinutes());     
		}

});
router.post('/',function(req,res,next){
	var obj={};
	for(var i in req.body){
		obj[i]=req.body[i];
	}
	obj.id=getId(7);
	obj.startTime=parseInt(obj.startTime);
	obj.endTime=parseInt(obj.endTime);
	cdb.insertData("globalMail",obj,function(result){
		if(result){
			res.send(obj);
		}else{
			res.send("");
		}
	})

	function kc(){
		var keys = ['a','b','c','d','e','f','g','h','k','m','n','p','q','r','s','t','u','v','w','x','y','z','1','2','3','4','5','6','7','8','9'];
	    return keys[Math.floor(Math.random()*keys.length)];
	};
	function getId(num){
	    var str = "e";
	    for(var i=0;i<num;++i){
	        str += kc();
	    }
	    return str;

	};

})

router.get('/delete',function(req,res,next){
	var id=req.query.id;
	cdb.delCampaign("globalMail",{id:id},function(result){
		if(result){
			res.send({result:true});
		}else{
			res.send({result:false});
		}
	})
})

router.post('/find',function(req,res,next){
	var id=req.body.id;
		cdb.getOne("globalMail",{id:id},function(data){
			if (data){
				res.send(data);
			}else{
				res.send("");
			}
		})
})

router.post('/update',function(req,res,next){
	var obj={};
		for(var i in req.body){
			obj[i]=req.body[i];
		}
	obj.startTime=parseInt(obj.startTime);
	obj.endTime=parseInt(obj.endTime);
	cdb.updateMail(obj,function(result){
		if(result){
			res.send({result:true});
		}else{
			res.send({result:false});
		}
		
	})
})

router.get('/sendNum',function(req,res,next){
	var SendMode=req.query.SendMode;
	cdb.findData("emails",{SendMode:SendMode},function(result){
		if(result){
			var num=result.length
			res.send({result:num});
		}else{
			res.send({result:0});
		}
	})
})

var storage = multer.diskStorage({
 destination: function (req, file, cb) {
  cb(null, path.resolve('./images/'));
 },
 filename: function (req, file, cb) {
  cb(null, file.originalname);
 }
});
var upload = multer({storage: storage});

router.post('/uploadImg',upload.single('avatar'),function(req, res, next) {
		if (req.file){
			res.send(req.file.originalname);
			console.log("success");
		}else{
			res.send(null);
			console.log("error");
		}
});

function getFileName(path){
	var pos1 = path.lastIndexOf('/');
	var pos2 = path.lastIndexOf('\\');
	var pos  = Math.max(pos1, pos2)
	if( pos<0 ){
		return path;
	}else{
		return path.substring(pos+1);
	}
}

module.exports = router;

