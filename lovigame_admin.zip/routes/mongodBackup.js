var express = require('express');
var router = express.Router();
var filter = require('./filter');
var cf=require('../config');
var join = require('path').join;
var cdb = require('../database/dataBase');
var db = require('../database/db');
var exec = require("child_process").exec;
// var mb=require('../mongodBackup');
var timingBackup=require('../database/timingBackup');
// var bJ=require('../dataBackup/timing_data/backupJson');


var path = require('path');
var multer=require('multer');
var upload = multer({storage:multer.memoryStorage()});
var fs = require("fs");
var zip = require("node-native-zip");
var fstream=require('fstream');
var tar=require('tar');
var zlib=require('zlib');
var unzip = require("unzip");
var CombinedStream = require('combined-stream');

var archiver = require('archiver');
var Stream = require('stream');


/* GET users listing. */
router.get('/',filter.authorize,function(req, res, next) {
	var obj={};
	var data=[];
	var timingData=[];
	var path=cf.mongodBackup.storagePath;
	var timingPath=cf.mongodBackup.storagePath_timing;
	var dataBaseName=cf.Db;
	var dayBtn,workBtn,dayTxt,workTxt,ftbk,mb,bJ,delTxt,delBtn;
	var totalSize=0;
	var timing_config="./dataBackup/timing_data/config.json";
	var bjPath="./dataBackup/timing_data/backupJson.json";
	var delPath="./dataBackup/timing_data/autoDelete.json";
	var mbPath="./mongodBackup.json";
	if (!fs.existsSync(timingPath)) {
            fs.mkdirSync(timingPath);
        }
	// var cfgJson=cfg;
	fs.readFile(timing_config,'utf-8', function(err,cfgStr){
		if(err){ 
		  console.log(err);
		  return; 
		}else{
			var cfgJson=JSON.parse(cfgStr);
			fs.readFile(delPath,'utf-8', function(err,delStr){
				fs.readFile(bjPath,'utf-8', function(err,bjStr){
					fs.readFile(mbPath,'utf-8', function(err,mbStr){
						var bJ=JSON.parse(bjStr);
						var mb=JSON.parse(mbStr);
						for (var key in mb) {
					obj={
						id:mb[key].id,
						dataName:mb[key].dataName,
						time:getLocalTime(new Date(mb[key].time))
					}
					data.push(obj);
					}
					for(var k in bJ){
						obj={
							id:bJ[k].id,
							dataName:bJ[k].dataName,
							size:getFileSize(timingPath+"/"+bJ[k].id),
							time:getLocalTime(new Date(bJ[k].time))
						}
						timingData.push(obj);
					}
					if(!(cfgJson.backup)){
						dayBtn="开始备份";
						workBtn="开始备份";
						dayTxt="";
						workTxt="";
					}else if((cfgJson.work)<0){
						dayBtn="停止备份";
						workBtn="开始备份";
						dayTxt="备份中(每天 "+cfgJson.time+")";
						workTxt="";
					}else{
						var work;
						dayBtn="开始备份";
						workBtn="暂停备份";
						dayTxt="";
						cfgJson.work==0?work="日":work=cfgJson.work;
						workTxt="备份中(每周"+work+" "+cfgJson.time+")";
					}
					
					delJson=JSON.parse(delStr);
					if(delJson.delNum<0){
						delBtn="开始运行";
						delTxt="";
					}else{
						delBtn="暂停运行";
						delTxt="运行中(删除"+delJson.delNum+"天前数据)";
					}
					ftbk={
						dayBtn:dayBtn,
						workBtn:workBtn,
						dayTxt:dayTxt,
						workTxt:workTxt,
						dataBaseName:dataBaseName,
						delTxt:delTxt,
						delBtn:delBtn
					}
					var pathAndSize=timingPath+"  备份数据库总长度: "+totalSize+" Mb";
						res.render("mongodBackup",{title:"数据库备份",cfg:ftbk,result:data,timingData:timingData,path:path,mongodBackup:req.session.mongodBackup,loginAward:req.session.loginAward,dataStatistics:req.session.dataStatistics,timingPath:pathAndSize,userId:req.session.userId,queryMails:req.session.queryMails,globalMail:req.session.globalMail,user:req.session.user_id,inspect:req.session.inspect,limitPass:req.session.limitPass,grantCode:req.session.grantCode,transactionRecord:req.session.transactionRecord,sendMail:req.session.sendMail});
					})
					})
					})
					
				}
			})
		
	function toTwo(num){
		return num<10?"0"+num:num;
	}
	function getLocalTime(date){
		return date.getFullYear()+"-"+toTwo(date.getMonth()+1)+"-"+toTwo(date.getDate())+" "+toTwo(date.getHours())+":"+toTwo(date.getMinutes());
	}
	
	function getFileSize(path) { 
	    var size=0;
	    work(path);
	    function work(fPath){
	    	var files = fs.readdirSync(fPath);//需要用到同步读取
	    	files.forEach(function(file, index) {  
				var states = fs.statSync(fPath + '/' + file);  
		        if (states.isDirectory()) {  
		            work(fPath + '/' + file);  
		        }else{
		            size += states.size;//文件大小，以字节为单位
		        }
			});
	    }
	    var s=parseFloat((size/(1024*1024)).toFixed(2));
	    totalSize+=s;
	    return s;
	} 


});




router.post('/',function(req,res,next){
	var dataName=req.body.dataName;
	var time=new Date().getTime();
	var id=dataName+"_"+getDateTime(new Date(time));
	var mbPath="./mongodBackup.json";
	var cmds=[
		"mongodump -h "+cf.mongodBackup.serverAddress+" -d "+dataName+" -o "+cf.mongodBackup.storagePath+"/"+id
	]
	var index = 0;
	
	var doCmd = function(index){
		var cmd = cmds[index];
	 try{
			console.log(cmd,"start");
			exec(cmd,function(err){
				if(err){
					console.log(cmd,err);
					res.send({result:false});
					return;
				}
				else{
					console.log(cmd,"complete");
					console.log("");
					console.log("===========================================");
					index++;
					if(index <= cmds.length && cmds[index]){
	
						doCmd(index);
					}
					else{
						console.log("all complete");
						var obj;
						fs.readFile(mbPath,'utf-8', function(err,mbStr){
							obj=JSON.parse(mbStr);
							obj[id]={
								id:id,
								dataName:dataName,
								"time":time
							};
							var objStr = JSON.stringify(obj);
							
						   	// 写入文件
						   	fs.writeFile(mbPath, objStr,function(err){
							if(!err){
								console.log("success");
								res.send({result:obj});
							}else{
								console.log(err);
								res.send({result:false});
							}
						   });
						})
					}
	
				}
	
			}).stdout.on('data',function(msg){
				 console.log(msg);
			});
		}
		catch(e){
			console.log(e);
			res.send({result:false});
			return;
		}
	
	}
	doCmd(index);


	function toTwo(num){
		return num<10?"0"+num:num;
	}
	function getDateTime(date){
		return date.getFullYear()+""+toTwo(date.getMonth()+1)+""+toTwo(date.getDate())+""+toTwo(date.getHours())+""+toTwo(date.getMinutes());
	}


	

})

router.post('/delete',function(req,res,next){
	var id=req.body.id;
	var table=req.body.table;
	var path,writePath,obj,objStr,mb,bJ;
	var bjPath="./dataBackup/timing_data/backupJson.json";
	var mbPath="./mongodBackup.json";

	fs.readFile(bjPath,'utf-8', function(err,bjStr){
		fs.readFile(mbPath,'utf-8', function(err,mbStr){
			mb=JSON.parse(mbStr);
			bJ=JSON.parse(bjStr);
			// 写入文件
		    if(table=="1"){
		   		path=cf.mongodBackup.storagePath+"/"+id;
		   		writePath=mbPath;
		   		obj=mb;
		    }else if(table=="2"){
		   		path=cf.mongodBackup.storagePath_timing+"/"+id;
		   		writePath=bjPath;
		   		obj=bJ;
		  	}
		   	delete obj[id];
		   	objStr = JSON.stringify(obj);
		   	fs.writeFile(writePath, objStr,function(err){
				if(!err){
					console.log("success");
					deleteall(path);
					res.send({result:obj});
				}else{
					console.log(err);
					res.send({result:false});
				}
		   });
		})
	})


	
   

	
	function deleteall(path){
		var files = [];  
		if(fs.existsSync(path)){  
			files = fs.readdirSync(path);  
			files.forEach(function(file, index) {  
				var curPath = path + "/" + file;  
				if(fs.statSync(curPath).isDirectory()) {  
					deleteall(curPath);
				}else{ 
					fs.unlinkSync(curPath);  
				}  
			});  
			fs.rmdirSync(path); 
		}  
	};


})

router.post('/recover',function(req,res,next){
	var id=req.body.id;
	var table=req.body.table;
	var file_path,obj,flog,bJ,mb;
	var bjPath="./dataBackup/timing_data/backupJson.json";
	var mbPath="./mongodBackup.json";

	fs.readFile(bjPath,'utf-8', function(err,bjStr){
		fs.readFile(mbPath,'utf-8', function(err,mbStr){
			mb=JSON.parse(mbStr);
			bJ=JSON.parse(bjStr);
			if(table=="1"){
				obj=mb;
				flog = findSync(cf.mongodBackup.storagePath,id);
				file_path=cf.mongodBackup.storagePath+"/"+id;
			}else if(table=="2"){
				obj=bJ;
				flog = findSync(cf.mongodBackup.storagePath_timing,id);
				file_path=cf.mongodBackup.storagePath_timing+"/"+id;
			}
			if(obj[id] && flog){
				var cmd="mongorestore --drop -h "+cf.mongodBackup.serverAddress+" -d "+obj[id].dataName+" "+file_path+"/"+obj[id].dataName;
				console.log(cmd,"start");
				exec(cmd,function(err){
					if(err){
						console.log(cmd,err);
						res.send({result:false});
						return;
					}
					else{
						console.log(cmd,"complete");
						res.send({result:true});
					}

				})
			}else{
				res.send({result:false});
			}

		})
	})


})

router.get('/download',function(req,res,next){
		var id=req.query.id;
		var table=req.query.table;
		var path,flog;

		if(table=="1"){
			path=cf.mongodBackup.storagePath+"/"+id;
			flog = findSync(cf.mongodBackup.storagePath,id);
		}else{
			path=cf.mongodBackup.storagePath_timing+"/"+id;
			flog = findSync(cf.mongodBackup.storagePath_timing,id);
		}

		if (flog){
			var archive = archiver('zip',{
			  	zlib:{level:9}
			  });
			var mongodbName = addfile(path);
			res.set({
		            "Content-type":"application/octet-stream",
		            "Content-Disposition":"attachment;filename="+encodeURI(mongodbName+".zip")
			        });
			       
			var ts = new Stream;
				ts.readable =true;
				ts.writable = true;
				ts.write = function (buff){
					res.write(buff);
				}
				ts.end=function(buf){
				  	res.end();
				}


			  archive.on('warning', function(err) {
				  if (err.code === 'ENOENT') {
				    // log warning
				  } else {
				    // throw error
				    console.log(err);
				  }
				});
			  archive.on('error', function(err){
			      console.log(err);
			      return;
			  });
			
			 archive.pipe(ts);
			archive.finalize();
		}
	 
		function addfile(startPath) {
		    var fileName="freshbody_demo";
		    function finder(path) {
		        var files=fs.readdirSync(path);
		        files.forEach((val,index) => {
		            var fPath=join(path,val);
		            var stats=fs.statSync(fPath);
		            if(stats.isDirectory()){
		            	fileName=val;
		            	finder(fPath);
		            };
		            if(stats.isFile()){
		            	archive.file(fPath, { name:val});
		            };
		        });

		    }
		    finder(startPath);
		    return fileName;
		}


})




router.post('/upLoadFile',upload.single('avatar'),function(req,res,next){
	if (req.file){
		var time=new Date().getTime();
		var filename=req.file.originalname;
		var buffer=req.file.buffer;
		var dataName=filename.split(".")[0];
		var id=dataName+"_"+getlocalTime(new Date(time));
		var fp=cf.mongodBackup.storagePath+"/"+id;
		var baseUrl=fp+"/"+dataName;
		var mbPath="./mongodBackup.json";
		var obj;
		if (!fs.existsSync(fp)) {
			fs.mkdirSync(fp);
		}
		if (!fs.existsSync(baseUrl)) {
			fs.mkdirSync(baseUrl);
		}
		
		var combinedStream = CombinedStream.create();

		combinedStream.append(buffer);
		combinedStream.pipe(unzip.Extract({path:baseUrl}));

		
		fs.readFile(mbPath,'utf-8', function(err,mbStr){
			obj=JSON.parse(mbStr);
			obj[id]={
				id:id,
				dataName:dataName,
				time:time
			}
			var objStr = JSON.stringify(obj);
							
			   // 写入文件
			fs.writeFile("./mongodBackup.json", objStr,function(err){
				if(!err){
					console.log("success");
					res.send({result:true});
				}else{
					console.log(err);
					res.send({result:false});
				}
			});

		})

	}else{
		console.log("error");
		res.send({result:false});
	}
})

router.post('/fixTimeBackup',function(req,res,next){
	var obj={};
	for(var k in req.body){
		obj[k]=req.body[k];
	}

	obj.work=parseInt(obj.work);
	obj.backup==="true"?obj.backup=true:obj.backup=false;
	var objStr = JSON.stringify(obj);	
	   // 写入文件
	fs.writeFile("./dataBackup/timing_data/config.json",objStr,function(err){
		if(err){
			console.log(err);
			return;
		}

		timingBackup.dataBackup(obj,function(result){})
		if(!obj.backup){
			res.send({result:false});
		}else if(obj.work<0){
			res.send({result:"day"});
		}else{
			res.send({result:"work"});
		}

	});
})
router.post('/autoDel',function(req,res,next){
	var delNum=parseInt(req.body.delNum);
		timingBackup.autoDelete({delNum:delNum});
		res.send({result:delNum});
})


	function toTwo(num){
		return num<10?"0"+num:num;
	}
	function getlocalTime(date){
		return date.getFullYear()+""+toTwo(date.getMonth()+1)+""+toTwo(date.getDate())+""+toTwo(date.getHours())+""+toTwo(date.getMinutes());
	}

	function findSync(path,fname) {
			var result=false;
			var files=fs.readdirSync(path);
			files.forEach((val,index) => {
				// var file_name=fPath.replace(/(.*\/)*([^.]+).*/ig,"$2");
				if(val==fname){
					result=true;
				}
			});
			return result;
	}

	function getfileName(filename){
		var rgExp=/(.*\/)*([^.]+).*/ig;
		var id=filename.match(rgExp);
		return id;
	}

	function fileList(startPath) {
	    var result=[];
	    var filepath;
	    var object;
	    var zipname;
	    function finder(path) {
	        var files=fs.readdirSync(path);
	        files.forEach((val,index) => {
	            var fPath=join(path,val);
	            var stats=fs.statSync(fPath);
	            if(stats.isDirectory()){
	            	filepath=fPath;
	            	zipname=val;
	            	finder(fPath);
	            };
	            if(stats.isFile()){
	            	var obj={
	            		name:val,
	            		path:filepath+"/"+val
	            	};
	            	result.push(obj);
	            };
	        });

	    }
	    finder(startPath);
	    object={
	    	zipname:zipname,
	    	result:result
	    }
	    return object;
	}

	


module.exports = router;

