var express = require('express');
var router = express.Router();
var filter = require('./filter');
var cdb = require('../database/dataBase');

/* GET users listing. */
router.get('/',filter.authorize,function(req, res, next){
	cdb.findAllDailyGift(function(result){
		if(!result){
			result=[];
		}else{
			for (var i = 0; i < result.length; i++) {
				if(result[i].payPre){
					result[i].payPre=JSON.parse(result[i].payPre);
				}else{
					result[i].payPre=[];
				}
				if(result[i].payAft){
					result[i].payAft=JSON.parse(result[i].payAft);
				}else{
					result[i].payAft=[];
				}
				
			}
			console.log("result",result)
		}
		res.render("loginAward",{title:"登录奖励",result:result,mongodBackup:req.session.mongodBackup,userId:req.session.userId,loginAward:req.session.loginAward,dataStatistics:req.session.dataStatistics,queryMails:req.session.queryMails,globalMail:req.session.globalMail,user:req.session.user_id,inspect:req.session.inspect,limitPass:req.session.limitPass,grantCode:req.session.grantCode,transactionRecord:req.session.transactionRecord,sendMail:req.session.sendMail});
	})
  	
});

router.post('/save',function(req,res,next){
	var obj={};
	for(var t in req.body){
		obj[t]=req.body[t];
	}
	console.log(obj);
	obj.id=parseInt(obj.id);
	cdb.upDailyGift(obj,function(result){
		if(result){
			res.send(true);
		}else{
			res.send(false);
		}
	})
})

router.post('/pt',function(req,res,next){
	var obj={};
	for(var t in req.body){
		obj[t]=req.body[t];
	}
	console.log(obj);
	obj.id=parseInt(obj.id);
	cdb.upPt(obj,function(result){
		if(result){
			res.send(true);
		}else{
			res.send(false);
		}
	})
})

router.post('/remove',function(req,res,next){
	var obj={};
	for(var t in req.body){
		obj[t]=req.body[t];
	}
	obj.id=parseInt(obj.id);
	cdb.deleteDailyGift(obj,function(result){
		if(result){
			res.send(true);
		}else{
			res.send(false);
		}
	})
})
module.exports = router;
