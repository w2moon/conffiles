var express = require('express');
var router = express.Router();
var filter = require('./filter');
var cdb = require('../database/dataBase');
var db = require('../database/db');
var async=require('async');
var excel=require('./excel');
var multer=require('multer');

/* GET users listing. */
router.get('/',filter.authorize,function(req, res, next){
  	res.render("dataStatistics",{title:"数据统计",userId:req.session.userId,mongodBackup:req.session.mongodBackup,loginAward:req.session.loginAward,dataStatistics:req.session.dataStatistics,queryMails:req.session.queryMails,globalMail:req.session.globalMail,user:req.session.user_id,inspect:req.session.inspect,limitPass:req.session.limitPass,grantCode:req.session.grantCode,transactionRecord:req.session.transactionRecord,sendMail:req.session.sendMail});
});
router.post('/',function(req,res,next){
	var obj={};
	for(var i in req.body){
		obj[i]=req.body[i];
	}
	obj.startTime=parseInt(obj.startTime);
	obj.endTime=parseInt(obj.endTime);
	if(obj.selectVal=="retention"){
		res.send("");
	}else if(obj.selectVal=="newUser"){
		cdb.findNewRoles(obj,function(result){
			if(result){
				var arr=[];
				var hash={};
				var date=[];
				var index=0;
				for (var i = 0; i < result.length; i++){
					var dataTime=getLocalTime(new Date(result[i].time));
					if(hash[dataTime]){
						hash[dataTime]++;
					}else{
						hash[dataTime]=1;
					}
				}
				for (var t = obj.startTime; t < obj.endTime; t+=86400000) {
					var times=getLocalTime(new Date(t));
						date[index]=times;
						index++;

				}
				for (var i = 0; i < date.length; i++){
					if(hash[date[i]]){
						arr[i]=hash[date[i]];
					}else{
						arr[i]=0;
					}
				}
				res.send({arr:arr,date:date});
			}else{
				res.send(null);
			}
		})
	}else if(obj.selectVal=="loginUser"){
		var arr=[];
		var date=[];
		var index=0;
		var hash={};
		// var tn=(obj.endTime-obj.startTime+1)/86400000;
		for (var t = obj.startTime; t < obj.endTime; t+=86400000) {
				var times=getLocalTime(new Date(t));
					date[index]=times;
					index++;

			}

		cdb.findRoles1({time:obj.endTime,platform:obj.platform},function(result,t){
			if(result){
				console.log("result",result);
				for (var j = obj.startTime; j < obj.endTime; j+=86400000) {
					var tim=getLocalTime(new Date(j));
					for (var i = 0; i < result.length; i++) {
						if (result[i].time<=j){
							hash[tim]?(hash[tim]++):hash[tim]=1;
						}
					}
					
				}
				console.log(hash);
				for (var i = 0; i < date.length; i++) {
					if(hash[date[i]]){
						arr[i]=hash[date[i]];
					}else{
						arr[i]=0;
					}
					}
					res.send({arr:arr,date:date});
			}
			
		})



	}else if(obj.selectVal=="nextDayRemain"){
		var arr=[];
		var date=[];
		var index=0;
		var hash={};
		for (var t = obj.startTime; t < obj.endTime; t+=86400000){
				var times=getLocalTime(new Date(t));
					date[index]=times;
					index++;
			}

		var data={
			startTime:obj.startTime,
			endTime:obj.endTime,
			platform:obj.platform
		}
		db.findAccT(data,function(result){
			if (result){
				nextDayRemain(result);
			}else{
				res.send("");
			}
		})
		function nextDayRemain(result){
			for (var i = 0; i < result.length; i++) {
				var tim=getLocalTime(new Date(result[i].regTime));
				var dif=result[i].t-result[i].regTime;
					if (hash[tim]){
						hash[tim].total++;
					}else{
						hash[tim]={
							nr:0,
							total:1
						}
					}
					if(dif>=86400000){
					hash[tim].nr++;
				}
			}

			for (var n = 0; n < date.length; n++) {
				if(hash[date[n]]){
					arr[n]=parseFloat(((hash[date[n]].nr/hash[date[n]].total)*100).toFixed(2));
				}else{
					arr[n]=0;
				}
			}
			console.log("hash",hash);
			res.send({arr:arr,date:date});

		}

	}else if(obj.selectVal=="sevenDayRemain"){
		var arr=[];
		var date=[];
		var index=0;
		var hash={};
		for (var t = obj.startTime; t < obj.endTime; t+=86400000){
				var times=getLocalTime(new Date(t));
					date[index]=times;
					index++;
			}

		var data={
			startTime:obj.startTime,
			endTime:obj.endTime,
			platform:obj.platform
		}
		db.findAccT(data,function(result){
			if (result){
				sevenDayRemain(result);
			}else{
				res.send("");
			}
		})
		function sevenDayRemain(result){
			for (var i = 0; i < result.length; i++) {
				var tim=getLocalTime(new Date(result[i].regTime));
				var dif=result[i].t-result[i].regTime;
					if (hash[tim]){
						hash[tim].total++;
					}else{
						hash[tim]={
							nr:0,
							total:1
						}
					}
					if(dif>=(86400000*7)){
					hash[tim].nr++;
				}
			}

			for (var n = 0; n < date.length; n++) {
				if(hash[date[n]]){
					arr[n]=parseFloat(((hash[date[n]].nr/hash[date[n]].total)*100).toFixed(2));
				}else{
					arr[n]=0;
				}
			}
			console.log("hash",hash);
			res.send({arr:arr,date:date});

		}

	}else if(obj.selectVal=="activeUser"){
		var arr=[];
		var date=[];
		var index=0;
		var hash={};
		for (var t = obj.startTime; t < obj.endTime; t+=86400000){
			var times=getLocalTime(new Date(t));
				date[index]=times;
				index++;
		}
		var data={
				startTime:obj.startTime,
				endTime:obj.endTime,
				platform:obj.platform
			}
			cdb.findLog(data,function(result){
				if (result){
					activeUsers(result);
				}else{
					res.send("");
				}
			})
			function activeUsers(result){
				for (var i = 0; i < result.length; i++) {
					var tt=getLocalTime(new Date(result[i].time));
						if(hash[tt]){
							hash[tt]++;
						}else{
							hash[tt]=1;
						}
				}

				for (var i = 0; i < date.length; i++) {
					if(hash[date[i]]){
						arr[i]=hash[date[i]];
					}else{
						arr[i]=0;
					}
				}
				res.send({arr:arr,date:date});

			}


	}else if(obj.selectVal=="payUser"){
		var arr=[];
		var date=[];
		var index=0;
		var hash={};
		for (var t = obj.startTime; t < obj.endTime; t+=86400000){
			var times=getLocalTime(new Date(t));
				date[index]=times;
				index++;
		}

		var data={
			event:"buy",
			startTime:obj.startTime,
			endTime:obj.endTime,
			platform:obj.platform
		}
		cdb.findBuyUser(data,function(result){
			if (result){
				countUsers(result);
			}else{
				res.send("");
			}
		})

		function countUsers(result){
			for (var i = 0; i < result.length; i++) {
				var tt=getLocalTime(new Date(result[i].time));
				if(hash[tt]){
					hash[tt]++;
				}else{
					hash[tt]=1;
				}
			}

			for (var i = 0; i < date.length; i++) {
				if(hash[date[i]]){
					arr[i]=hash[date[i]];
				}else{
					arr[i]=0;
				}
			}
			res.send({arr:arr,date:date});

		}

	}else if(obj.selectVal=="rate"){
		var arr=[];
		var date=[];
		var index=0;
		var hash={};
		for (var t = obj.startTime; t < obj.endTime; t+=86400000){
			var times=getLocalTime(new Date(t));
				date[index]=times;
				index++;
		}
		var data={
				event:"buy",
				startTime:obj.startTime,
				endTime:obj.endTime,
				platform:obj.platform
			}
			cdb.findBuyUser(data,function(result){
				if (result){
					buyUser(result);
					var param={
						startTime:data.startTime,
						endTime:data.endTime,
						platform:data.platform
					}
					cdb.findLog(param,function(rt){
						if (rt){
							for (var i = 0; i < rt.length; i++) {
								var tt=getLocalTime(new Date(rt[i].time));
									hash[tt].total++;
							}
							for (var i = 0; i < date.length; i++) {
								if(hash[date[i]]){
									arr[i]=parseFloat((((hash[date[i]].buy)/(hash[date[i]].total))*100).toFixed(2));
								}else{
									arr[i]=0;
								}
							}
							res.send({arr:arr,date:date});
						}else{
							res.send("");
						}
					})
				}else{
					res.send("");
				}
			})

			function buyUser(result){
				for (var i = 0; i < result.length; i++) {
					var tt=getLocalTime(new Date(result[i].time));
					if (hash[tt]){
						hash[tt].buy++;
					}else{
						hash[tt]={
							buy:1,
							total:0
						}
					}
				}
			}

	}else if(obj.selectVal=="averagePay"){
		var arr=[];
		var date=[];
		var index=0;
		var hash={};
		for (var t = obj.startTime; t < obj.endTime; t+=86400000){
			var times=getLocalTime(new Date(t));
				date[index]=times;
				index++;
		}
		var data={
			event:"buy",
			startTime:obj.startTime,
			endTime:obj.endTime,
			platform:obj.platform
		}
		cdb.findBuyUser(data,function(result){
			if (result){
				countPays(result);
			}else{
				res.send("");
			}
		})
		function countPays(result){
			for (var i = 0; i < result.length; i++) {
				var tt=getLocalTime(new Date(result[i].time));
				var param=JSON.parse(result[i].params);
				var money=param.money;
					if (hash[tt]){
						hash[tt].people++;
						hash[tt].money += money;

					}else{
						hash[tt]={
							people:1,
							money:money
						}
					}
			}

			for (var i = 0; i < date.length; i++) {
				arr[i]=new Array();
				if(hash[date[i]]){
					arr[i]=parseFloat((hash[date[i]].money/hash[date[i]].people).toFixed(2));
				}else{
					arr[i]=0;
				}
			}
			res.send({arr:arr,date:date});
		}

		
	}else if(obj.selectVal=="onlineLength"){

		var arr=[];
		var date=[];
		var index=0;
		var hash={};
		var n=0;
		for (var t = obj.startTime; t < obj.endTime; t+=86400000){
			var times=getLocalTime(new Date(t));
				date[index]=times;
				index++;
		}
		var data={
			startTime:obj.startTime,
			endTime:obj.endTime,
			op:"logout",
			platform:obj.platform
		}
		cdb.findLog(data,function(result){
			if(result){
				onlineTime(result)
			}
		})
		function onlineTime(result){
			for (var i = 0; i < result.length; i++) {
				var tt=getLocalTime(new Date(result[i].time));
					if(hash[tt]){
						hash[tt]=hash[tt]+result[i].online;
					}else{
						hash[tt]=result[i].online;
					}
			}

			for (var j = 0; j < date.length; j++) {
				if(hash[date[j]]){
					arr[j]=parseFloat((hash[date[j]]/3600000).toFixed(2));
				}else{
					arr[j]=0;
				}
			}
				res.send({arr:arr,date:date});
		}

	}else if(obj.selectVal=="difficulty"){
		var arr=[];
		var date=[];
		var index=0;
		var hash={};
		for (var t = obj.startTime; t < obj.endTime; t+=86400000){
			var times=getLocalTime(new Date(t));
				date[index]=times;
				index++;
		}
		var params={
				startTime:obj.startTime,
				endTime:obj.endTime,
				platform:obj.platform,
				event:"newRole",
			}
			cdb.findEvent(params,function(result){
				if (result){
					addRole(result);
				}else{
					res.send("");
				}
			})
			function addRole(result){
				console.log("result",result);
				for (var i = 0; i < result.length; i++) {
					var tt=getLocalTime(new Date(result[i].time));
					var param,dif;
						if(hash[tt]){
							param=JSON.parse(result[i].params);
							dif=param.difficulty;
							hash[tt][dif]++;
						}else{
							hash[tt]={
								normal:0,
								easy:0,
								hard:0
							}
							param=JSON.parse(result[i].params);
							dif=param.difficulty;
							hash[tt][dif]++;

						}
				}

				for (var i = 0; i < date.length; i++) {
					arr[i]=new Array();
					if(hash[date[i]]){
						arr[i][0]=hash[date[i]].easy;
						arr[i][1]=hash[date[i]].normal;
						arr[i][2]=hash[date[i]].hard
					}else{
						arr[i][0]=0;
						arr[i][1]=0;
						arr[i][2]=0;
					}
					}
					res.send({arr:arr,date:date});

			}

	}else if(obj.selectVal=="gameDuration"){
		var arr=[];
		var date=[];
		var hash={};
		var max=0;
		var params={
			startTime:obj.startTime,
			endTime:obj.endTime,
			platform:obj.platform
		}
			db.findAccT(params,function(data){
				if (data){
					accStatis(data,5);
				}else{
					res.send("")
				}
			})
		function accStatis(data,n){
			var index=0;
			for (var i = 0; i < data.length; i++) {
				var t=Math.floor((Math.ceil(data[i].oL/3600000))/n);
				var m=t*5;
				var interval=m+"-"+(m+5);
				if(max<m) max=m;
				if(hash[interval]){
					hash[interval]++;
				}else{
					hash[interval]=1;
				}
			}
			for (var j = 0; j <= max; j+=5) {
				date[index]=j+"-"+(j+5);
				index++;
			}
			for (var i = 0; i < date.length; i++) {
				hash[date[i]]?arr[i]=hash[date[i]]:arr[i]=0;
			}
				res.send({arr:arr,date:date});
		}
	}else if(obj.selectVal=="teachingCompletion"){
		var arr=[];
		var date=[];
		var hash={};
		var max=0;
		var params={
			startTime:obj.startTime,
			endTime:obj.endTime,
			platform:obj.platform,
			event:"tutorial",
		}
		cdb.findEvent(params,function(data){
			if(data){
				tutorial(data);
			}else{
				res.send("");
			}
		})
		function tutorial(data){
			var index=0;
			for (var i = 0; i < data.length; i++) {
				var tutor=JSON.parse(data[i].params);
				var name=tutor.name;
				if(hash[name]){
					hash[name]++;
				}else{
					hash[name]=1;
				}
			}
			for(var atr in hash){
				arr.push(hash[atr]);
				date.push(atr);
			}
			res.send({arr:arr,date:date});
		}
	}else if(obj.selectVal=="PokedexUnlocked"){
		var arr=[];
		var date=[];
		var hash={};
		var role={};
		var excelJson=excel.excelToIDJson("./file/MonsterHandbook.xlsx");
		for(var atr in excelJson){
			if(hash[excelJson[atr].mapTag]){
				hash[excelJson[atr].mapTag].total++;
			}else{
				hash[excelJson[atr].mapTag]={};
				hash[excelJson[atr].mapTag].total=1;
				hash[excelJson[atr].mapTag].pass=0;
				date.push(excelJson[atr].mapTag);

			}
		}

		var params={
			startTime:obj.startTime,
			endTime:obj.endTime,
			platform:obj.platform
		}

		cdb.findUnlock(params,function(data){
			if(data){
				console.log("data",data);
				for (var i = 0; i < data.length; i++){
					var mapTag=data[i].mapTag;
					for (var j = 0; j < mapTag.length; j++) {
						if ((mapTag[j].unlock/hash[mapTag[j].map].total)>0.6){
							hash[mapTag[j].map].pass++;
						}
					}
				}
				for (var n = 0; n < date.length; n++) {
					arr.push(hash[date[n]].pass);
				}
				res.send({arr:arr,date:date});
			}else{
				res.send("");
			}
		})


	}else if(obj.selectVal=="enemyKillNum"){
		var arr=[];
		var date=[];
		var hash={};
		var mosRole=[];
		hash=excel.excelToIDJson("./file/MonstersList.xlsx");
		var params={
			startTime:obj.startTime,
			endTime:obj.endTime,
			platform:obj.platform,
			event:"kill"
		}
		cdb.findEvent(params,function(data){
			console.log(data)
			if(data){
				var index=0;
				var ratio=[];
				var total=data.length;
				for(var m in hash){
					hash[m].kill=0;
				}
				for (var i = 0; i < data.length; i++) {
					var mosJson=JSON.parse(data[i].params); 
						hash[mosJson.monster].kill++;
				}
				for(var atr in hash){
					mosRole[index]=[];
					mosRole[index][0]=atr;
					mosRole[index][1]=hash[atr].name;
					mosRole[index][2]=hash[atr].kill;
					index++;
				}
				mosRole.sort(function(a,b){
					return b[2]-a[2];
				})
				for(var i = 0; i < mosRole.length; i++){
					date[i]=mosRole[i][1];
					arr[i]=mosRole[i][2];
					ratio[i]=((mosRole[i][2]/total)*100).toFixed(2)+"%";
				}
				console.log("arr",arr);
				console.log("ratio",ratio);
				console.log("date",date);
				res.send({arr:arr,date:date,ratio:ratio})
			}else{
				res.send("");
			}
		})
	}else if(obj.selectVal=="reviveNum"){
		res.send("");
	}else if(obj.selectVal=="exitPosition"){
		res.send("");
	}else if(obj.selectVal=="buyThing"){
		var arr=[];
		var date=[];
		var index=0;
		var hash={};
		var commod={};
		var mul=[];
		var totalMoney=0;
		var goods=excel.excelToIDJson("./file/merchandise.xlsx");
		for (var t = obj.startTime; t < obj.endTime; t+=86400000){
			var times=getLocalTime(new Date(t));
				date[index]=times;
				index++;
		}
		var params={
			startTime:obj.startTime,
			endTime:obj.endTime,
			platform:obj.platform,
			event:"buy"
		}
		cdb.findEvent(params,function(data){
			if(data){
				var startT=obj.startTime;
				getSold(data,startT);
			}else{
				res.send("");
			}
		})
		function getSold(data,st){
			if (st<obj.endTime){
				countGoods(data,st);
			}else{
				for (var i = 0; i < date.length; i++) {
					if(hash[date[i]]){
						arr[i]=hash[date[i]];
					}else{
						arr[i]=0;
					}
				}
				for (var i = 0; i < arr.length; i++) {
					totalMoney+=arr[i];
				}
				detailed(data);
			}
		}
		function countGoods(data,st){
			for (var i = 0; i < data.length; i++) {
				if(data[i].time>=st && data[i].time<=(st+86400000)){
					var json=JSON.parse(data[i].params);
					var T=getLocalTime(new Date(data[i].time));
					if(hash[T]){
						hash[T]=hash[T]+json.money;
					}else{
						hash[T]=json.money;
					}
				}
			}
			getSold(data,st+86400000);
		}

		function detailed(data){
			var num=0;
			var buyJson=excel.excelToIDJson("./file/merchandise.xlsx");
			for(var atr in buyJson){
				buyJson[atr].money=0;
			}
			for (var i = 0; i < data.length; i++) {
				var json=JSON.parse(data[i].params);
					buyJson[json.id].money+=json.money;
			}
			for(var rs in buyJson){
				if(commod[buyJson[rs].type]){
					commod[buyJson[rs].type].money+=buyJson[rs].money;
				}else{
					commod[buyJson[rs].type]={};
					commod[buyJson[rs].type].typeName=buyJson[rs].typeName;
					commod[buyJson[rs].type].money=buyJson[rs].money;
				}
			}
			for(var ml in commod){
				mul[num]=[];
				mul[num][0]=commod[ml].typeName;
				mul[num][1]=((commod[ml].money/totalMoney)*100).toFixed(2)+"%";
				mul[num][2]=commod[ml].money;
				mul[num][3]=ml;
				num++;
			}
			mul.sort(function(a,b){
				return b[2]-a[2];
			});
			res.send({arr:arr,date:date,mul:mul,buyJson:buyJson,buyJson:buyJson});
		}

	}
})


var storage = multer.diskStorage({
    destination: function (req, file, callback) {
        callback(null,"./file");
    },
    filename: function (req, file, callback) {
        callback(null,file.originalname);
    }
});
var upload = multer({ storage: storage });

router.post('/upfile',upload.single('avatar'),function(req,res,next){
	if (req.file){
		res.send({result:true});
	}else{
		res.send({result:false});
	}
})

	function toTwo(num){
        	return num<10?"0"+num:num;
    		}
	function getLocalTime(date) {     
   			return date.getFullYear()+"-"+toTwo(date.getMonth()+1)+"-"+toTwo(date.getDate());     
		}
	function getLocalDate(date) {     
		return date.getFullYear()+"-"+toTwo(date.getMonth()+1)+"-"+toTwo(date.getDate())+" "+toTwo(date.getHours())+":"+toTwo(date.getMinutes());     
	 }
	 function countNum(result){
		var userArr=[];
		var json={};
		for (var i = 0; i < result.length; i++) {
			if (!json[result[i].id]){
				userArr.push(result[i]);
				json[result[i].id]=1;
			}
		}
		return userArr.length;
	}
module.exports = router;
