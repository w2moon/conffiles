var express = require('express');
var router = express.Router();
var cdb = require('../database/dataBase');

router.get('/', function(req, res, next) {
    var giftId=parseInt(req.query.giftId);
    var gifPrice=req.query.gifPrice;
    var user=req.query.user;
    cdb.getOne("giftPacks",{giftId:giftId},function(data){
        if(data){
            var time=new Date().getTime();
            var obj={
                giftId:giftId,
                gifName:data.gifName,
                gifPrice:gifPrice,
                user:user,
                time:time
            }
            cdb.insertData("transactionRecord",obj,function(result){
                if (result){
                    console.log("insert success");
                    res.send("insert success");
                }else{
                    console.log("insert error");
                    res.send("insert error");
                }
            });
            
        }else{
            console.log("not giftId");
            res.send("not giftId");
        }
    })
   

});

module.exports = router;