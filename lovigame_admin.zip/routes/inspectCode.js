var express = require('express');
var router = express.Router();
var filter = require('./filter');
var db = require('../database/db');
var cdb = require('../database/dataBase');
/* GET users listing. */
router.get('/',filter.authorize,function(req, res, next) {
  	res.render("inspectCode",{title:"inspectCode",userId:req.session.userId,mongodBackup:req.session.mongodBackup,loginAward:req.session.loginAward,dataStatistics:req.session.dataStatistics,queryMails:req.session.queryMails,globalMail:req.session.globalMail,user:req.session.user_id,inspect:req.session.inspect,limitPass:req.session.limitPass,grantCode:req.session.grantCode,transactionRecord:req.session.transactionRecord,sendMail:req.session.sendMail});
});
router.post('/',function(req, res, next) {
	var key=req.body.key;
	var status;
	cdb.getOne('cdkey',{id:key},function(data){
		if (data.used==1) {
			status="已使用";
		}else if(data.used==0){
			status="未使用"
		}else{
			status="未找到"
		}
		res.send({status:status,user:data.user,address:data.address});
	})

});
module.exports = router;

