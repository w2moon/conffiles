var express = require('express');
var router = express.Router();
var user = require('../database/user');
var cf=require('../config');

/* GET users listing. */
router.get('/',function(req, res, next) {
	var message={
		title:"login",
		userId:"admin",
		password:"admin"
	}
  res.render("login",message);
});
router.post('/', function(req, res, next) {
 var email=req.body.email;
 var password=req.body.password;
 var obj={
  email:email,
  password:password
 }
  user.findUser(obj,function(result){
  	if (result.email==email || result.password==password) {
        req.session.userId = result.userId;
        req.session.inspect = result.inspect;
        req.session.limitPass = result.limitPass;
        req.session.grantCode = result.grantCode;
        req.session.transactionRecord=result.transactionRecord;
        req.session.sendMail=result.sendMail;
        req.session.globalMail=result.globalMail;
        req.session.queryMails=result.queryMails;
        req.session.loginAward=result.loginAward;
        req.session.dataStatistics=result.dataStatistics;
        req.session.mongodBackup=result.mongodBackup;
        if (result.email===cf.admin){
          req.session.user_id = "admin";
        }else{
          req.session.user_id = result.email;
        }
        res.redirect("/index");
  	} else {
  		res.redirect("/login");
  	}
  		
  });
});



module.exports = router;

