var express = require('express');
var router = express.Router();
var filter = require('./filter');
var nodemailer = require('nodemailer');

/* GET users listing. */
router.get('/',filter.authorize, function(req, res, next) {
 	res.render("grantCode",{title:"grantCode",userId:req.session.userId,mongodBackup:req.session.mongodBackup,loginAward:req.session.loginAward,dataStatistics:req.session.dataStatistics,queryMails:req.session.queryMails,globalMail:req.session.globalMail,user:req.session.user_id,inspect:req.session.inspect,limitPass:req.session.limitPass,grantCode:req.session.grantCode,transactionRecord:req.session.transactionRecord,sendMail:req.session.sendMail});
});
router.post('/',function(req, res, next){
	var email=req.body['email'];
	var	key=req.body['key'];
	var	sendemail=req.body['sendemail'];
	var	accreditCode=req.body['accreditCode'];
	var	eTitle=req.body['eTitle'];
	var	eContent=req.body['eContent'];
	var mailTransport = nodemailer.createTransport({
		    service: 'qq',
		    // secureConnection: true,
		    auth: {
		        user : sendemail,
		        pass : accreditCode
		    }
		});

	var options = {
	    from: sendemail,
	    to: email,
	    subject: eTitle,
	    text: '',
	    html: '<h1>'+eContent+'你的兑换码为'+key+',请注意查收</h1>'
	    // html: '<h1>你好，这是一封来自NodeMailer的邮件！</h1><p><img src="./images/icon.png"/></p>',
	    // attachments: 
	    //       [
	    //         {
	    //           filename: 'img1.png',      
	    //           path: 'public/images/img1.png', 
	    //           cid : '00000001'         
	    //         },
	    //         {
	    //           filename: 'img2.png',      
	    //           path: 'public/images/img2.png', 
	    //           cid : '00000002'         
	    //         },
	    //       ]
	  };
	 
	  mailTransport.sendMail(options, function(err, msg){
	    if(err){
	      console.log(err);
	      res.send({result:false});
	    }
	    else {
	      console.log(msg);
	      // res.render('index', { title: "已接收："+msg.accepted});
	      res.send({result:true});
	    }
	  });


	
});
module.exports = router;

