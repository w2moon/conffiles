var express = require('express');
var router = express.Router();
var filter = require('./filter');
var cdb = require('../database/dataBase');
var db=require('../database/db');

/* GET users listing. */
router.get('/',filter.authorize,function(req, res, next) {
	db.allCampaign(function(err,result){
	  		if (!err && result) {
				  console.log("result",result);
				for (var i = 0; i < result.length; i++) {
					result[i].startTime=getLocalTime(new Date(parseInt(result[i].startTime)));
					result[i].endTime=getLocalTime(new Date(parseInt(result[i].endTime)));
				}
	  			console.log("findAll success");
	  		} else {
				result=[];
	  			console.log("findAll error");
	  		}
	  		// res.json(result);
	  		res.render("limitTimeCustoms",{userId:req.session.userId,mongodBackup:req.session.mongodBackup,loginAward:req.session.loginAward,dataStatistics:req.session.dataStatistics,queryMails:req.session.queryMails,result:result,globalMail:req.session.globalMail,user:req.session.user_id,inspect:req.session.inspect,limitPass:req.session.limitPass,grantCode:req.session.grantCode,transactionRecord:req.session.transactionRecord,sendMail:req.session.sendMail});
		  })
		  
		function getLocalTime(date){
			return date.getFullYear()+"-"+toTwo(date.getMonth()+1)+"-"+toTwo(date.getDate())+" "+toTwo(date.getHours())+":"+toTwo(date.getMinutes());
		}
		function toTwo(num){
			return num<10?"0"+num:num;
		}
});
router.post('/', function(req, res, next){
    var obj={};
	for (var i in req.body) {
		obj[i]=req.body[i];	
	}
		obj.startTime=parseInt(obj.startTime);
		obj.endTime=parseInt(obj.endTime);
		db.addCampaign(obj,function(err,result){
			if (!err && result) {
				res.send(JSON.stringify({result:obj}));
			}else{
				res.send("");
			}
			
		});
		

});

router.post('/find', function(req, res, next){
    var startTime=req.body.startTime;
	var endTime=req.body.endTime;
	var platform=req.body.platform;
	db.findCampaign({platform:platform},function(err,result){
		console.log(result);
		if (!err && result) {
			for(var i = 0; i < result.length; i++){
				if(startTime < result[i].endTime && endTime > result[i].startTime) {
					res.send(result[i].id);
					return;
				}
			}
			res.send(null);
		}else{
			res.send(null);
		}
	})
		

});

router.get('/delete',function(req, res, next) {
		var id=req.query.id;
			console.log(id);
			db.delCampaign({id:id},function(err,result){
				if (!err && result) {
					res.send({result:true});
				} else {
					res.send({result:false});
				}
			})
	});
module.exports = router;
