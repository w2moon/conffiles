var express = require('express');
var router = express.Router();
var db = require('../database/db');
var cdb = require('../database/createDataBase');
/* GET users listing. */
router.get('/',function(req, res, next) {
	var key='3fh6qv',id="jianxiongsg",userAddress='192.168.1.105';
	db.usekey(key,id,userAddress,function(err,info){
            if(err){

                res.send(JSON.stringify({result:false}));
            }
            else{

                res.send(JSON.stringify({result:true,info:info}));
            }

        })
	  	
});
module.exports = router;
