var express = require('express');
var router = express.Router();
var fs = require('fs');
router.get('/',function(req, res, next) {
			var fReadStream;
			// var currFile=req.query.filepath;
			// var fileName=req.query.name;
			var currFile='./emailMould/example.xlsx';
			var fileName='example.xlsx';
			console.log(currFile);
			console.log(fileName);
			fs.exists(currFile,function(exist) {
	        if(exist){
	            res.set({
	                "Content-type":"application/octet-stream",
	                "Content-Disposition":"attachment;filename="+encodeURI(fileName)
	            });
	            fReadStream = fs.createReadStream(currFile);
	            fReadStream.on("data",(chunk) => res.write(chunk,"binary"));
	            fReadStream.on("end",function () {
	                res.end();
	            });
	        }else{
	            res.set("Content-type","text/html");
	            res.send("file not exist!");
	            res.end();
	        }
	    });

	
});
module.exports = router;