var express = require('express');
var router = express.Router();
var db=require('../database/db');
var cdb=require('../database/dataBase');



router.get('/',function(req,res){
    //var obj = req.query;
var obj = {};
var nowTime=new Date().getTime();
console.log("nowTime",nowTime);
for(var k in req.query){
    obj[k] = req.query[k];
}

    obj.t = nowTime;
// console.log(obj);
db.log(obj);
var e = null;
var arr = obj.v.split(".");
if(obj.op == "login" && (arr.length < 3 || parseInt(arr[2]) <45)){
    e = "sys.openURL('http://store.steampowered.com/app/550840/');app.end();";//"wl.addSystemTips('试玩已经结束，请去steam下载最新版本.',function(){app.end();});"
}

if(obj.platform && obj.op=="login" || obj.op=="logout"){
    db.account(obj,function(accDat){
    var items = [];
    if(accDat){
        items = accDat.items;
    }
    var ip=req.connection.remoteAddress;
    var dR={
            id:obj.id,
            ip:ip,
            op:obj.op,
            v:obj.v,
            platform:obj.platform,
            time:nowTime
    }
    var logObj={
            id:obj.id,
            ip:ip,
            op:obj.op,
            v:obj.v,
            platform:obj.platform,
            time:nowTime,
            online:0
    }
    if (obj.op=="login"){
        cdb.findMails(function(data){
        if(data){
            for (var i = 0; i < data.length; i++) {
                var time=new Date().getTime(); 
                var result={
                    id:data[i].id,
                    to:obj.id,
                    sendUser:data[i].sendUser,
                    title:data[i].title,
                    content:data[i].content,
                    items:data[i].items,
                    SendMode:"auto",
                    time:time,
                    read:false
                };
                cdb.insertMails(result,function(flog){
                    if(flog){
                        console.log("success");
                    }else{
                        console.log("error");
                    }
                    loginEvent();
                })
            }
            }else{
                loginEvent()
            }
        });
    }else{
        logoutEvent();
    }
    


    

    function dailyRecord(){
        cdb.dailyRecord(logObj,function(result){
            findRole();
        });
    }
    function logoutEvent(){
        db.upAccountOl({id:obj.id,nt:nowTime},function(result){
            cdb.updateLog({id:obj.id,op:obj.op,time:nowTime},function(flog){
                findRole();
            })
        })
    }
    function loginEvent(){
        db.upAccountT({id:obj.id,t:obj.t},function(result){
            dailyRecord();
        })
    }
    function findRole(){
        cdb.findRoleOne({id:obj.id,platform:obj.platform},function(data){
            if(data){
                res.send(JSON.stringify({e:e,items:items,t:new Date().getTime(),i:"请更新新版本"}));
            }else{
                cdb.insertNewRole(dR,function(result){
                    res.send(JSON.stringify({e:e,items:items,t:new Date().getTime(),i:"请更新新版本"}));
                })
            }
        })
    }
   
    });
}
else if(obj.op == "cdkey"){
    var param = JSON.parse(obj.p);
    db.usekey(param.key,obj.id,req.connection.remoteAddress,function(err,info){
        if(err){
            res.send(JSON.stringify({result:false}));
        }
        else{

            res.send(JSON.stringify({result:true,info:info}));
        }

    })
}
else if(obj.op == "campaign" && obj.p && obj.platform){
    var param = JSON.parse(obj.p);
    db.getCampaign(obj.platform,function(err,info){
        if(info.length > 0){
            var now = new Date().getTime();
            var o = info[0];
            if(now+10000 > o.startTime && now < o.endTime){
                o.active = true;
            }
            o.startRemain = o.startTime - now;
            o.endRemain = o.endTime - now;
            res.send(JSON.stringify(o));
        }
        else{
            res.send(JSON.stringify({}));
        }

    });
}else if(obj.op == "listMail"){
    cdb.findSelfMails({to:obj.id},function(result){
        if(result){
            for (var i = 0; i < result.length; i++) {
                delete result[i]["_id"];
                delete result[i]["to"];
                delete result[i]["SendMode"];
                result[i].nowTime=nowTime;
                result[i].time = getLocalTime(new Date(result[i].time));
            }
            res.send({mails:result});
        }else{
            res.send("{}");
        }
    })
}else if(obj.op == "readMail"){
    var param = JSON.parse(obj.p);
    cdb.getOne("emails",{to:obj.id,id:param.id},function(result){
        if(result){
            cdb.updateRead({to:obj.id,id:param.id});
            delete result["_id"];
            result.time=getLocalTime(new Date(result.time));
            res.send({mails:result});
        }else{
            res.send("{}");
        }
    })
}else if(obj.op == "recieveMail"){
    var param = JSON.parse(obj.p);
    cdb.getOne("emails",{to:obj.id,id:param.id},function(result){
        if(result){
            if(result.mailType=="gifts"){
                var email = JSON.parse(result.items);
                for (var i = 0; i < param.idx.length; i++) {
                    var index=param.idx[i];
                    if (email[index] && email[index].used==false){
                        email[index].used=true;
                    }else{
                        res.send({error:"idx_error"});
                        return;
                    }
                }
                var items=JSON.stringify(email);
                cdb.updateItems({to:obj.id,id:param.id,items:items},function(flog){
                    if(flog){
                        res.send("{}");
                    }else{
                        res.send({error:"update_error"});
                    }
                })
            }else{
                res.send("{}");
            }
        }else{
            res.send({error:"idx_error"});
        }
    })
}else if(obj.op == "deleteMail" && obj.p){
    var param = JSON.parse(obj.p);
    if (param.id){
        cdb.deleteMails({to:obj.id,id:param.id},function(result){
            if(result){
                res.send({success:"delete_success"});
            }else{
                res.send({error:"delete_error"});
            }
        })
    }else{
        res.send({error:"no_id"});
    }
}else if(obj.id && obj.platform && obj.event && obj.params){
    // var param = JSON.parse(obj.params);
        var data={
            id:obj.id,
            platform:obj.platform,
            event:obj.event,
            params:obj.params,
            time:nowTime
        }
        if(obj.event=="unlock"){
            cdb.unlockMos(data,function(rs){
                insertEvent();
            })
        }else{
            insertEvent();
        }
        function insertEvent(){
            cdb.insertEvent(data,function(result){
                if(result){
                    console.log("insertEvent success");
                    res.send(data);
                }else{
                    console.log("insertEvent fail");
                    res.send({error:"error"})
                }
            })
        }
        
}else{
    res.send(JSON.stringify({}));
}
// else if(obj.op == "addCampaign"){
//     var param = JSON.parse(obj.p);
//     db.addCampaign(param,function(err,info){
//         if(err){
//             res.send(JSON.stringify({}));
//         }
//         else{
//             res.send(JSON.stringify(info));
//         }
//     });

// }
// else if(obj.op == "delCampaign"){
//     var param = JSON.parse(obj.p);
//     db.delCampaign(param,function(err,info){
//         if(err){
//             res.send(JSON.stringify({result:false}));
//         }
//         else{

//             res.send(JSON.stringify({result:true}));
//         }
//     });
// }
// else if(obj.op == "allCampaign"){
//     db.allCampaign(function(err,info){
//         if(err){
//             res.send(JSON.stringify({result:false}));
//         }
//         else{
//             res.send(JSON.stringify({result:true,info:info}));
//         }
//     });
// }
function toTwo(num){
    return num<10?"0"+num:num;
    }
function getLocalTime(date) {     
        return date.getFullYear()+"-"+toTwo(date.getMonth()+1)+"-"+toTwo(date.getDate())+" "+toTwo(date.getHours())+":"+toTwo(date.getMinutes());     
    }
})


module.exports = router;
