var db = require("./linkdb");


exports.createcode = function (obj, cb) {
    db.collection('codereCords', { safe: true }, function (err, collection) {
        if (err) {
            console.log(err);
            cb(false);
            return;
        }
        collection.insert(obj, { safe: true }, function (err, result) {
            if (err) {
                console.log(err);
            }
            else {
                console.log("inserted")
            }
        })
        collection.findOne(obj, function (err, data) {

            if (!err && data) {
                cb(data);
                console.log(data);
            }
            else {
                cb(false);
                console.log("not found");
            }

        });
    });
};

// db.coderecords.find(obj,function(err,allData){
//     if(!err && allData){
//         cb(true);
//         console.log(allData);
//     }else{
//         cb(false);
//         console.log("allData not found");
//     }
// });
exports.findAll = function (cb) {
    db.collection('codereCords', { safe: true }, function (err, collection) {
        if (err) {
            console.log(err);
            cb(false);
            return;
        }
       collection.find({}).toArray(function(err, docs) {
            cb(docs);
          });
    });

}

exports.getOne = function (obj,cb) {
    db.collection('codereCords', { safe: true }, function (err, collection) {
        if (err) {
            console.log(err);
            cb(false);
            return;
        }
        collection.findOne(obj, function (err, data) {

            if (!err && data) {
                cb(data);
                console.log("found");
            }
            else {
                cb(false);
                console.log("not found");
            }

        });
    });

}