var cf=require('../config');
var fs = require("fs");
var exec = require("child_process").exec;


exports.dataBackup=function(cfg,cb){
	var cfgJson=cfg;
	var bjPath="./dataBackup/timing_data/backupJson.json";
	if(dayTiming) clearInterval(dayTiming);
	if(workTiming) clearInterval(workTiming);
	if (cfgJson.backup){
		if(cfgJson.work<0){
			var dayTiming = setInterval(function(){
				var date=new Date();
				var nowTime=date.getHours()+":"+date.getMinutes();
				if(cfgJson.time===nowTime){
					var t=date.getTime();
					var dataName=cf.Db;
					var id=dataName+"_"+getDateTime(new Date(t));
					var cmd="mongodump -h "+cf.mongodBackup.serverAddress+" -d "+dataName+" -o "+cf.mongodBackup.storagePath_timing+"/"+id;
					exec(cmd,function(err){
						if(err){
							console.log(cmd,err);
							cb(false);
						}else{
							console.log(cmd,"complete");
							fs.readFile(bjPath,'utf-8', function(err,bjStr){
								var obj=JSON.parse(bjStr);
								obj[id]={
									id:id,
									dataName:dataName,
									"time":t
								};
								var objStr = JSON.stringify(obj);
								
							   	// 写入文件
							   	fs.writeFile(bjPath,objStr,function(err){
									if(!err){
										console.log("success");
										cb(true);
									}else{
										console.log(err);
										cb(false);
									}
							   	});

							})
							
						}

					})
				}
			},60000);
		}else{
			var workTiming = setInterval(function(){
				var date=new Date();
				var nowWork=date.getDay();
				var nowTime=date.getHours()+":"+date.getMinutes();
				if(cfgJson.work===nowWork && cfgJson.time===nowTime){
					var t=date.getTime();
					var dataName=cf.Db;
					var id=dataName+"_"+getDateTime(new Date(t));
					var cmd="mongodump -h "+cf.mongodBackup.serverAddress+" -d "+dataName+" -o "+cf.mongodBackup.storagePath_timing+"/"+id;
					exec(cmd,function(err){
						if(err){
							console.log(cmd,err);
							cb(false);
						}else{
							console.log(cmd,"complete");
							fs.readFile(bjPath,'utf-8', function(err,bjStr){
								var obj=JSON.parse(bjStr);
								obj[id]={
								id:id,
								dataName:dataName,
								"time":t
							};
								var objStr = JSON.stringify(obj);
							
						   		// 写入文件
							   	fs.writeFile(bjPath, objStr,function(err){
									if(!err){
										console.log("success");
										cb(true);
									}else{
										console.log(err);
										cb(false);
									}
							   	});
							})
							
						}

					})
				}
			},60000);
		}
		
	}

}

exports.autoDelete=function(obj){
	var delNum=obj.delNum;
	var path,id;
	var bjPath="./dataBackup/timing_data/backupJson.json";
	var delPath="./dataBackup/timing_data/autoDelete.json";
	if(delInterval) clearInterval(delInterval);
	var delObj={
		delNum:delNum
	}
	var delStr=JSON.stringify(delObj);
	fs.writeFile(delPath,delStr,function(err){
		if(!err){
			console.log("success");
		}else{
			console.log(err);
		}
	});


	if(delNum>0){
		del();
		var delInterval=setInterval(del,86400000);

	}
	function del(){
		var nowTime=new Date().getTime();
		var time=nowTime-delNum*86400000;
		fs.readFile(bjPath,'utf-8', function(err,bjStr){
			var bjJson=JSON.parse(bjStr);
			for(var k in bjJson){
				if(bjJson[k].time<time){
					id=bjJson[k].id;
					path=cf.mongodBackup.storagePath_timing+"/"+id;
					delete bjJson[id];
					deleteall(path);
				}
			}
			var objStr = JSON.stringify(bjJson);
				fs.writeFile(bjPath, objStr,function(err){
					if(!err){
						console.log("success");
					}else{
						console.log(err);
					}
				});
		})
		
	}
}

function deleteall(path){
	var files = [];  
	if(fs.existsSync(path)){  
		files = fs.readdirSync(path);  
		files.forEach(function(file, index) {  
			var curPath = path + "/" + file;  
			if(fs.statSync(curPath).isDirectory()) {  
				deleteall(curPath);
			} else { 
				fs.unlinkSync(curPath);  
			}  
		});  
		fs.rmdirSync(path);  
	}  
};


function toTwo(num){
		return num<10?"0"+num:num;
}
function getDateTime(date){
	return date.getFullYear()+""+toTwo(date.getMonth()+1)+""+toTwo(date.getDate())+""+toTwo(date.getHours())+""+toTwo(date.getMinutes());
}