var cf=require("../config");
var mongodb = require('mongodb');
var server = new mongodb.Server(cf.server,cf.port,{auto_reconnect:true});
var db = new mongodb.Db(cf.Db,server,{safe:true});
db.open(function(err,db){
    if(err){
        console.log(err);
        return;
    }
    console.log("inited");
});

module.exports = db;