var db = require("./linkdb");
var excel=require('../routes/excel');


exports.createcode = function (baseNmae,obj,cb) {
    db.collection(baseNmae, { safe: true }, function (err, collection) {
        if (err) {
            console.log(err);
            cb(false);
            return;
        }
        collection.insert(obj, { safe: true }, function (err, result) {
            if (err) {
                console.log(err);
            }
            else {
                console.log("inserted")
            }
        })
        collection.findOne(obj, function (err, data) {
            if (!err && data) {
                cb(data);
                console.log("insert success");
            }
            else {
                cb(null);
                console.log("insert error");
            }

        });
    });
};

exports.insertData = function (baseNmae,obj,cb) {
    db.collection(baseNmae, { safe: true }, function (err, collection) {
        if (err) {
            console.log(err);
            cb(false);
            return;
        }
        collection.insert(obj, { safe: true }, function (err, result) {
            if (err) {
                console.log(err);
                cb(false);
            }
            else {
                console.log("inserted")
                cb(true);
            }
        })
    });
};

// db.coderecords.find(obj,function(err,allData){
//     if(!err && allData){
//         cb(true);
//         console.log(allData);
//     }else{
//         cb(false);
//         console.log("allData not found");
//     }
// });
exports.findAll = function (baseNmae,cb) {
    db.collection(baseNmae, { safe: true }, function (err, collection) {
        if (err) {
            console.log(err);
            cb(false);
            return;
        }
       collection.find({}).toArray(function(err, docs) {
            if (docs.length==0) {
                cb(null);
            }else{
                cb(docs);

            }
          });
    });

}

exports.getOne = function (baseNmae,obj,cb) {
    db.collection(baseNmae, { safe: true }, function (err, collection) {
        if (err) {
            console.log(err);
            cb(false);
            return;
        }
        collection.findOne(obj, function (err, data) {

            if (!err && data) {
                cb(data);
                console.log("found");
            }
            else {
                cb(false);
                console.log("not found");
            }

        });
    });

}

exports.delCampaign = function(baseNmae,param,cb){
    db.collection(baseNmae,{safe:true},function(err,cams){
        cams.deleteOne(param,function(err,data){
            console.log("delCampaign",data);
            if(err){
                cb(false);
                return;
            }
            if(!data){
               cb(false);
            }
            else{
                 cb(true);
            }

        });
    })
};

exports.deleteData = function(baseNmae,param,cb){
    db.collection(baseNmae,{safe:true},function(err,collection){
        collection.deleteOne(param,function(err,data){
            if(err){
                cb(false);
                return;
            }
            if(!data){
               cb(false);
            }
            else{
                cb(true);
            }

        });
    })
};

exports.removeData = function(baseNmae,param,cb){
    db.collection(baseNmae,{safe:true},function(err,collection){
        collection.remove(param,function(err,data){
            if(err){
                cb(false);
                return;
            }
            if(!data){
               cb(false);
            }
            else{
                cb(true);
            }

        });
    })
};

exports.seqencing = function(baseNmae,n,cb){
    db.collection(baseNmae, { safe: true }, function (err, collection) {
        if (err) {
            console.log(err);
            cb(null);
            return;
        }

          collection.find({}).sort({giftId:n}).toArray(function(err, docs) {
            if (docs.length==0) {
                cb(null);
            }else{
                cb(docs);

            }
          });
    });

};

exports.findData = function(baseNmae,obj,cb){
    db.collection(baseNmae, { safe: true }, function (err, collection) {
        if (err) {
            console.log(err);
            cb(null);
            return;
        }
        collection.find(obj).toArray(function(err, docs) {
            if (docs.length==0) {
                cb(null);
            }else{
                cb(docs);

            }
        });
    });

};

exports.sortData = function(baseNmae,obj,sortobj,cb){
    db.collection(baseNmae, { safe: true }, function (err, collection) {
        if (err) {
            console.log(err);
            cb(null);
            return;
        }

          collection.find(obj).sort(sortobj).toArray(function(err, docs) {
            if (docs.length==0) {
                cb(null);
            }else{
                cb(docs);

            }
          });
    });

};


exports.updateMail = function(obj,cb){
     db.collection("globalMail",{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }   
        collection.update({id:obj.id},{$set:{title:obj.title,sendUser:obj.sendUser,content:obj.content,items:obj.items,startTime:obj.startTime,endTime:obj.endTime}},{},function(err){
            if(err){
                console.log(err);
                cb(false);
            }else{
                cb(true);
            }
        });
    });

};

exports.findMails = function(cb){
     db.collection("globalMail",{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }   
        var nowTime=new Date().getTime();
        collection.find({startTime:{'$lt':nowTime},endTime:{'$gt':nowTime}}).toArray(function(err, docs) {
            if (docs.length==0) {
                cb(null);
            }else{
                cb(docs);
            }
        });
    });

};


exports.insertMails = function(obj,cb){

    db.collection('mailRecord',{safe:true},function(err,mailRecord){
        mailRecord.findOne({id:obj.id,to:obj.to},function(err,data){
            if(err || data){
                return;
            }
            if(!data){
                mailRecord.insert(obj,{safe:true},function(err,result){
                    if(err){
                        console.log(err);
                        return;
                    }else{
                        db.collection('emails',{safe:true},function(err,collection){
                            if(!data){
                                collection.insert(obj,{safe:true},function(err,result){
                                    if(err){
                                        console.log(err);
                                        cb(false);
                                    }
                                    else{
                                        cb(true);
                                    }
                                });
                            }
                        })
                    }
                });



            }
        })
    })


};

exports.updateItems = function(obj,cb){
     db.collection("emails",{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }   
        collection.update({id:obj.id,to:obj.to},{$set:{'items':obj.items}},{},function(err){
            if(err){
                console.log(err);
                cb(false);
            }else{
                cb(true);
            }
        });
    });

};

exports.updateRead = function(obj){
     db.collection("emails",{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }   
        collection.update({id:obj.id,to:obj.to},{$set:{'read':true}},{},function(err){
            if(err){
                console.log(err);
            }
        });
    });

};

exports.findSelfMails = function(obj,cb){
     db.collection("emails",{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }   
        var nowTime=new Date().getTime();
        var time=nowTime-2592000000;
        collection.find({time:{'$gt':time},to:obj.to}).toArray(function(err, docs) {
            if (docs.length==0){
                cb(null);
            }else{
                cb(docs);
            }
        });
    });

};

exports.deleteMails = function(param,cb){
    db.collection("emails",{safe:true},function(err,collection){
        collection.findOne(param, function (err, data) {
            if (!err && data) {
               collection.deleteOne(param,function(err,data){
                    if(err){
                        cb(false);
                        return;
                    }
                    if(!data){
                       cb(false);
                    }
                    else{
                        cb(true);
                    }
                });
            }else {
                cb(false);
            }

        });
        
    })
};

exports.dailyRecord = function (obj,cb) {
    db.collection("LogTable", { safe: true }, function (err, collection) {
        if (err) {
            console.log(err);
            cb(false);
            return;
        }
        collection.insert(obj, { safe: true }, function (err, result) {
            if (err) {
                console.log(err);
                cb(false);
            }
            else {
                console.log("inserted")
                cb(true);
            }
        })
    });
};

exports.updateLog = function(obj,cb){
     db.collection("LogTable",{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }   
        collection.findOne({id:obj.id},function(err,data){
            if(!err && data){
                var online=obj.time-data.time;
                collection.update({id:obj.id,op:'login'},{$set:{op:'logout',online:online}},{},function(err){
                    if(err){
                        console.log(err);
                    }
                   cb(true); 
                });
            }else{
                cb(false);
            }
        });
    });

};

exports.findLog = function(obj,cb){
     db.collection("LogTable",{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }
        if(obj.platform){
            collection.find({time:{'$gte':obj.startTime,'$lte':obj.endTime},platform:{'$regex':obj.platform,'$options':'i'}}).sort({time:1}).toArray(function(err, docs){
                if (docs.length==0) {
                    cb(null);
                }else{
                    cb(docs);
                }
            });
        }else{
            collection.find({time:{'$gte':obj.startTime,'$lte':obj.endTime}}).sort({time:1}).toArray(function(err, docs){
                if (docs.length==0) {
                    cb(null);
                }else{
                    cb(docs);
                }
            });
        }
    });
};

exports.findUserLog = function(obj,userId,startLog,cb){
     db.collection("LogTable",{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }
        if(obj.platform){
            collection.find({time:{'$gte':obj.startTime,'$lte':obj.endTime},platform:{'$regex':obj.platform,'$options':'i'},id:userId}).sort({time:-1}).toArray(function(err, docs){
                if (docs.length==0) {
                    cb(null,startLog);
                }else{
                    cb(docs[0],startLog);
                }
            });
        }else{
            collection.find({time:{'$gte':obj.startTime,'$lte':obj.endTime},id:userId}).sort({time:-1}).toArray(function(err, docs){
                if (docs.length==0) {
                    cb(null,startLog);
                }else{
                    cb(docs[0],startLog);
                }
            });
        }
    });
};

exports.findLogOp = function(obj,cb){
     db.collection("LogTable",{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }
        if(obj.platform){
            collection.find({time:{'$gte':obj.startTime,'$lte':obj.endTime},op:obj.op,platform:{'$regex':obj.platform,'$options':'i'}}).sort({time:-1}).toArray(function(err, docs){
                if (docs.length==0) {
                    cb(null);
                }else{
                    cb(docs);
                }
            });
        }else{
            collection.find({time:{'$gte':obj.startTime,'$lte':obj.endTime},op:obj.op}).sort({time:-1}).toArray(function(err, docs){
                if (docs.length==0) {
                    cb(null);
                }else{
                    cb(docs);
                }
            });
        }
    });
};

exports.findLogOpLogout = function(obj,cb){
     db.collection("LogTable",{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }
        if(obj.platform){
            collection.find({time:{'$gt':obj.startTime,'$lte':obj.endTime},op:obj.op,platform:{'$regex':obj.platform,'$options':'i'},id:obj.id}).sort({time:1}).toArray(function(err, docs){
                if (docs.length==0) {
                    cb(null);
                }else{
                    cb(docs[0]);
                }
            });
        }else{
            collection.find({time:{'$gt':obj.startTime,'$lte':obj.endTime},op:obj.op,id:obj.id}).sort({time:1}).toArray(function(err, docs){
                if (docs.length==0) {
                    cb(null);
                }else{
                    cb(docs[0]);
                }
            });
        }
    });
};

exports.findRoleLog = function(obj,cb){
     db.collection("LogTable",{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }
        collection.find(obj).toArray(function(err, docs){
            if (docs.length==0) {
                cb(null);
            }else{
                cb(docs);
            }
        });
       
    });
};

exports.findlastLogin = function(obj,cb){
     db.collection("LogTable",{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }
        collection.find(obj).sort({time:-1}).toArray(function(err, docs){
            if (docs.length==0) {
                cb(null);
            }else{
                cb(docs[0]);
            }
        });
       
    });
};

exports.timeFrontRoles = function(obj,cb){
     db.collection("LogTable",{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }
        collection.find({time:{'$lte':obj.dateTime}}).toArray(function(err, docs){
            if (docs.length==0) {
                cb(null);
            }else{
                cb(docs);
            }
        });
        
    });
};

exports.findRole = function(obj,cb){
     db.collection("newRole",{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }

        collection.find(obj).toArray(function(err, docs){
            if (docs.length==0) {
                cb(null);
            }else{
                cb(docs);
            }
        });
        
    });

};

exports.findRoleOne = function(obj,cb){
     db.collection("newRole",{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }

        collection.findOne(obj,function(err,data){
            if(!err && data){
                cb(data);
            }else{
                cb(null);
            }
        });
        
    });

};


exports.findRoles1 = function(obj,cb){
     db.collection("newRole",{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }

        if(obj.platform){
            collection.find({time:{'$lte':obj.time},platform:{'$regex':obj.platform,'$options':'i'}}).sort({time:-1}).toArray(function(err, docs){
                if (docs.length==0) {
                    cb(null,obj.time);
                }else{
                    cb(docs,obj.time);
                }
            });
        }else{
            collection.find({time:{'$lte':obj.time}}).sort({time:-1}).toArray(function(err, docs){
                if (docs.length==0) {
                    cb(null,obj.time);
                }else{
                    cb(docs,obj.time);
                }
            });
        }
        
    });

};


exports.insertNewRole = function (obj,cb) {
    db.collection("newRole", { safe: true }, function (err, collection) {
        if (err) {
            console.log(err);
            cb(false);
            return;
        }
        collection.insert(obj, { safe: true }, function (err, result) {
            if (err) {
                console.log(err);
                cb(false);
            }
            else {
                cb(true);
            }
        })
    });
};

exports.findNewRoles = function(obj,cb){
     db.collection("newRole",{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }
        if(obj.platform){
            collection.find({time:{'$gte':obj.startTime,'$lte':obj.endTime},platform:{'$regex':obj.platform,'$options':'i'}}).sort({time:1}).toArray(function(err, docs){
                if (docs.length==0) {
                    cb(null);
                }else{
                    cb(docs);
                }
            });
        }else{
            collection.find({time:{'$gte':obj.startTime,'$lte':obj.endTime}}).sort({time:1}).toArray(function(err, docs){
                if (docs.length==0) {
                    cb(null);
                }else{
                    cb(docs);
                }
            });
        }
    });
};



exports.insertEvent = function(obj,cb){

    db.collection('event',{safe:true},function(err,collection){
        if(err){
            console.log(err);
            cb(false);
            return;
        }
        collection.insert(obj,{safe:true},function(err,result){
            if(err){
                console.log(err);
                cb(false);
            }
            else{
                cb(true);
            }
        });
    })
};

exports.searchEvent = function(obj,cb){
    db.collection("event", { safe: true }, function (err, collection) {
        if (err) {
            console.log(err);
            cb(null);
            return;
        }

        collection.find(obj).sort({time:-1}).toArray(function(err, docs) {
            if (docs.length==0) {
                cb(null);
            }else{
                cb(docs);

            }
        });
    });

};

exports.findBuyUser = function(obj,cb){
     db.collection("event",{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }
        if(obj.platform){
            collection.find({time:{'$gte':obj.startTime,'$lte':obj.endTime},platform:{'$regex':obj.platform,'$options':'i'},event:obj.event}).sort({time:1}).toArray(function(err, docs){
                if (docs.length==0) {
                    cb(null);
                }else{
                    cb(docs);
                }
            });
        }else{
            collection.find({time:{'$gte':obj.startTime,'$lte':obj.endTime},event:obj.event}).sort({time:1}).toArray(function(err, docs){
                if (docs.length==0) {
                    cb(null);
                }else{
                    cb(docs);
                }
            });
        }
    });
};

exports.findEvent = function(obj,cb){
     db.collection("event",{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }
        if(obj.platform){
            collection.find({time:{'$gte':obj.startTime,'$lte':obj.endTime},platform:{'$regex':obj.platform,'$options':'i'},event:obj.event}).sort({time:1}).toArray(function(err, docs){
                if (docs.length==0) {
                    cb(null);
                }else{
                    cb(docs);
                }
            });
        }else{
            collection.find({time:{'$gte':obj.startTime,'$lte':obj.endTime},event:obj.event}).sort({time:1}).toArray(function(err, docs){
                if (docs.length==0) {
                    cb(null);
                }else{
                    cb(docs);
                }
            });
        }
    });
};

exports.unlockMos = function(obj,cb){
    db.collection('unlock',{safe:true},function(err,collection){
        if(err){
            console.log(err);
            cb(false);
            return;
        }
        collection.findOne({id:obj.id},function(err,data){
            var excelJson=excel.excelToIDJson("./file/MonsterHandbook.xlsx");
            var paramJson=JSON.parse(obj.params);
            var mapTag="";
            for(var ms in excelJson){
                if(ms==paramJson.monster){
                    mapTag=excelJson[ms].mapTag;
                }
            }
            if(!err && data){
                var map=data.mapTag;
                var flog=false;
                for (var i = 0; i < map.length; i++) {
                    if(map[i].map==mapTag){
                        map[i].unlock++;
                        flog=true;
                        break;
                    }
                }
                if(!flog){
                    map.push({
                        map:mapTag,
                        unlock:1
                    });
                }
                collection.update({id:obj.id},{$set:{mapTag:map,time:obj.time}},{},function(err){
                    if(err){
                        console.log(err);
                        cb(false);
                        return;
                    }
                    cb(true);
                });
            }else{
                var param={
                    id:obj.id,
                    platform:obj.platform,
                    event:obj.event,
                    mapTag:[{
                        map:mapTag,
                        unlock:1
                    }],
                    time:obj.time

                }
                collection.insert(param,{safe:true},function(err,result){
                    if(err){
                        console.log(err);
                        cb(false);
                    }
                    else{
                        cb(true);
                    }
                });
            }
        });

    })
};

exports.findUnlock = function(obj,cb){
     db.collection("unlock",{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }
        if(obj.platform){
            collection.find({time:{'$gte':obj.startTime,'$lte':obj.endTime},platform:{'$regex':obj.platform,'$options':'i'}}).toArray(function(err, docs){
                if (docs.length==0) {
                    cb(null);
                }else{
                    cb(docs);
                }
            });
        }else{
            collection.find({time:{'$gte':obj.startTime,'$lte':obj.endTime}}).toArray(function(err, docs){
                if (docs.length==0) {
                    cb(null);
                }else{
                    cb(docs);
                }
            });
        }
    });
};

exports.upDailyGift=function(obj,cb){
    db.collection("dailyGift",{safe:true},function(err,collection){
        collection.findOne({id:obj.id},function(err,data){
            if(err){
                console.log(err);
                cb(false);
            }
            if(!data){
                var param;
                if(obj.payIf=="payPre"){
                    param={
                        id:obj.id,
                        payPre:obj.gifList,
                        payAft:"",
                        payPrompt:obj.payPrompt
                    }
                }else if(obj.payIf=="payAft"){
                    param={
                        id:obj.id,
                        payPre:"",
                        payAft:obj.gifList,
                        payPrompt:obj.payPrompt
                    }
                }
                collection.insert(param,{safe:true},function(err,result){
                    if(err){
                        console.log(err);
                        cb(false);
                    }else{
                        cb(true);
                    }
                });
            }else{
                if(obj.payIf=="payPre"){
                    collection.update({id:obj.id},{$set:{payPre:obj.gifList}},{},function(err){
                        if(err){
                            console.log(err);
                            cb(false);
                        }else{
                            cb(true);
                        }
                    })
                }else if(obj.payIf=="payAft"){
                    collection.update({id:obj.id},{$set:{payAft:obj.gifList}},{},function(err){
                        if(err){
                            console.log(err);
                            cb(false);
                        }else{
                            cb(true);
                        }
                    })
                }
                

            }

        });
    })
}

exports.upPt=function(obj,cb){
    db.collection("dailyGift",{safe:true},function(err,collection){
        collection.findOne({id:obj.id},function(err,data){
            if(err){
                console.log(err);
                cb(false);
            }
            if(!data){
                return;
            }else{
                collection.update({id:obj.id},{$set:{payPrompt:obj.payPrompt}},{},function(err){
                    if(err){
                        console.log(err);
                        cb(false);
                    }else{
                        cb(true);
                    }
                })
            }

        });
    })
}

exports.findAllDailyGift = function(cb){
    db.collection("dailyGift", { safe: true }, function (err, collection) {
        if (err) {
            console.log(err);
            cb(null);
            return;
        }

        collection.find().sort({id:-1}).toArray(function(err, docs) {
            if (docs.length==0) {
                cb(null);
            }else{
                cb(docs);

            }
        });
    });

};

exports.deleteDailyGift = function(obj,cb){
    db.collection("dailyGift",{safe:true},function(err,collection){
        collection.deleteOne(obj,function(err,data){
            if(err){
                cb(false);
                return;
            }
            if(!data){
               cb(false);
            }
            else{
                cb(true);
            }

        });
    })
};