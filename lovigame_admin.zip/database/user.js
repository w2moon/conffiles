var db = require("./linkdb");
var cf = require("../config");


    exports.insetUser = function(obj,cb){
        db.collection('manager',{safe:true},function(err,collection){
            if(err){
                console.log(err);
                cb(false);
                return;
            }
            collection.insert(obj,{safe:true},function(err,result){
                if(err){
                    cb(false);
                    console.log(err);
                }
                else{
                     console.log("inserted")
                }
            })
            collection.findOne(obj, function (err, data) {
                if (!err && data) {
                    cb(data);
                    console.log(data);
                }
                else {
                    cb(false);
                    console.log("not found");
                }

            });
        });
    };
    exports.findUser = function(obj,cb){
        db.collection('manager',{safe:true},function(err,collection){
            if(err){
                console.log(err);
                cb(false);
                return;
            }
            
            
        
            collection.findOne({email:obj.email,password:obj.password},function(err,data){

                if(!err && data){
                    cb(data);
                    console.log("found");
                }else{
                    cb(false);
                    console.log("not found");

                    collection.findOne({email:cf.admin},function(err,data){
                        if(!err && data){
                            console.log("admin");
                        }else{
                            collection.insert({userId:'admin',email:cf.admin,password:cf.admin,remark:'管理员'},{safe:true},function(err,result){
                                if(err){
                                    console.log(err);
                                }
                                else{
                                     console.log("inserted")
                                }
                            })
                            console.log("not found");  
                        }
                       
                    });


                }
               
            });
        });
    };

    exports.findAll = function (cb) {
    db.collection('manager', { safe: true }, function (err, collection) {
        if (err) {
            console.log(err);
            cb(false);
            return;
        }
       collection.find({}).toArray(function(err, docs) {
            cb(docs);
          });
    });

}

 exports.upDate = function (userId,email,password,cb) {
    db.collection('manager', { safe: true }, function (err, collection) {
        if (err) {
            console.log(err);
            cb(false);
            return;
        }
        collection.update({email:email},{$set:{userId:userId,password:password}},{},function(err){
            if(err){
            console.log(err);
            cb(false);
            }else{
            cb(true);
            }
        });
        
    });

}

