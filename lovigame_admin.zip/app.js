var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var timingBackup=require("./database/timingBackup");
var cfg=require('./dataBackup/timing_data/config');


var index = require('./routes/index');
var createCode = require('./routes/createCode');
var login=require('./routes/login');
var setPermission=require('./routes/setPermission');
var limitTimeCustoms=require('./routes/limitTimeCustoms');
var grantCode=require('./routes/grantCode');
var inspectCode=require('./routes/inspectCode');
var personMaterial=require('./routes/personMaterial');
var myTeam=require('./routes/myTeam');
var downfile=require('./routes/downfile');
var deleteLine=require('./routes/deleteLine');
var downModule=require('./routes/downModule');
var insertUserIdDemo=require('./routes/insertUserIdDemo');
var deleteUser=require('./routes/deleteUser');
var transactionRecord=require('./routes/transactionRecord');
var limitedTimeGiftBag=require('./routes/limitedTimeGiftBag');
var salesDataCount=require('./routes/salesDataCount');
var playerDemo=require('./routes/playerDemo');
var sendMail=require('./routes/sendMail');
var globalMail=require('./routes/globalMail');
var ck=require('./routes/ck');
var queryMails=require('./routes/queryMails');
var dailyRecord=require('./routes/dailyRecord');
var newRoleCount=require('./routes/newRoleCount');
var searchEvent=require('./routes/searchEvent');
var onlineTimeCount=require('./routes/onlineTimeCount');
var loginSituation=require('./routes/loginSituation');
var mongodBackup=require('./routes/mongodBackup');
var dataStatistics=require('./routes/dataStatistics');
var loginAward=require('./routes/loginAward');

var app = express();
var session = require('express-session');

/*
var ejs = require('ejs');
app.engine('html',ejs.__express);
app.set('view engine', 'html');
*/

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.set('view options', { filename: "views" });


// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser("admin"));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session());


app.use('/',login);
app.use('/login',login);
app.use('/index', index);
app.use('/createCode', createCode);
app.use('/setPermission',setPermission);
app.use('/limitTimeCustoms',limitTimeCustoms);
app.use('/grantCode',grantCode);
app.use('/inspectCode',inspectCode);
app.use('/personMaterial',personMaterial);
app.use('/personMaterial/user',personMaterial);
app.use('/myTeam',myTeam);
app.use('/downfile',downfile);
app.use('/deleteLine',deleteLine);
app.use('/deleteLine/user',deleteLine);
app.use('/downModule',downModule);
app.use('/insertUserIdDemo',insertUserIdDemo);
app.use('/deleteUser',deleteUser);
app.use('/transactionRecord',transactionRecord);
app.use('/limitedTimeGiftBag',limitedTimeGiftBag);
app.use('/salesDataCount',salesDataCount);
app.use('/playerDemo',playerDemo);
app.use('/ck',ck);
app.use('/sendMail',sendMail);
app.use('/globalMail',globalMail);
app.use('/queryMails',queryMails);
app.use('/dailyRecord',dailyRecord);
app.use('/newRoleCount',newRoleCount);
app.use('/searchEvent',searchEvent);
app.use('/onlineTimeCount',onlineTimeCount);
app.use('/loginSituation',loginSituation);
app.use('/mongodBackup',mongodBackup);
app.use('/dataStatistics',dataStatistics);
app.use('/loginAward',loginAward);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

timingBackup.dataBackup(cfg,function(result){})


module.exports = app;
