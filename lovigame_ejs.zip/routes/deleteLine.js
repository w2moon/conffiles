var express = require('express');
var router = express.Router();
var db = require('../database/db');
var cdb = require('../database/dataBase');
var path=require('path');
var fs = require('fs');
router.get('/',function(req, res, next) {

			// var currDir = path.normalize(req.query.dir),
	  //       fileName = req.query.name,
	  //       currFile = path.join(currDir,fileName),
	  //       fReadStream;

		var name=req.query.name;
		var baseName=req.query.baseName;
		    console.log(name);
		    var delRow={
		    	id:name
		    }
		    cdb.delCampaign(baseName,delRow,function(result){
		    	if (result) {
		    		res.send({result:true});
		    	} else {
		    		res.send({result:false});
		    	}
		    })
	});

// router.get('/user',function(req, res, next) {
// 		var name=req.query.name;
// 		var baseName=req.query.baseName;
// 		    console.log(name);
// 		    var delRow={
// 		    	email:name
// 		    }
// 		    cdb.delCampaign(baseName,delRow,function(result){
// 		    	if (result) {
// 		    		res.send({result:true});
// 		    	} else {
// 		    		res.send({result:false});
// 		    	}
// 		    })
// 	});

module.exports = router;