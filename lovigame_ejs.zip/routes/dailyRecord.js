var express = require('express');
var router = express.Router();
var filter = require('./filter');
var cdb = require('../database/dataBase');

/* GET users listing. */
router.get('/',function(req, res, next){
  	res.render("dailyRecord",{title:"在线人数统计",userId:req.session.userId,queryMails:req.session.queryMails,globalMail:req.session.globalMail,user:req.session.user_id,inspect:req.session.inspect,limitPass:req.session.limitPass,grantCode:req.session.grantCode,transactionRecord:req.session.transactionRecord,sendMail:req.session.sendMail});
});
router.post('/',function(req,res,next){
	var obj={};
	for(var i in req.body){
		obj[i]=req.body[i];
	}
	obj.startTime=parseInt(obj.startTime);
	obj.endTime=parseInt(obj.endTime);
	cdb.findLog(obj,function(result){
		if(result){
			res.send(result);
		}else{
			res.send(null);
		}
	})

})


module.exports = router;
