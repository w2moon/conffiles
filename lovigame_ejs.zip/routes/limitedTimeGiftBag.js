var express = require('express');
var router = express.Router();
var fs = require('fs');
var http=require("http");
var request = require('request');
var filter = require('./filter');
var user=require('../database/user');
var cdb=require("../database/dataBase");
var multer = require('multer');
var path = require('path');



/* GET users listing. */
router.get('/',filter.authorize,function(req, res, next) {
	cdb.findAll("giftPacks",function(data){
		if (data) {
			console.log("findAll success");
		} else {
			data=[];
			console.log("findAll null");
		}
	res.render("limitedTimeGiftBag",{result:data,globalMail:req.session.globalMail,queryMails:req.session.queryMails,userId:req.session.userId,user:req.session.user_id,inspect:req.session.inspect,limitPass:req.session.limitPass,grantCode:req.session.grantCode,transactionRecord:req.session.transactionRecord,sendMail:req.session.sendMail});
	})

	
});

router.post('/creatGifts',function(req, res, next) {
	var id=req.body.id;
	var gifName=req.body.gifname;
	var startTime=req.body.startTime;
	var endTime=req.body.endTime;
	var gifPrice=req.body.gifPrice;
	var smallPic=req.body.smallPic;
	var bigPic=req.body.bigPic;
	var	goods1=req.body.goods1;
	var	goods1Num=req.body.goods1Num;
	var goods2=req.body.goods2;
	var	goods2Num=req.body.goods2Num;
	var	goods3=req.body.goods3;
	var	goods3Num=req.body.goods3Num;
	var	goods4=req.body.goods4;
	var	goods4Num=req.body.goods4Num;
	console.log(typeof smallPic+"   type");
	var giftPacks={
		id:id,
		gifName:gifName,
		startTime:startTime,
		endTime:endTime,
		gifPrice:gifPrice,
		smallPic:smallPic,
		bigPic:bigPic,
		goods1:goods1,
		goods1Num:goods1Num,
		goods2:goods2,
		goods2Num:goods2Num,
		goods3:goods3,
		goods3Num:goods3Num,
		goods4:goods4,
		goods4Num:goods4Num
	}
	console.log(giftPacks);

	cdb.seqencing("giftPacks",-1,function(result){
		if (result){
			console.log(result);
			giftPacks.giftId=result[0].giftId+1;
			cdb.createcode("giftPacks",giftPacks,function(data){
				if (data) {
					console.log("insert success");
					res.send({result:data});
				}else{
					console.log("insert fail");
					res.send(null);
				}
			})
		}else{
			giftPacks.giftId=10000001;
			cdb.createcode("giftPacks",giftPacks,function(data){
				if (data) {
					console.log("insert success");
					res.send({result:data});
				}else{
					console.log("insert fail");
					res.send(null);
				}
			})
		}
	})

	
	

	

});
router.post('/find',function(req, res, next) {
	var startTime=req.body.startTime;
	var endTime=req.body.endTime;

	cdb.findAll("giftPacks",function(result){
		if (result) {
			console.log(startTime+" "+endTime);
			var starttime = new Date(startTime).getTime();
			var endtime = new Date(endTime).getTime();
			for(var i = 0; i < result.length; i++){
				if(starttime < (new Date(result[i].endTime).getTime()) && endtime > (new Date(result[i].startTime).getTime())) {
					res.send({result:result[i].gifName});
					return;
				}
				
			}
			res.send(null);
		}else{
			res.send(null);
		}
	})
	

});

router.get('/deleteLine',function(req, res, next) {
	var id=req.query.id;
	console.log(id);
	cdb.delCampaign("giftPacks",{id:id},function(result){
		console.log(result);
		if (result) {
			res.send({result:result});
		}else{
			res.send({result:false});
		}
		
	})
});

router.get('/currentGift',function(req, res, next) {
	var nowTime=new Date().getTime();
	cdb.findAll("giftPacks",function(result){
		for (var i = 0; i < result.length; i++) {
			var startTime=new Date(result[i].startTime).getTime();
			var endTime=new Date(result[i].endTime).getTime();
			if (nowTime > startTime && nowTime < endTime){
				var goods="";
				if (result[i].goods1){
					goods+=result[i].goods1+","+result[i].goods1Num;
				}
				if (result[i].goods2){
					goods+=";"+result[i].goods2+","+result[i].goods2Num;
				}
				if (result[i].goods3){
					goods+=";"+result[i].goods3+","+result[i].goods3Num;
				}
				if (result[i].goods4){
					goods+=";"+result[i].goods4+","+result[i].goods4Num;
				}
				res.send({
					"giftId":result[i].giftId,
					"gifName":result[i].gifName,
					"gifPrice":result[i].gifPrice,
					"goods":goods,
					"startTime":result[i].startTime,
					"endTime":result[i].endTime,
					"enclosure":"/imgfile/"+result[i].fileName
				});
				return;
			}
		}
		res.send("{}");
	})
	

});

var storage = multer.diskStorage({
 destination: function (req, file, cb) {
  cb(null, path.resolve('./public/imgfile/'));
 },
 filename: function (req, file, cb) {
  cb(null, file.originalname);
 }
});
var upload = multer({storage: storage});

router.post('/uploadImg',upload.single('avatar'),function(req, res, next) {
		if (req.file){
			console.log("success");
		}else{
			console.log("error");
		}
});



module.exports = router;