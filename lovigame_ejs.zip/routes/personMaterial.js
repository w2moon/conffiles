var express = require('express');
var router = express.Router();
var filter = require('./filter');
var cdb = require('../database/dataBase');
var user = require('../database/user');
/* GET users listing. */
router.get('/',filter.authorize,function(req, res, next) {
  res.render("personMaterial",{title:"personMaterial",userId:req.session.userId,queryMails:req.session.queryMails,globalMail:req.session.globalMail,user:req.session.user_id,inspect:req.session.inspect,limitPass:req.session.limitPass,grantCode:req.session.grantCode,transactionRecord:req.session.transactionRecord,sendMail:req.session.sendMail});
});

router.get('/user',function(req, res, next) {
  var email=req.query.email;
  cdb.getOne('manager',{email:email},function(data){
  	if (data) {
  		res.send({result:true});
  	} else {
  		res.send({result:false});
  	}
  })
});

router.post('/',function(req, res, next) {
  var userId=req.body.userId;
  var email=req.body.email;
  var newPwd=req.body.newPwd;
  var confirmPwd=req.body.confirmPwd;
  // var obj={
  // 	userId:userId,
  // 	email:email,
  // 	password:password
  // }
  user.upDate(userId,email,newPwd,function(result){
  	if (result) {
  		res.send({result:true});
  	} else {
  		res.send({result:false});
  	}
  })
});

module.exports = router;
