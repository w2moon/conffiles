var express = require('express');
var router = express.Router();
var filter = require('./filter');
var db = require('../database/db');
var cdb = require('../database/createDataBase');
var path=require('path');
var fs = require('fs');
/* GET users listing. */
router.get('/',filter.authorize, function(req, res, next) {
	var mess={
		title:"createCode",
		num:3
	}

  	cdb.findAll(function(result){
	  		if (result) {
	  			console.log(result);
	  			console.log("findAll success");
	  		} else {
	  			console.log("findAll error");
	  		}
	  		// res.json(result);
	  		res.render("createCode",{result:result,queryMails:req.session.queryMails,globalMail:req.session.globalMail,userId:req.session.userId,user:req.session.user_id,inspect:req.session.inspect,limitPass:req.session.limitPass,grantCode:req.session.grantCode,transactionRecord:req.session.transactionRecord,sendMail:req.session.sendMail});
	  	})
});
router.post('/', function(req, res, next){
	var codeNum=req.body['codeNum'];
	var	resId=req.body['resId'];
		db.genkey(codeNum,1,resId,function(err,path){
		if (!err) {
			var date=new Date();
			var nowDate=""+date.getFullYear()+"-"+toTwo(date.getMonth()+1)+"-"+toTwo(date.getDate())+" "+toTwo(date.getHours())+":"+toTwo(date.getMinutes())+"";
			var resNum=""+resId+","+codeNum+"";
			var keys = ['a','b','c','d','e','f','g','h','k','m','n','p','q','r','s','t','u','v','w','x','y','z','1','2','3','4','5','6','7','8','9'];
			var kc = function(){
			    return keys[Math.floor(Math.random()*keys.length)];
			};
			var ks = function(num){
			    var str = "";
			    for(var i=0;i<num;++i){
			        str += kc();
			    }
			    return str;

			};
			var identify="a"+ks(20);
			console.log("genkeysuccess");
		}else{
			console.log("genkeyerror");
		}

		cdb.createcode({id:identify,time:nowDate,resnum:resNum,download:path},function(result){
			if (result) {
				console.log("success");
			}else{
				console.log("error");
			}
			res.send(JSON.stringify({path:path,nowDate:nowDate,resNum:resNum,result:result}));
		});
		function toTwo(num){
			return num<10?"0"+num:num;
		}
		// res.json({content:content});
		// res.end(content);
	});
	
  // res.render("createCode",{title:"createCode"});




});
module.exports = router;