var express = require('express');
var router = express.Router();
var filter = require('./filter');
var db=require('../database/db');
var cdb=require('../database/dataBase');

/* GET users listing. */
router.get('/',filter.authorize, function(req, res, next) {
 	res.render("sendMail",{title:"邮件系统",userId:req.session.userId,globalMail:req.session.globalMail,queryMails:req.session.queryMails,user:req.session.user_id,inspect:req.session.inspect,limitPass:req.session.limitPass,grantCode:req.session.grantCode,transactionRecord:req.session.transactionRecord,sendMail:req.session.sendMail});
});
router.post('/',function(req,res,next){
	var obj={};
	for(var i in req.body){
		obj[i]=req.body[i];
	}
	obj.id=getId(7);
	obj.time=new Date().getTime();
	db.getAccount({id:obj.to},function(result){
		if (result){
			cdb.insertData("emails",obj,function(data){
				if (data){
					res.send("send_success");
				}else{
					res.send("send_fail");
				}
			});
		}else{
			res.send("no_user");
		}
	})

	
	function kc(){
		var keys = ['a','b','c','d','e','f','g','h','k','m','n','p','q','r','s','t','u','v','w','x','y','z','1','2','3','4','5','6','7','8','9'];
	    return keys[Math.floor(Math.random()*keys.length)];
	};
	function getId(num){
	    var str = "e";
	    for(var i=0;i<num;++i){
	        str += kc();
	    }
	    return str;

	};
	
})
module.exports = router;

