var express = require('express');
var router = express.Router();
var filter = require('./filter');
var cdb=require('../database/dataBase')

/* GET users listing. */
router.get('/',filter.authorize,function(req, res, next) {
  	res.render("salesDataCount",{title:"index",userId:req.session.userId,queryMails:req.session.queryMails,globalMail:req.session.globalMail,user:req.session.user_id,inspect:req.session.inspect,limitPass:req.session.limitPass,grantCode:req.session.grantCode,transactionRecord:req.session.transactionRecord,sendMail:req.session.sendMail});
});

router.post("/",function(req, res, next){
	var startTime=req.body.startTime;
	var endTime=req.body.endTime;
	var result={};
	var messArr=[];
	var attr;
	cdb.findAll("transactionRecord",function(data){
		if (data){
			for (var i = 0; i < data.length; i++) {
				if (data[i].time>startTime && data[i].time<endTime){
					messArr.push(data[i]);
				}

			}
			if (messArr.length>0){
				for (var j = 0; j < messArr.length; j++) {
					attr="";
					for(var atr in result){
						if (parseInt(atr) === messArr[j].giftId){
							attr=atr;
						}
					}
					if(attr){
						result[attr].push(messArr[j]);
					}else{
						var str=(messArr[j].giftId).toString();
						result[str]=[];
						result[str].push(messArr[j]);
					}
				
				}
			}
			res.send(result);

		}else{
			res.send("");
		}
	})
})

module.exports = router;
