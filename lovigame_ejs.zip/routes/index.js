var express = require('express');
var router = express.Router();
var filter = require('./filter');

/* GET users listing. */
router.get('/',filter.authorize,function(req, res, next) {
  	res.render("index",{title:"index",userId:req.session.userId,queryMails:req.session.queryMails,globalMail:req.session.globalMail,user:req.session.user_id,inspect:req.session.inspect,limitPass:req.session.limitPass,grantCode:req.session.grantCode,transactionRecord:req.session.transactionRecord,sendMail:req.session.sendMail});
});


module.exports = router;
