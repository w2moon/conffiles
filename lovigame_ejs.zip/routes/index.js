var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
	var list=[{
		id:93,src:'../images/list1.jpg'
	},{
		id:86,src:'../images/list2.jpg'
	},{
		id:85,src:'../images/list3.jpg'
	}];
	var text=[{
		title:'强势登陆湖南卫视 《还珠格格》手游再掀回忆热潮',
		content:'20年前，一部名为《还珠格格》电视剧首度登陆湖南卫视便风靡全国，并创下至今依旧难以超越的收视率记录，成为接下来不折不扣的假期档银屏霸主。',
	},{
		title:'强势登陆湖南卫视 《还珠格格》手游再掀回忆热潮',
		content:'20年前，一部名为《还珠格格》电视剧首度登陆湖南卫视便风靡全国，并创下至今依旧难以超越的收视率记录，成为接下来不折不扣的假期档银屏霸主。',
	},{
		title:'强势登陆湖南卫视 《还珠格格》手游再掀回忆热潮',
		content:'20年前，一部名为《还珠格格》电视剧首度登陆湖南卫视便风靡全国，并创下至今依旧难以超越的收视率记录，成为接下来不折不扣的假期档银屏霸主。',
	}];
	res.render("index",{title:"lovigame"});
});

module.exports = router;
