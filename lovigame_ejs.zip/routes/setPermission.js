var express = require('express');
var router = express.Router();
var filter = require('./filter');
var user=require('../database/user');

/* GET users listing. */
router.get('/',filter.authorize,function(req, res, next) {
	user.findAll(function(data){
		if (data) {
			console.log("findAll success");
		} else {
			console.log("findAll null");
		}
		res.render("setPermission",{result:data,queryMails:req.session.queryMails,userId:req.session.userId,globalMail:req.session.globalMail,user:req.session.user_id,inspect:req.session.inspect,limitPass:req.session.limitPass,grantCode:req.session.grantCode,transactionRecord:req.session.transactionRecord,sendMail:req.session.sendMail});
	})
});

router.post('/',function(req,res,next){
	var userId=req.body.userId,
		email=req.body.email,
		remark=req.body.remark,
		inspect=req.body.inspect,
		limitPass=req.body.limitPass,
		grantCode=req.body.grantCode,
		transactionRecord=req.body.transactionRecord,
		sendMail=req.body.sendMail,
		globalMail=req.body.globalMail,
		queryMails=req.body.queryMails,
		nowDate=req.body.nowDate,
		password=req.body.password;
	var data={
		userId:userId,
		email:email,
		remark:remark,
		inspect:inspect,
		limitPass:limitPass,
		grantCode:grantCode,
		transactionRecord:transactionRecord,
		sendMail:sendMail,
		globalMail:globalMail,
		queryMails:queryMails,
		nowDate:nowDate,
		password:password
	}
	user.insetUser(data,function(result){
		if (result) {
			console.log("insert success");
			res.send({userId:result.userId,email:result.email,nowDate:result.nowDate,remark:result.remark});
		} else {
			res.send({result:false});
			console.log("insert err");
		}
	})
});

module.exports = router;
