var express = require('express');
var router = express.Router();
var filter = require('./filter');
var cdb = require('../database/dataBase');

/* GET users listing. */
router.get('/',function(req, res, next){
  	res.render("onlineTimeCount",{title:"上线时间统计",userId:req.session.userId,queryMails:req.session.queryMails,globalMail:req.session.globalMail,user:req.session.user_id,inspect:req.session.inspect,limitPass:req.session.limitPass,grantCode:req.session.grantCode,transactionRecord:req.session.transactionRecord,sendMail:req.session.sendMail});
});
router.post('/',function(req,res,next){
	var obj={};
	var userList=[];
	var flog=false;
	for(var i in req.body){
		obj[i]=req.body[i];
	}
	obj.startTime=parseInt(obj.startTime);
	obj.endTime=parseInt(obj.endTime);
	cdb.findNewRoles(obj,function(data){
		if(!data){
			res.send("");
		}else{
			var index=0;
			for (var i = 0; i < data.length; i++) {
				cdb.findUserLog(obj,data[i].id,data[i].time,function(result,startLogin){
					if(result){
						var obj={
							id:result.id,
							platform:result.platform,
							startLogin:startLogin,
							endLogin:result.time
						};
						userList.push(obj);
					}
					index++;
					if(index==data.length){
						flog=true;
					}
					if(flog){
						res.send(userList);
					}
				})
			}
		}
	})
})


module.exports = router;
