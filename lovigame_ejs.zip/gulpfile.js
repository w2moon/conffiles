var gulp = require('gulp'); 
// 调用 .create() 意味着你得到一个唯一的实例并允许您创建多个服务器或代理。 
var browserSync = require('browser-sync').create(); 
var nodemon = require('gulp-nodemon'); 
var reload = browserSync.reload;

gulp.task("node", function() {
    return nodemon({ 
        script: './bin/www', // 忽略部分对程序运行无影响的文件的改动，nodemon只监视js文件，可用ext项来扩展别的文件类型 
        ignore: ["gulpfile.js", "node_modules/", "public/**/*.*"], 
        ext: 'js',
        env: { 'NODE_ENV': 'development' } 
    }).on('start', function(){
        setTimeout(reload,100);
    }).on('crash', function () {
        console.log('crash');
    });
});


gulp.task('start', ["node"], function() {
    var files = ["public/**/*.*", "views/**", "routes/**"];
    browserSync.init(files, {
        proxy: 'http://localhost:3005',
        browser: 'chrome',
        notify: false,
        port: 8080
    });

    gulp.watch(files).on("change", reload); 
});
