var db = require("./linkdb");


exports.createcode = function (baseNmae,obj,cb) {
    db.collection(baseNmae, { safe: true }, function (err, collection) {
        if (err) {
            console.log(err);
            cb(false);
            return;
        }
        collection.insert(obj, { safe: true }, function (err, result) {
            if (err) {
                console.log(err);
            }
            else {
                console.log("inserted")
            }
        })
        collection.findOne(obj, function (err, data) {
            if (!err && data) {
                cb(data);
                console.log("insert success");
            }
            else {
                cb(null);
                console.log("insert error");
            }

        });
    });
};

exports.insertData = function (baseNmae,obj,cb) {
    db.collection(baseNmae, { safe: true }, function (err, collection) {
        if (err) {
            console.log(err);
            cb(false);
            return;
        }
        collection.insert(obj, { safe: true }, function (err, result) {
            if (err) {
                console.log(err);
                cb(false);
            }
            else {
                console.log("inserted")
                cb(true);
            }
        })
    });
};

// db.coderecords.find(obj,function(err,allData){
//     if(!err && allData){
//         cb(true);
//         console.log(allData);
//     }else{
//         cb(false);
//         console.log("allData not found");
//     }
// });
exports.findAll = function (baseNmae,cb) {
    db.collection(baseNmae, { safe: true }, function (err, collection) {
        if (err) {
            console.log(err);
            cb(false);
            return;
        }
       collection.find({}).toArray(function(err, docs) {
            if (docs.length==0) {
                cb(null);
            }else{
                cb(docs);

            }
          });
    });

}

exports.getOne = function (baseNmae,obj,cb) {
    db.collection(baseNmae, { safe: true }, function (err, collection) {
        if (err) {
            console.log(err);
            cb(false);
            return;
        }
        collection.findOne(obj, function (err, data) {

            if (!err && data) {
                cb(data);
                console.log("found");
            }
            else {
                cb(false);
                console.log("not found");
            }

        });
    });

}

exports.delCampaign = function(baseNmae,param,cb){
    db.collection(baseNmae,{safe:true},function(err,cams){
        cams.deleteOne(param,function(err,data){
            console.log("delCampaign",data);
            if(err){
                cb(false);
                return;
            }
            if(!data){
               cb(false);
            }
            else{
                 cb(true);
            }

        });
    })
};

exports.seqencing = function(baseNmae,n,cb){
    db.collection(baseNmae, { safe: true }, function (err, collection) {
        if (err) {
            console.log(err);
            cb(null);
            return;
        }

          collection.find({}).sort({giftId:n}).toArray(function(err, docs) {
            if (docs.length==0) {
                cb(null);
            }else{
                cb(docs);

            }
          });
    });

};

exports.findData = function(baseNmae,obj,cb){
    db.collection(baseNmae, { safe: true }, function (err, collection) {
        if (err) {
            console.log(err);
            cb(null);
            return;
        }
        collection.find(obj).toArray(function(err, docs) {
            if (docs.length==0) {
                cb(null);
            }else{
                cb(docs);

            }
        });
    });

};

exports.sortData = function(baseNmae,obj,sortobj,cb){
    db.collection(baseNmae, { safe: true }, function (err, collection) {
        if (err) {
            console.log(err);
            cb(null);
            return;
        }

          collection.find(obj).sort(sortobj).toArray(function(err, docs) {
            if (docs.length==0) {
                cb(null);
            }else{
                cb(docs);

            }
          });
    });

};


exports.updateMail = function(obj,cb){
     db.collection("globalMail",{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }   
        collection.update({id:obj.id},{$set:{title:obj.title,content:obj.content,items:obj.items,startTime:obj.startTime,endTime:obj.endTime}},{},function(err){
            if(err){
                console.log(err);
                cb(false);
            }else{
                cb(true);
            }
        });
    });

};

exports.findMails = function(cb){
     db.collection("globalMail",{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }   
        var nowTime=new Date().getTime();
        collection.find({startTime:{'$lt':nowTime},endTime:{'$gt':nowTime}}).toArray(function(err, docs) {
            if (docs.length==0) {
                cb(null);
            }else{
                cb(docs);
            }
        });
    });

};


exports.insertMails = function(obj,cb){

    db.collection('emails',{safe:true},function(err,collection){
        collection.findOne({id:obj.id,to:obj.to},function(err,data){
            if(err){
                console.log(err);
                cb(false);
                return;
            }
            if(!data){
                collection.insert(obj,{safe:true},function(err,result){
                    if(err){
                        console.log(err);
                        cb(false);
                    }
                    else{
                        cb(true);
                    }
                });
            }
        })
    })
};

exports.updateItems = function(obj,cb){
     db.collection("emails",{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }   
        collection.update({id:obj.id,to:obj.to},{$set:{'items':obj.items}},{},function(err){
            if(err){
                console.log(err);
                cb(false);
            }else{
                cb(true);
            }
        });
    });

};

exports.updateRead = function(obj){
     db.collection("emails",{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }   
        collection.update({id:obj.id,to:obj.to},{$set:{'read':true}},{},function(err){
            if(err){
                console.log(err);
            }
        });
    });

};

exports.findSelfMails = function(obj,cb){
     db.collection("emails",{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }   
        var nowTime=new Date().getTime();
        var time=nowTime-2592000000;
        collection.find({time:{'$gt':time},to:obj.to}).toArray(function(err, docs) {
            console.log("docs",docs);
            if (docs.length==0){
                cb(null);
            }else{
                cb(docs);
            }
        });
    });

};

exports.deleteMails = function(param,cb){
    db.collection("emails",{safe:true},function(err,collection){
        collection.findOne(param, function (err, data) {
            if (!err && data) {
               collection.deleteOne(param,function(err,data){
                    if(err){
                        cb(false);
                        return;
                    }
                    if(!data){
                       cb(false);
                    }
                    else{
                        cb(true);
                    }
                });
            }else {
                cb(false);
            }

        });
        
    })
};

exports.dailyRecord = function (obj,cb) {
    db.collection("LogTable", { safe: true }, function (err, collection) {
        if (err) {
            console.log(err);
            cb(false);
            return;
        }
        collection.insert(obj, { safe: true }, function (err, result) {
            if (err) {
                console.log(err);
                cb(false);
            }
            else {
                console.log("inserted")
                cb(true);
            }
        })
    });
};

exports.findLog = function(obj,cb){
     db.collection("LogTable",{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }
        if(obj.platform){
            collection.find({time:{'$gte':obj.startTime,'$lte':obj.endTime},platform:obj.platform}).sort({time:1}).toArray(function(err, docs){
                if (docs.length==0) {
                    cb(null);
                }else{
                    cb(docs);
                }
            });
        }else{
            collection.find({time:{'$gte':obj.startTime,'$lte':obj.endTime}}).sort({time:1}).toArray(function(err, docs){
                if (docs.length==0) {
                    cb(null);
                }else{
                    cb(docs);
                }
            });
        }
    });
};

exports.findUserLog = function(obj,userId,startLog,cb){
     db.collection("LogTable",{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }
        if(obj.platform){
            collection.find({time:{'$gte':obj.startTime,'$lte':obj.endTime},platform:obj.platform,id:userId}).sort({time:-1}).toArray(function(err, docs){
                if (docs.length==0) {
                    cb(null,startLog);
                }else{
                    cb(docs[0],startLog);
                }
            });
        }else{
            collection.find({time:{'$gte':obj.startTime,'$lte':obj.endTime},id:userId}).sort({time:-1}).toArray(function(err, docs){
                if (docs.length==0) {
                    cb(null,startLog);
                }else{
                    cb(docs[0],startLog);
                }
            });
        }
    });
};

exports.findRoleLog = function(obj,cb){
     db.collection("LogTable",{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }
        collection.find(obj).toArray(function(err, docs){
            if (docs.length==0) {
                cb(null);
            }else{
                cb(docs);
            }
        });
       
    });
};

exports.findlastLogin = function(obj,cb){
     db.collection("LogTable",{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }
        collection.find(obj).sort({time:-1}).toArray(function(err, docs){
            if (docs.length==0) {
                cb(null);
            }else{
                cb(docs[0]);
            }
        });
       
    });
};

exports.timeFrontRoles = function(obj,cb){
     db.collection("LogTable",{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }
        collection.find({time:{'$lte':obj.dateTime}}).toArray(function(err, docs){
            if (docs.length==0) {
                cb(null);
            }else{
                cb(docs);
            }
        });
        
    });
};

exports.findRole = function(obj,cb){
     db.collection("newRole",{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }

        collection.find(obj).toArray(function(err, docs){
            if (docs.length==0) {
                cb(null);
            }else{
                cb(docs);
            }
        });
        
    });

};

exports.insertNewRole = function (obj,cb) {
    db.collection("newRole", { safe: true }, function (err, collection) {
        if (err) {
            console.log(err);
            cb(false);
            return;
        }
        collection.insert(obj, { safe: true }, function (err, result) {
            if (err) {
                console.log(err);
                cb(false);
            }
            else {
                cb(true);
            }
        })
    });
};

exports.findNewRoles = function(obj,cb){
     db.collection("newRole",{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }
        if(obj.platform){
            collection.find({time:{'$gte':obj.startTime,'$lte':obj.endTime},platform:obj.platform}).sort({time:1}).toArray(function(err, docs){
                if (docs.length==0) {
                    cb(null);
                }else{
                    cb(docs);
                }
            });
        }else{
            collection.find({time:{'$gte':obj.startTime,'$lte':obj.endTime}}).sort({time:1}).toArray(function(err, docs){
                if (docs.length==0) {
                    cb(null);
                }else{
                    cb(docs);
                }
            });
        }
    });
};



exports.insertEvent = function(obj,cb){

    db.collection('event',{safe:true},function(err,collection){
        if(err){
            console.log(err);
            cb(false);
            return;
        }
        collection.insert(obj,{safe:true},function(err,result){
            if(err){
                console.log(err);
                cb(false);
            }
            else{
                cb(true);
            }
        });
    })
};

exports.searchEvent = function(obj,cb){
    db.collection("event", { safe: true }, function (err, collection) {
        if (err) {
            console.log(err);
            cb(null);
            return;
        }

        collection.find(obj).sort({time:-1}).toArray(function(err, docs) {
            if (docs.length==0) {
                cb(null);
            }else{
                cb(docs);

            }
        });
    });

};