var cf=require("../config");
var mongodb = require('mongodb');
var fs = require('fs');
var server = new mongodb.Server(cf.server,cf.port,{auto_reconnect:true});
var db = new mongodb.Db(cf.Db,server,{safe:true});
var inited = false;
var queuedOps = [];
db.open(function(err,db){
    if(err){
        console.log(err);
        return;
    }
    console.log("inited");
    inited = true;
    nextOp();
});

var nextOp = function(){
    if(queuedOps.length<=0){
        return;
    }
    var op = queuedOps.shift();
    op.func.apply(null,op.args);
}

var queueOp = function(func){
    queuedOps.push({
        func:func,
        args:Array.prototype.splice.call(arguments,1)
    });

}


var log = function(obj){
    if(!inited){
        queueOp(log,obj);
        console.log("need wait");
        return;
    }
    db.collection('log',{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }
        collection.insert(obj,{safe:true},function(err,result){
            if(err){
                console.log(err);
            }
            else{
                 console.log("inserted")
            }
        })
    });
    nextOp();
};

var account = function(obj,cb){

    if(!inited){
        queueOp(account,obj,cb);
        console.log("need wait");
        return;
    }
     db.collection('account',{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }
        collection.findOne({id:obj.id},function(err,data){

            if(!err && !data){
                 collection.insert(obj,{safe:true},function(err,result){
                    if(err){
                          console.log(err);
                     }
                });
            }
            if(cb){
                 cb(data);
            }
        });
    });
     nextOp();

};

var getAccount = function(obj,cb){

    if(!inited){
        queueOp(account,obj,cb);
        console.log("need wait");
        return;
    }
     db.collection('account',{safe:true},function(err,collection){
        if(err){
            console.log(err);
            return;
        }
        collection.findOne({id:obj.id},function(err,data){

            if(!err && data){
                cb(true);
            }else{
                cb(false);
            }
            
        });
    });
     nextOp();

};

var keys = ['a','b','c','d','e','f','g','h','k','m','n','p','q','r','s','t','u','v','w','x','y','z','1','2','3','4','5','6','7','8','9'];
var kc = function(){
    return keys[Math.floor(Math.random()*keys.length)];
};
var ks = function(num){
    var str = "";
    for(var i=0;i<num;++i){
        str += kc();
    }
    return str;

};

var checkAndInsertKey = function(collection,allkeys,num,maxSingleUse,info,onFinish){
    var key = ks(6);
    var curDate = new Date().getTime();
    collection.findOne({id:key},function(err,data){
        if(err){
            onFinish();
            return;
        }
        if(!data){
            collection.insert({id:key,info:info,used:0,maxSingleUse:maxSingleUse,date:curDate},{safe:true},function(err,result){
                if(err){
                    console.log(err);
                }
                else{
                    allkeys.push(key);
                    num--;
                    if(num<=0){
                        onFinish();
                    }
                    else{

                        checkAndInsertKey(collection,allkeys,num,maxSingleUse,info,onFinish);
                    }

                }
            });
        }
        else{

            checkAndInsertKey(collection,allkeys,num,maxSingleUse,info,onFinish);
        }
    })

}

var genkey = function(num,maxSingleUse,info,cb){
    if(!inited){
        queueOp(genkey,num,maxSingleUse,info,cb);
        cb(err,null)
        return;
    }
    db.collection('cdkey',{safe:true},function(err,collection){
        if(err){
            console.log(err);
            cb(err,null)
            return;
        }
        var allkeys = [];
        checkAndInsertKey(collection,allkeys,num,maxSingleUse,info,function(){
            var content = "";
            var a=8;
            var date=new Date();
            var nowDate=""+date.getFullYear()+""+toTwo(date.getMonth()+1)+""+toTwo(date.getDate())+""+toTwo(date.getHours())+""+toTwo(date.getMinutes())+"";
            var path="./keys/keys_"+num+"_"+info+"_"+nowDate+".txt";
            for(var i=0;i<allkeys.length;++i){
                 content +=allkeys[i]+"\r\n";
            }

            //date param file
            fs.writeFile(path,content,function(err){
                cb(err,path);
            });
            
            function toTwo(num){
                return num<10?"0"+num:num;
            }
        });

    })

    nextOp();
};

var addLogItemInfo = function(id,key){
    db.collection('cdkey',{safe:true},function(err,keys){
        keys.findOne({id:key},function(err,data){
            if(err || !data){
                return;
            }
            db.collection('account',{safe:true},function(err,accounts){
                accounts.findOne({id:id},function(e,acc){
                    if(e){
                        return;
                    }
                    var items = acc.items;
                    if(!items){
                        items = [];
                    }
                    if(items.indexOf(data.info)!=-1){
                        return;
                    }
                    console.log(id,key,data.info,items);
                    items.push(data.info);
            accounts.update({id:id},{$set:{items:items}},{},function(err){
                if(err){

                }
                else{

                }
            });

                });
            })
        });
    })
};

var genItemInfos = function(cb){
    if(!inited){
        queueOp(genItemInfos,cb);
        return;
    }
    var temp = {};
    db.collection('log',{safe:true},function(err,logs){
        if(err){
            console.log(err);
            return;
        }
        logs.find({op:"cdkey"}).toArray(function(err,logDats){
            logDats.forEach(function(dat){
                if(dat.p){
                    try{

                     var r = JSON.parse(dat.p);
                     if(r.key.length == 6){
                         if(!temp[r.key]){
                            temp[r.key] = dat.id;
                         }
                         else{
                             if(temp[r.key] != dat.id){
                                 console.log("multi use",r.key,dat.id,temp[r.key]);
                             }
                         }
                     }
                    }
                    catch(e){

                    }
                }
            });
            var arr = [];
            for(var k in temp){
                 arr.push({id:temp[k],key:k});
                addLogItemInfo(temp[k],k);
            }
            console.log("all num:",arr.length)


        })
    })
   nextOp();

}

var usekey = function(key,id,address,cb){
    if(!inited){
        queueOp(usekey,key,cb);
        return;
    }

    db.collection('cdkey',{safe:true},function(err,collection){
        if(err){
            console.log(err);
            cb(err);
            return;
        }
        collection.findOne({id:key},function(err,data){
            if(err) {
                console.log(err);
                cb(err);
                return;
            }
            if(!data){
                cb("invalid key");
                 return;
            }
            if(data.used >= data.maxSingleUse){
                cb("exceed max use");
                return;
            }
            collection.update({id:key,used:{$lt:data.maxSingleUse}},{$inc:{used:1},$set:{user:id,address:address,date:new Date().getTime()}},{},function(err){
                if(err){

                 cb(err);
                }
                else{
                addLogItemInfo(id,key);
                 cb(null,data.info);
                }
            });
        });

    });
    nextOp();
}
var close = function(){
     db.close();
}


var addCampaign = function(param,cb){
if(!inited){
        queueOp(addCampaign,param,cb);
        return;
    }
    db.collection('campaign',{safe:true},function(err,cams){
        cams.findOne({id:param.id},function(err,data){
            if(err){
                cb(err);
                return;
            }
            if(!data){
                 //add campaign
                cams.insert(param,{safe:true},function(err,result){
                    if(err){
                        cb(err);
                    }
                    else{
                        cb(null,{result:true});
                    }
                });
            }
            else{
                // update campaign
                cams.update({id:param.id},param,{},function(err){
                    if(err){
                        cb(err);
                    }
                    else{
                        cb(null,{result:true});
                    }
                })

            }

        });
    })
    nextOp();
};


var delCampaign = function(param,cb){
    db.collection('campaign',{safe:true},function(err,cams){
        cams.deleteOne({id:param.id},function(err,data){
            if(err){
                cb(err);
                return;
            }
            if(!data){
               cb(null,true);
            }
            else{
                 cb(null,true);
            }

        });
    })
};

var allCampaign = function(cb){
    db.collection('campaign',{safe:true},function(err,cams){
        if(err){
            cb(err);
            return;
        }
        cams.find().toArray(function(err,info){
            cb(null,info);
        });
    });
};

var findCampaign = function(obj,cb){
    db.collection('campaign',{safe:true},function(err,cams){
        if(err){
            cb(err);
            return;
        }
        cams.find(obj).toArray(function(err,info){
            cb(null,info);
        });
    });
};

var campaign = function(platform,cb){
if(!inited){
        queueOp(campaign,cb);
        return;
    }

    db.collection('campaign',{safe:true},function(err,cams){
        if(err){
             cb(err);
             return;
        }
        var now = new Date().getTime();
        cams.find({"endTime":{"$gte":now},"platform":platform},function(err,data){
            data.sort({"startTime":1}).limit(1).toArray(function(err,info){
             cb(err,info);
            })
        })
    });
nextOp();
};


module.exports = {
    log:log,
    account:account,
    getAccount:getAccount,
    genkey:genkey,
    usekey:usekey,
    close:close,
    genItemInfos:genItemInfos,
    getCampaign:campaign,
    findCampaign:findCampaign,
    addCampaign:addCampaign,
    delCampaign:delCampaign,
    allCampaign:allCampaign,
};
