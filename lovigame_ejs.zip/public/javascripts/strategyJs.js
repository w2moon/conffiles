(function(){
	var pages=document.getElementById('paging'),
		spanPageNum=document.getElementById('spanPageNum'),
		spanTotalPage=document.getElementById('spanTotalPage'),
		spanFirst=document.getElementById('spanFirst'),
		spanPre=document.getElementById('spanPre'),
		spanNext=document.getElementById('spanNext'),
		spanLast=document.getElementById('spanLast'),
		pageContent=document.getElementById('pageContent'),
		oli=pageContent.querySelectorAll("li"),
		length=oli.length,
		page=1,
		currentRow,
		maxRow,
		pageSize=4;
		spanNext.onclick=next;
		spanPre.onclick=pre;
		spanFirst.onclick=first;
		spanLast.onclick=last;
	function hideTable(){
		for (var i = 0; i < length; i++) {
			oli[i].style.display="none";
		}
	}
	function showPage(){
		spanPageNum.innerHTML=page;
	}
	function preLink(){
		// spanPre.innerHTML="<a href='javascript:pre()'>上一页</a>";
		spanPre.className +=" on";

	}
	function preText(){
		// spanPre.innerHTML="上一页";
		spanPre.className="pagcon";
	}
	function nextLink(){
		// spanNext.innerHTML = "<a href='javascript:next()'>下一页</a>"; 
		spanNext.className +=" on";
	}
	function nextText(){
		// spanNext.innerHTML="下一页";
		spanNext.className ="pagcon";
	}
	function firstLink(){
		// spanFirst.innerHTML="<a href='javascript:pre()'>首页</a>";
		spanFirst.className +=" on";
	}
	function firstText(){
		// spanFirst.innerHTML="首页";
		spanFirst.className="pagcon";
	}
	function lastLink(){
		// spanLast.innerHTML="<a href='javascript:pre()'>尾页</a>";
		spanLast.className +=" on";
	}
	function lastText(){
		// spanLast.innerHTML="尾页";
		spanLast.className="pagcon";
	}
	function pageCount(){
		return Math.ceil(length/pageSize);
	}
//下一页 
	function next(){ 
		hideTable(); 
		currentRow = pageSize * page; 
		maxRow = currentRow + pageSize; 
		if ( maxRow > length ) maxRow = length; 
		for ( var i = currentRow; i< maxRow; i++ ){ 
		oli[i].style.display = 'block'; 
		} 
		page++; 
		if ( maxRow == length ) { 
		nextText(); 
		lastText();
		} 
		showPage(); 
		preLink(); 
		firstLink(); 
	} 
//上一页
	function pre(){
		hideTable();
		page--;
		if(page<1)page=1;
		maxRow=page*pageSize;
		currentRow=maxRow-pageSize;
		for (var i = currentRow; i <maxRow; i++) {
			oli[i].style.display="block";
		}
		if (page==1) {
			preText();
			firstText();
		}
		nextLink();
		lastLink();
		showPage();
	}
//首页
	function first(){
		hideTable();
		page=1;
		for (var i = 0; i < pageSize; i++) {
			oli[i].style.display="block";
		}
		preText();
		firstText();
		nextLink();
		lastLink();
		showPage();
	}
//尾页
	function last(){
		hideTable();
		page=pageCount();
		currentRow=(page-1)*pageSize;
		for (var i = currentRow; i < length; i++) {
			oli[i].style.display="block";
		}
		showPage();
		lastText();
		nextText();
		preLink();
		firstLink();
	}
	function hide(){
		for (var i = pageSize; i < length; i++) {
			oli[i].style.display="none";
		}
		spanPageNum.innerHTML="1";
		spanTotalPage.innerHTML=pageCount();
		nextLink();
		lastLink();
	}
	hide();

})()
//移动端高度自适应
  $(function(){
  	(function(){
  		var width=parseFloat($(width).width()),
        mbanner=$("#mbanner"),
        H=width*0.56;
        if(width<600){
        mbanner.css("height",H+"px");
    }
  	})()
  })
  //窗口改变触发的事件
	// window.onresize = function () {
	// 	var w=document.body.clientWidth || document.documentElement.clientWidth;
	// 	alert(w);
	// 	var h=0.548*w;

 //  }
 //  	window.re
 $(window).resize(function () {         
    var w=$(window).width();
    	h=0.64*w;
    	if(w<599){
    	$("#content-l").css("top",h+"px");
    	}else{
    	$("#content-l").css("top","475px");
    	}
});
