$(document).ready(function(){
	(function(){
		var table = document.getElementById("table"),
			totalPage = document.getElementById("spanTotalPage"),//总页数
			pageNum = document.getElementById("spanPageNum"), //获取当前页<span> 
			spanPre = document.getElementById("spanPre"),//获取上一页<span> 
			spanNext = document.getElementById("spanNext"),//获取下一页<span> 
			numberRowsInTable = table.querySelectorAll("tr"),//获取所有记录
			length= numberRowsInTable.length,//记录总条数
		 	pageSize = 10, //每页显示的记录条数 
		 	currentRow,
		 	maxRow,
			page = 1; //当前页，默认第一页 
			spanPre.onclick=pre;
			spanNext.onclick=next;
		function next(){
			if(page<pageCount()){
				hideTable();
				currentRow=page*pageSize;
				maxRow=currentRow+pageSize;
				if (maxRow>length) maxRow=length;
				for (var i = currentRow; i < maxRow; i++) {
					numberRowsInTable[i].style.display="";
				}
				page++;
				if (page==pageCount()) {
					nextText();
				}else{
					nextLink();
				}
			}
		
			prelLink();
			showPage();
		}
		function pre(){
			if(page>1){
				hideTable();
				page--;
				maxRow=page*pageSize;
				currentRow=maxRow-pageSize;
				if (currentRow<0) currentRow=0;
				for (var i = currentRow; i < maxRow; i++) {
					numberRowsInTable[i].style.display="";
				}
				if (currentRow==0) {
					preText();
				}else{
					prelLink();
				}
			}
		
				nextLink();
				showPage();
		
		
		}
		function prelLink(){
			spanPre.className="btn";
		}
		function preText(){
			spanPre.className="btn on";
		}
		function nextLink(){
			spanNext.className="btn";
		}
		function nextText(){
			spanNext.className="btn on";
		}
		function pageCount(){
			return Math.ceil(length/pageSize);
		}
		function hideTable(){
			for (var i = 0; i < length; i++) {
				numberRowsInTable[i].style.display="none";
			}
		}
		function showPage(){
			pageNum.innerHTML=page;
		}
		function hide(){
			for (var i = pageSize; i < length; i++){
				numberRowsInTable[i].style.display="none";
			}
			pageNum.innerHTML=1;
			totalPage.innerHTML=pageCount();
			preText();
		}
		hide();

		$("#jump").bind("click",function(){
			var jumpPage=$("#jumpPage input").val();
			hideTable();
			page=jumpPage;
			currentRow=(page-1)*pageSize;
			maxRow=currentRow+pageSize;
			if (maxRow>length) maxRow=length;
			for (var i = currentRow; i < maxRow; i++) {
				numberRowsInTable[i].style.display="";
			}
			if (page==pageCount()) {
				nextText();
			}else{
				nextLink();
			}
			if (currentRow==0) {
				preText();
			}else{
				prelLink();
			}
			showPage();

		})

		$("#submit").bind("click",function(){
			table.innerHTML="";
			var userId=$("#user").val();
			if(!userId){
				alert("请输入用户ID");
			}else{
				$.ajax({
					type:"POST",
					url:"/searchEvent",
					data:"userId="+userId,
					success:function(result){
						if(!result){
							alert("用户名不存在");
						}else{
							for (var i = 0; i < result.length; i++) {
								var otr=document.createElement("tr");
								for (var j = 0; j < 5; j++) {
									var otd=document.createElement("td");
									var html;
									switch(j){
										case 0:
											html=i+1;
										break;
										case 1:
											html=result[i].platform;
										break;
										case 2:
											html=result[i].event.replace(/\"/g,"");
										break;
										case 3:
											var paramObj=JSON.parse(result[i].params);
											var h='<p class="paramH"><span class="l">名称</span><span class="r">属性</span></p>';
											for(var atr in paramObj){
												var b='<p class="paramB"><span class="l">'+atr+'</span><span class="r">'+paramObj[atr]+'</span></p>';
												h+=b;
											}
											html=h;
										break;
										case 4:
											html=getLocalDate(new Date(parseInt(result[i].time)));
										break;
									}
									otd.innerHTML=html;
									otr.appendChild(otd);
								}
								table.appendChild(otr);
								numberRowsInTable = table.querySelectorAll("tr"),//获取所有记录
								length= numberRowsInTable.length,//记录总条数
								hide();
							}
						}
					}
				});
			}
		})

		function toTwo(num){
			return num<10?"0"+num:num;
		}
		function getLocalDate(date){
			return date.getFullYear()+"-"+toTwo(date.getMonth()+1)+"-"+toTwo(date.getDate())+" "+toTwo(date.getHours())+":"+toTwo(date.getMinutes());
		}

	})()
})