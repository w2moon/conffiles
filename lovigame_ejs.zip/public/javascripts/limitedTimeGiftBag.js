$(document).ready(function(){
(function(){
	var table = document.getElementById("table"),
		totalPage = document.getElementById("spanTotalPage"),//总页数
		pageNum = document.getElementById("spanPageNum"), //获取当前页<span> 
		spanPre = document.getElementById("spanPre"),//获取上一页<span> 
		spanNext = document.getElementById("spanNext"),//获取下一页<span> 
		numberRowsInTable = table.querySelectorAll("tr"),//获取所有记录
		length= numberRowsInTable.length,//记录总条数
	 	pageSize = 5, //每页显示的记录条数 
	 	currentRow,
	 	maxRow,
		page = 1;//当前页，默认第一页 
		spanPre.onclick=pre;
		spanNext.onclick=next;
	function next(){
		if(page<pageCount()){
			hideTable();
			currentRow=page*pageSize;
			maxRow=currentRow+pageSize;
			if (maxRow>length) maxRow=length;
			for (var i = currentRow; i < maxRow; i++) {
				numberRowsInTable[i].style.display="";
			}
			page++;
			if (page==pageCount()) {
				nextText();
			}
		}
	
		prelLink();
		showPage();
	}
	function pre(){
		if(page>1){
			hideTable();
			page--;
			maxRow=page*pageSize;
			currentRow=maxRow-pageSize;
			if (currentRow<0) currentRow=0;
			for (var i = currentRow; i < maxRow; i++) {
				numberRowsInTable[i].style.display="";
			}
			if (currentRow==0) {
				preText();
			}
		}
	
			nextLink();
			showPage();
	
	
	}
	function prelLink(){
		spanPre.className="btn";
	}
	function preText(){
		spanPre.className="btn on";
	}
	function nextLink(){
		spanNext.className="btn";
	}
	function nextText(){
		spanNext.className="btn on";
	}
	function pageCount(){
		return Math.ceil(length/pageSize);
	}
	function hideTable(){
		for (var i = 0; i < length; i++) {
			numberRowsInTable[i].style.display="none";
		}
	}
	function showPage(){
		pageNum.innerHTML=page;
	}
	function hide(){
		for (var i = pageSize; i < length; i++){
			numberRowsInTable[i].style.display="none";
		}
		pageNum.innerHTML=1;
		totalPage.innerHTML=pageCount();
		preText();
	}
	hide();


	
 $("#uploadPic1").click(function(){
 	var file=$("#uploadPic1");
 	var smallPic=$("#showSmallPic1");
 	file.val("");
 	showFileName(file,smallPic);
 })
 $("#uploadPic2").click(function(){
 	var file=$("#uploadPic2");
 	var maxPic=$("#showMaxPic1");
 	file.val("");
 	showFileName(file,maxPic);
 })

 function showFileName(file,picName){
 	var time=setInterval(function(){
 		var fileName=file.val();
 		if (fileName!="") {
 			if (typePic(fileName)) {
 				picName.html(getFileName(fileName)).css({"font-size":"14px","left":"0px"});
 				clearInterval(time);
 			}else{
 				file.val("");
 				clearInterval(time);
 			}
 			
 		}
 	},50)
 }


 	$('#uploadPic1').change(function(event) {
 		var smallImg=$('#uploadPic1')[0].files[0];
	    var formData = new FormData($("#myform1"));
	    formData.append("avatar",smallImg);
	    $.ajax({
	      type: 'POST',
	      url: '/limitedTimeGiftBag/uploadImg',
	      data: formData,
	      cache:false,
		  contentType:false,
	      processData:false,
	      success: function (data) {
	      	if (data) {
	      		console.log("success");
	      	}
	      },
	      error: function (err) {
	        console.log(err.message);
	      }
	    })
	});

	$('#uploadPic2').change(function(event) {
 		var smallImg=$('#uploadPic2')[0].files[0];
	    var formData = new FormData($("#myform2"));
	    formData.append("avatar",smallImg);
	    $.ajax({
	      type: 'POST',
	      url: '/limitedTimeGiftBag/uploadImg',
	      data: formData,
	      cache:false,
		  contentType:false,
	      processData:false,
	      success: function (data) {
	        if (data) {
	      		console.log("success");
	      	}
	      },
	      error: function (err) {
	        console.log(err.message);
	      }
	    })
	});




 function getFileName(path){
		var pos1 = path.lastIndexOf('/');
		var pos2 = path.lastIndexOf('\\');
		var pos  = Math.max(pos1, pos2)
		if( pos<0 ){
			return path;
		}else{
			return path.substring(pos+1);
		}
		
	}
 function typePic(fileName){ 
	    var suffixIndex=fileName.lastIndexOf(".");  
	    var suffix=fileName.substring(suffixIndex+1).toUpperCase();  
	    if(suffix!="BMP"&&suffix!="JPG"&&suffix!="JPEG"&&suffix!="PNG"&&suffix!="GIF"){  
	    alert("请上传图片（格式BMP、JPG、JPEG、PNG、GIF等）!"); 
	    return false;
	}else{
		return true;
	}
}

  

  	
	var kc = function(){
		var keys = ['a','b','c','d','e','f','g','h','k','m','n','p','q','r','s','t','u','v','w','x','y','z','1','2','3','4','5','6','7','8','9'];
	    return keys[Math.floor(Math.random()*keys.length)];
	};
	function createId(num){
	    var str = "c";
	    for(var i=0;i<num;++i){
	        str += kc();
	    }
	    return str;

	};

$("#gifPrice").blur(function(){
	var priceVal=$("#gifPrice").val();
	var pat=/^[0-9]*[1-9][0-9]*$/
	if (priceVal && !priceVal.match(pat)) {
		alert("礼包价格必须为整数");
		$("#gifPrice").val("")
		$("#gifPrice").focus();
		return;
	}
});




$("#createGift").bind("click", function () {
	var gifname=$("#gifname").val();
	var startDate=$("#startDate").val();
	var startTime=$("#startTime").val();
	var endDate=$("#endDate").val();
	var endTime=$("#endTime").val();
	var goods1=$("#goods1").val();
	var goods1Num=$("#goods1Num").val();
	var goods2=$("#goods2").val();
	var goods2Num=$("#goods2Num").val();
	var goods3=$("#goods3").val();
	var goods3Num=$("#goods3Num").val();
	var goods4=$("#goods4").val();
	var goods4Num=$("#goods4Num").val();
	var gifPrice=$("#gifPrice").val();
	var smallPic=$("#uploadPic1").val();
	var bigPic=$("#uploadPic2").val();
	
	if (!gifname) {
		alert("请输入礼包名称");
	} else if(!startTime || !startDate){
		alert("请输入开始时间");
	}else if(!endTime || !endDate){
		alert("请输入结束时间")
	}else if(startDate>endDate){
		alert("开始时间必须小于结束时间");
	}else if(!goods1 && !goods2 && !goods3 && !goods4){
		alert("请输入礼包内容");
	}else if(!gifPrice){
		alert("请输入礼包价格");
	}else if(!smallPic || !bigPic) {
		alert("请上传图片");
	}else{
		var smallPic=getFileName(smallPic);
		var bigPic=getFileName(bigPic);
		var id=createId(20);
		var giftPacks={
			id:id,
			gifname:gifname,
			startTime:startDate+" "+startTime,
			endTime:endDate+" "+endTime,
			gifPrice:gifPrice,
			smallPic:smallPic,
			bigPic:bigPic
		}
		if (goods1 && goods1Num){
			giftPacks.goods1=goods1;
			giftPacks.goods1Num=goods1Num;
		}else{
			giftPacks.goods1=null;
			giftPacks.goods1Num=null;
		}
		if (goods2 && goods2Num){
			giftPacks.goods2=goods2;
			giftPacks.goods2Num=goods2Num;
		}else{
			giftPacks.goods2=null;
			giftPacks.goods2Num=null;
		}
		if (goods3 && goods3Num){
			giftPacks.goods3=goods3;
			giftPacks.goods3Num=goods3Num;
		}else{
			giftPacks.goods3=null;
			giftPacks.goods3Num=null;
		}
		if (goods4 && goods4Num){
			giftPacks.goods4=goods4;
			giftPacks.goods4Num=goods4Num;
		}else{
			giftPacks.goods4=null;
			giftPacks.goods4Num=null;
		}

		$.ajax({
	    type: 'POST',
	    url: '/limitedTimeGiftBag/find',
	    data: "startTime="+giftPacks.startTime+"&endTime="+giftPacks.endTime,
		success:function(data){
			console.log(data);
			if (data) {
				alert("礼包售卖时间和礼包 "+data.result+" 的售卖时间冲突");
			}else {
				$.ajax({
				    type: 'POST',
				    url: '/limitedTimeGiftBag/creatGifts',
				    data: giftPacks,
					success:function(data){
						if (!data) {
							alert("生成失败");
							console.log("insert error");
						} else {
							alert("生成成功");
							console.log("insert success");
							var otr=document.createElement("tr");
							var tbody=document.querySelector("#table");
							for (var i = 0; i < 8; i++) {
							var otd=document.createElement("td");
							var html="";
								switch(i){
									case 0:
									html="<div>1</div>";
									break;
									case 1:
									html="<div>"+data.result.giftId+"</div>";
									break;
									case 2:
									html="<div>"+data.result.gifName+"</div>";
									break;
									case 3:
									html="<div>"+data.result.gifPrice+"</div>";
									break;
									case 4:
									if (data.result.goods1){
										html="物品,数量;"+data.result.goods1+","+data.result.goods1Num;
									}
									if (data.result.goods2){
										html+=";"+data.result.goods2+","+data.result.goods2Num;
									}
									if (data.result.goods3){
										html+=";"+data.result.goods3+","+data.result.goods3Num;
									}
									if (data.result.goods4){
										html+=";"+data.result.goods4+","+data.result.goods4Num;
									}
										html="<div>"+html+"</div>";
									break;
									case 5:
									html="<div>"+data.result.startTime+"至"+data.result.endTime+"</div>";
									break;
									case 6:
									html="<div><a href='/imgfile/"+data.result.smallPic+"' target='_blank' style='color:#000'>"+data.result.smallPic+"</a>,<a href='/imgfile/"+data.result.bigPic+"' target='_blank' style='color:#000'>"+data.result.bigPic+"</a></div>";
									break;
									case 7:
									html="<div>删除</div>";
									break;
								}
								otd.innerHTML=html;
								otr.appendChild(otd);
							}
							otr.className=data.result.id;
							tbody.insertBefore(otr,tbody.firstChild);
							window.location.reload();
							numberRowsInTable = table.querySelectorAll("tr"),//获取所有记录
							length= numberRowsInTable.length,//记录总条数
							hide();
							deleteLine();
						}
					}
				});
			}
		}

		});
	}
	    
	});

			deleteLine();
			function deleteLine(){
			var index;
			var otd=document.querySelectorAll("#table tr td:last-child");
				for (var i = 0; i < otd.length; i++) {
					otd[i].index=i;
					otd[i].onclick=function(){
						index=this.index;
						var flog=confirm("确定删除吗？");
						if (flog) {
							deleteAjax(this.parentNode.className,index);
						}
					}
				}
			}
			function deleteAjax(id,index){
    			$.ajax({
    				type: 'GET',
				    url: '/limitedTimeGiftBag/deleteLine',
				    data: 'id='+id,
				    success:function(data){
				    	if (data.result) {
				    		alert("删除成功");
				    		console.log(data.result);
				    		window.location.reload();
				    		numberRowsInTable[index].parentNode.removeChild(numberRowsInTable[index]);
				    	} else {
				    		alert("删除失败");
				    	}
				    }
    			})
			
			}

			
			


})()
})