window.onload=function(){
	var quit=document.querySelector("#header .headbox .right");
	if (quit) {
		quit.onclick=function(){
			var flag=confirm("确定退出吗？");
			if(flag){
				window.location.href="/login";
				return false;
			}
		}
	}
		

}
	
