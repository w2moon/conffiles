$(document).ready(function(){
	(function(){
		var userId=$("#userId"),
			email=$("#email"),
			newPwd=$("#newPwd"),
			prompt2=$("#formBox .prompt1"),
			submit=$("#submit");
			confirmPwd=$("#confirmPwd");
		email.blur(function(){
			emailVal=email.val();
			if (emailVal==""){
				alert("请输入邮箱");
			} else {
				find(emailVal);
			}

		})

		function find(emailVal){
			$.ajax({
				type:'GET',
				url:'/personMaterial/user',
				data:'email='+emailVal,
				success:function(result){
					if (result.result) {
						$("#formBox .prompt").css("display","none");
					}else{
						$("#formBox .prompt").css("display","inline-block");
					}
				}

			})
		}

		submit.click(function(){
			var userIdVal=userId.val(),
				emailVal=email.val(),
				newPwdVal=newPwd.val(),
				confirmPwdVal=confirmPwd.val();
				if (newPwdVal!=confirmPwdVal) {
					alert("两次密码不一致");
				} else {
				var data={
					userId:userIdVal,
					email:emailVal,
					newPwd:newPwdVal,
					confirmPwd:confirmPwdVal
				}
				submitData(data);
			}
			
		})
		function submitData(data){
			$.ajax({
				type:'POST',
				url:'/personMaterial',
				data:data,
				success:function(result){
					if (result) {
						alert("修改成功,请重新登陆");
						window.location.href='/login';
					}
				}
			})
		}
	})()
})