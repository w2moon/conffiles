$(document).ready(function(){
	(function(){
		var table = document.getElementById("table"),
			totalPage = document.getElementById("spanTotalPage"),//总页数
			pageNum = document.getElementById("spanPageNum"), //获取当前页<span> 
			spanPre = document.getElementById("spanPre"),//获取上一页<span> 
			spanNext = document.getElementById("spanNext"),//获取下一页<span> 
			numberRowsInTable = table.querySelectorAll("tr"),//获取所有记录
			removeBtn = document.getElementById("removeBtn"),
			length= numberRowsInTable.length,//记录总条数
		 	pageSize = 9, //每页显示的记录条数 
		 	currentRow,
		 	maxRow,
		 	index,
			page = 1; //当前页，默认第一页 
			spanPre.onclick=pre;
			spanNext.onclick=next;
		function next(){
			if(page<pageCount()){
				hideTable();
				currentRow=page*pageSize;
				maxRow=currentRow+pageSize;
				if (maxRow>length) maxRow=length;
				for (var i = currentRow; i < maxRow; ++i) {
					numberRowsInTable[i].style.display="";
				}
				page++;
				if (page==pageCount()) {
					nextText();
				}
			}
		
			prelLink();
			showPage();
		}
		function pre(){
			if(page>1){
				hideTable();
				page--;
				maxRow=page*pageSize;
				currentRow=maxRow-pageSize;
				if (currentRow<0) currentRow=0;
				for (var i = currentRow; i < maxRow; i++) {
					numberRowsInTable[i].style.display="";
				}
				if (currentRow==0) {
					preText();
				}
			}
		
				nextLink();
				showPage();
		
		
		}
		function prelLink(){
			spanPre.className="btn";
		}
		function preText(){
			spanPre.className="btn on";
		}
		function nextLink(){
			spanNext.className="btn";
		}
		function nextText(){
			spanNext.className="btn on";
		}
		function pageCount(){
			return Math.ceil(length/pageSize);
		}
		function hideTable(){
			for (var i = 0; i < length; i++) {
				numberRowsInTable[i].style.display="none";
			}
		}
		function showPage(){
			pageNum.innerHTML=page;
		}
		function hide(){
			for (var i = pageSize; i < length; i++){
				numberRowsInTable[i].style.display="none";
			}
			pageNum.innerHTML=1;
			totalPage.innerHTML=pageCount();
			preText();
		}
		hide();
		function check(){
			for (var i = 0; i < length; i++) {
				numberRowsInTable[i].index=i;
				numberRowsInTable[i].onclick=function(){
					index=this.index;
					for (var i = 0; i <length; i++) {
						numberRowsInTable[i].style.backgroundColor="#9faaae";
					}
					this.style.backgroundColor="#dbdfe1";
				}
			}
		}
		check();
		var removeBtn=document.querySelector("#setPermission .rightBox .removeBtn");
		removeBtn.onclick=remove;
		function remove(){
			var tr=numberRowsInTable[index]
			tr.parentNode.removeChild(tr);
			index='';
		}
		addMember();
		function addMember(){
			var submit=$("#submit");
			submit.click(function(){
				var userId=$("#userId").val();
				var email=$("#email").val();
				var remark=$("#remark").val();
				var checks=document.querySelectorAll("#checkBox .checks");
				var checkVal=[];
				var date=new Date();
				var nowDate=""+date.getFullYear()+"."+(date.getMonth()+1)+"."+date.getDate()+"";
				for (var i = 0; i < checks.length; i++) {
					if (checks[i].checked) {
						checkVal[i]=checks[i].value;
					} else {
						checkVal[i]=false;
					}
				}
				if (userId=="") {
					alert("请输入用户名");
				} else if(email==""){
					alert("请输入用户邮箱");
				}else if(checkVal.length==0) {
					alert("请设置新增成员的权限");
				}else{
					$.ajax({
						type:'POST',
						url:'/setPermission',
						data:{
							userId:userId,
							email:email,
							remark:remark,
							inspect:checkVal[0],
							limitPass:checkVal[1],
							grantCode:checkVal[2],
							transactionRecord:checkVal[3],
							sendMail:checkVal[4],
							globalMail:checkVal[5],
							queryMails:checkVal[6],
							nowDate:nowDate,
							password:email
						},
						success:function(data){
							var otr=document.createElement("tr");
							var tbody=document.querySelector("#table tbody");
							for (var i = 0; i < 4; i++) {
							var otd=document.createElement("td");
							var html="";
								switch(i){
									case 0:
									html=data.userId;
									break;
									case 1:
									html=data.email;
									break;
									case 2:
									html=data.nowDate;
									break;
									case 3:
									html=data.remark;
									break;
								}
							otd.innerHTML=html;
							otr.appendChild(otd);
							}
							otr.className=data.email;
							tbody.insertBefore(otr,tbody.firstChild);
							numberRowsInTable = table.querySelectorAll("tr"),//获取所有记录
							length= numberRowsInTable.length,//记录总条数
							hide();
						}
					})
				}
			});
		}



		document.onkeydown=function(event){
		  	var e = event || window.event || arguments.callee.caller.arguments[0];
				if(e && e.keyCode==46){ 
					removeLine();
				}
		}
		removeBtn.onclick=removeLine;
		function removeLine(){
			if (numberRowsInTable[index].className=="644265454@qq.com") {
				alert("管理员身份不能被删除");
			} else {
				var flog=confirm("确认删除该成员吗？");
					if (flog) {
						var name=numberRowsInTable[index].className;
						deleteAjax(name)
					}
			}
			
		}
		function deleteAjax(name){
			$.ajax({
				type: 'GET',
			    url: '/deleteUser',
			    data: 'name='+name+'&baseName=manager',
			    success:function(data){
			    	if (data.result) {
			    		alert("删除成功");
			    		numberRowsInTable[index].parentNode.removeChild(numberRowsInTable[index]);
			    	} else {
			    		alert("删除失败");
			    	}
			    }
			})
		
		}

	})()
})