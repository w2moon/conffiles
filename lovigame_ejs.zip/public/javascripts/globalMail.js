$(document).ready(function(){
	(function(){

		var table = document.getElementById("table"),
			totalPage = document.getElementById("spanTotalPage"),//总页数
			pageNum = document.getElementById("spanPageNum"), //获取当前页<span> 
			spanPre = document.getElementById("spanPre"),//获取上一页<span> 
			spanNext = document.getElementById("spanNext"),//获取下一页<span> 
			numberRowsInTable = table.querySelectorAll("tr"),//获取所有记录
			length= numberRowsInTable.length,//记录总条数
		 	pageSize = 5, //每页显示的记录条数 
		 	currentRow,
		 	maxRow,
			page = 1; //当前页，默认第一页 
			spanPre.onclick=pre;
			spanNext.onclick=next;
		function next(){
			if(page<pageCount()){
				hideTable();
				currentRow=page*pageSize;
				maxRow=currentRow+pageSize;
				if (maxRow>length) maxRow=length;
				for (var i = currentRow; i < maxRow; i++) {
					numberRowsInTable[i].style.display="";
				}
				page++;
				if (page==pageCount()) {
					nextText();
				}
			}
		
			prelLink();
			showPage();
		}
		function pre(){
			if(page>1){
				hideTable();
				page--;
				maxRow=page*pageSize;
				currentRow=maxRow-pageSize;
				if (currentRow<0) currentRow=0;
				for (var i = currentRow; i < maxRow; i++) {
					numberRowsInTable[i].style.display="";
				}
				if (currentRow==0) {
					preText();
				}
			}
		
				nextLink();
				showPage();
		
		
		}
		function prelLink(){
			spanPre.className="btn";
		}
		function preText(){
			spanPre.className="btn on";
		}
		function nextLink(){
			spanNext.className="btn";
		}
		function nextText(){
			spanNext.className="btn on";
		}
		function pageCount(){
			return Math.ceil(length/pageSize);
		}
		function hideTable(){
			for (var i = 0; i < length; i++) {
				numberRowsInTable[i].style.display="none";
			}
		}
		function showPage(){
			pageNum.innerHTML=page;
		}
		function hide(){
			for (var i = pageSize; i < length; i++){
				numberRowsInTable[i].style.display="none";
			}
			pageNum.innerHTML=1;
			totalPage.innerHTML=pageCount();
			preText();
		}
		hide();

		function toTwo(num){
        	return num<10?"0"+num:num;
    		}
		function getLocalTime(date) {     
       			return date.getFullYear()+"-"+toTwo(date.getMonth()+1)+"-"+toTwo(date.getDate())+" "+toTwo(date.getHours())+":"+toTwo(date.getMinutes());     
    		}
    	function getLocalDate(date) {     
       			return date.getFullYear()+"-"+toTwo(date.getMonth()+1)+"-"+toTwo(date.getDate())+"T"+toTwo(date.getHours())+":"+toTwo(date.getMinutes());     
    		}

		$("#items .btn").click(function(){
			$("#items .btn").before('<p class="item"><input class="itemid" type="text" name=""><input class="itemnum" type="number" min="0" name=""></p>');

		});
		$("#emailSubmit").click(function(){
			var startDate=$("#startTime").val();
			var endDate=$("#endTime").val();
			var eTitle=$("#eTitle").val();
			var eContent=$("#eContent").val();
			var itemId=document.querySelectorAll("#itemBox .itemid");
			var itemNum=document.querySelectorAll("#itemBox .itemnum");
			var items=[];
			for (var i = 0; i < itemId.length; i++) {
				if (itemId[i].value && itemNum[i].value){
					var obj={
						"id":itemId[i].value,
						"num":itemNum[i].value,
						"used":false
					}
					items.push(obj);
				}
			}
			if(!startDate){
				alert("请输入起始时间");
			}else if(!endDate){
				alert("请输入结束时间");
			}else if(startDate>endDate){
				alert("开始时间不能大于结束时间");
			}else if(!eTitle){
				alert("请输入邮件标题");
			}else if(!eContent){
				alert("请输入邮件内容");
			}else if(items.length==0){
				alert("请输入物品内容");
			}else{
				var startTime=new Date(startDate).getTime();
				var endTime=new Date(endDate).getTime();
				var itemsStr=JSON.stringify(items);
				$.ajax({
					type:"POST",
					url:"/globalMail",
					data:{
						title:eTitle,
						content:eContent,
						items:itemsStr,
						startTime:startTime,
						endTime:endTime
					},
					success:function(result){
						if (!result){
							alert("添加失败");
						}else{
							alert("添加成功");
							var starttime=getLocalTime(new Date(parseInt(result.startTime)));
							var endtime=getLocalTime(new Date(parseInt(result.endTime)));
							var otr=document.createElement("tr");
							for (var i = 0; i < 8; i++) {
								var otd=document.createElement("td");
								var html;
								switch(i){
									case 0:
									html="<div>"+result.id+"</div>";
									break;
									case 1:
									html="<div>"+result.title+"</div>";
									break;
									case 2:
									html="<div>"+result.content+"</div>";
									break;
									case 3:
									var itemlist=JSON.parse(result.items);
									var h='<p class="itemlisth"><span class="l">物品ID</span><span class="c">数量</span><span class="r">领取状态</span></p>';
									
									for (var j = itemlist.length-1; j >=0;j--) {
										var b='<p class="itemlistd"><span class="l">'+itemlist[j].id+'</span><span class="c">'+itemlist[j].num+'</span><span class="r">'+itemlist[j].used+'</span></p>';
										
										h+=b;
									}
									html="<div>"+h+"</div>";
									break;
									case 4:
									html="<div>"+starttime+"</div>";
									break;
									case 5:
									html="<div>"+endtime+"</div>";
									break;
									case 6:
									html="<div class='update'>修改</div>";
									break;
									case 7:
									html="<div>删除</div>";
									break;
								}
								otd.innerHTML=html;
								otr.className=result.id;
								otr.appendChild(otd);
							}
							table.insertBefore(otr,table.firstChild);
							numberRowsInTable = table.querySelectorAll("tr"),//获取所有记录
							length= numberRowsInTable.length,//记录总条数
							hide();
							deleteLine();
							update();
						}
					}
				});
			}
		})

			deleteLine();
			function deleteLine(){
			var index;
			var otd=document.querySelectorAll("#table tr td:last-child");
				for (var i = 0; i < otd.length; i++) {
					otd[i].index=i;
					otd[i].onclick=function(){
						index=this.index;
						var flog=confirm("确定删除吗？");
						if (flog) {
							deleteAjax(this.parentNode.className,index);
						}
					}
				}
			}
			function deleteAjax(id,index){
    			$.ajax({
    				type: 'GET',
				    url: '/globalMail/delete',
				    data: 'id='+id,
				    success:function(data){
				    	if (data.result) {
				    		alert("删除成功");
				    		numberRowsInTable[index].parentNode.removeChild(numberRowsInTable[index]);
				    	} else {
				    		alert("删除失败");
				    	}
				    }
    			})
			
			}

			update();
			function update(){
				var otd=document.querySelectorAll("#table tr .update");
					for (var i = 0; i < otd.length; i++) {
						otd[i].onclick=function(){
							$("#screenBox").css("display","block");
							$("body").css("overflow","hidden");
							var emailId=this.parentNode.parentNode.className;
								$.ajax({
									type:"POST",
									url:"/globalMail/find",
									data:"id="+emailId,
									success:function(data){
										if(data){
											var startTime=getLocalDate(new Date(parseInt(data.startTime)));
											var endTime=getLocalDate(new Date(parseInt(data.endTime)));
											var items=JSON.parse(data.items);
											if (items.length>5){
												for (var i = 0; i < items.length-5; i++) {
													$("#itbox .btn").before('<p class="item"><input class="upitemid" type="text" name=""><input class="upitemnum" type="number" min="0" name=""></p>');
												}
											}
											var upItemId=document.querySelectorAll("#itbox .upitemid");
											var upItemNum=document.querySelectorAll("#itbox .upitemnum");
											for (var i = 0; i < items.length; i++) {
												upItemId[i].value=items[i].id;
												upItemNum[i].value=items[i].num;
											}
											$("#emailId").val(data.id);
											$("#starttime").val(startTime);
											$("#endtime").val(endTime);
											$("#etitle").val(data.title);
											$("#econtent").val(data.content);
										}
									}
								});
						}
					}
			}

			$("#itbox .btn").click(function(){
				$("#itbox .btn").before('<p class="item"><input class="upitemid" type="text" name=""><input class="upitemnum" type="number" min="0" name=""></p>');

			});

			$("#cancel").click(function(){
				$("#screenBox").css("display","none");
				$("body").css("overflow","auto");
			});

			$("#save").click(function(){
				$("#screenBox").css("display","none");
				$("body").css("overflow","auto");
				var id=$("#emailId").val();
				var startDate=$("#starttime").val();
				var endDate=$("#endtime").val();
				var eTitle=$("#etitle").val();
				var eContent=$("#econtent").val();
				var itemId=document.querySelectorAll("#itbox .upitemid");
				var itemNum=document.querySelectorAll("#itbox .upitemnum");
				var items=[];
				for (var i = 0; i < itemId.length; i++) {
					if (itemId[i].value && itemNum[i].value){
						var obj={
							"id":itemId[i].value,
							"num":itemNum[i].value,
							"used":false
						}
						items.push(obj);
					}
				}
				if(!startDate){
					alert("请输入起始时间");
				}else if(!endDate){
					alert("请输入结束时间");
				}else if(startDate>endDate){
					alert("开始时间不能大于结束时间");
				}else if(!eTitle){
					alert("请输入邮件标题");
				}else if(!eContent){
					alert("请输入邮件内容");
				}else if(items.length==0){
					alert("请输入物品内容");
				}else{
					var startTime=new Date(startDate).getTime();
					var endTime=new Date(endDate).getTime();
					var itemsStr=JSON.stringify(items);
					$.ajax({
						type:"POST",
						url:"/globalMail/update",
						data:{
							id:id,
							startTime:startTime,
							endTime:endTime,
							title:eTitle,
							content:eContent,
							items:itemsStr
						},
						success:function(result){
							if(!result){
								alert("修改失败");
							}else{
								alert("修改成功");
								window.location.reload();
							}
						}
					});
				}
				
			})
			
			getSendNum();
			setInterval(function(){
				getSendNum();
			},5000)
			function getSendNum(){
				$.ajax({
					type:"GET",
					url:"/globalMail/sendNum",
					data:"SendMode=auto",
					success:function(data){
						$("#sendNum").html(data.result);
					}
				})
			}

	})()
})