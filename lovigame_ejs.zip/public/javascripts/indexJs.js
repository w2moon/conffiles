$(document).ready(function(){
	//游戏列表动画效果
	$(function(){
		var oDt=$("#mznav .wbox .mznav-list dt"),
			oDd=$("#mznav .wbox .mznav-list dd"),
			clickFlage=false;
		oDt.click(function(){
			if (clickFlage) {
				oDt.removeClass("open");
				oDd.slideUp(300);
			} else {
				oDt.addClass("open");
				oDd.slideDown(300);
			}
			clickFlage=!clickFlage;
		})
	})
	//banner轮播
	$(function () {
    var $tab = $("#banner .b-tab ul li"),
        $part = $("#banner .b-part .part"),
        $banner = $("#banner"),
        length = $tab.length,
        index = 0,
        timer = null;

    $tab.eq(0).addClass('on');
    $part.eq(0).show();

    $tab.click(function () {
        var i = $(this).index();
        if ( i !== index){
            change(function () {
                index = i;
            });
        }
    });

    auto();
    $banner.hover(function () {
        clearInterval(timer);
    },auto);
    function auto() {
        timer = setInterval(function () {
            change(function () {
                index ++;
                index %= length;
            });
        },3000)
    }
    function change(fn) {
        $part.eq(index).fadeOut(500);
        $tab.eq(index).removeClass('on');
        fn && fn();
        $part.eq(index).fadeIn(500);
        $tab.eq(index).addClass('on');
    }
});
	$(function(){
		var oHz=$("#mzgamelist li.hz"),
			oMzgamelist=$("#mzgamelist li.hz .mzgamelist-game");
		oHz.mouseenter(function(){
			oMzgamelist.fadeIn(300);
		});
		oHz.mouseleave(function(){
			oMzgamelist.fadeOut(300);
		})
	})

    //轮播高度自适应
         $(function(){
        var width=parseFloat($(document).width()),
            banner=$("#banner"),
            H=width*1.51;
            if(width<600){
                banner.css("height",H+"px");
            }
        
        
    })   

})