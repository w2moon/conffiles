// 产品中心列表动画
$(function(){
		var oHz=$("#mznews .gamelist li.hz"),
			oMzgamelist=$("#mznews .gamelist li.hz .mzgamelist-game");
		oHz.mouseenter(function(){
			oMzgamelist.fadeIn(300);
		});
		oHz.mouseleave(function(){
			oMzgamelist.fadeOut(300);
		})
	})