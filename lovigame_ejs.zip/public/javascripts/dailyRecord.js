$(document).ready(function(){
	(function(){
		$("#search").bind("click",function(){
			var vn=$("#vn").val();
			var startDate=$("#startDate").val();
			var endDate=$("#endDate").val();
			if(!startDate){
				alert("请输入开始时间");
			}else if(!endDate){
				alert("请输入结束时间")
			}else if(startDate>endDate){
				alert("开始时间不能大于结束时间");
			}else{
				var startTime=new Date(startDate).getTime()-28800000;
				var endTime=new Date(endDate).getTime()+57599999;
				var platform=vn?vn:null;
				$.ajax({
					type:"POST",
					url:"/dailyRecord",
					data:{
						startTime:startTime,
						endTime:endTime,
						platform:platform
					},
					success:function(data){
						if(data){
							var arr=[];
							var hash={};
							var date=[];
							var index=0;
							for (var i = 0; i < data.length; i++) {
								var dataTime=getLocalTime(new Date(data[i].time));
								if(hash[dataTime]){
									var flog=true;
									for (var j = 0; j < hash[dataTime].length; j++) {
										if (hash[dataTime][j]==data[i].id){
											flog=false;
											break;
										}
									}
									if(flog){
										hash[dataTime].push(data[i].id);
									}
								}else{
									hash[dataTime]=[];
									hash[dataTime].push(data[i].id);
								}
							}

							for (var t = startTime; t < endTime; t+=86400000) {
								var times=getLocalTime(new Date(t));
									date[index]=times;
									index++;

							}
							for (var i = 0; i < date.length; i++) {
								arr[i]=new Array();
								if(hash[date[i]]){
									arr[i][0]="";
									arr[i][1]=hash[date[i]].length;
								}else{
									arr[i][0]="";
									arr[i][1]=0;
								}
							}
							// for(var atr in hash){
							// 	arr[j]=new Array();
							// 	arr[j][0]="";
							// 	arr[j][1]=hash[atr];
							// 	date[j]=atr;
							// 	j++;
							// }

							if(arr.length<=10){
								for (var i = 0; i < arr.length; i++) {
									arr[i][0]=date[i];
								}
							}else{
								arr[0][0]=date[0];
								arr[arr.length-1][0]=date[arr.length-1];
							}
							var logTable = new JSChart('graph', 'line');
							logTable.setDataArray(arr);
							logTable.setTitle('Online role statistics');
							logTable.setTitleColor('#8E8E8E');
							logTable.setTitleFontSize(18);
							logTable.setAxisNameX('Time');
							logTable.setAxisNameY('Online Number');
							logTable.setAxisNameColor('#8E8E8E')
							logTable.setAxisColor('#000');
							logTable.setAxisValuesColor('#f00');
							logTable.setAxisPaddingLeft(60);
							logTable.setAxisPaddingRight(80);
							logTable.setAxisPaddingTop(60);
							logTable.setAxisPaddingBottom(60);
							logTable.setAxisValuesDecimals(0);
							logTable.setAxisValuesNumberX(20);//x轴点的距离
							logTable.setShowXValues(false);
							logTable.setGridColor('#C5A2DE');
							logTable.setLineColor('#9D12FD');//线的颜色
							logTable.setLineWidth(2);
							logTable.setFlagColor('#9D12FD');//圈的颜色
							logTable.setFlagRadius(0.5);
							// logTable.setLabelRotationAngle(20);
							logTable.setTooltipOffset(5)
							for (var i = 0; i < arr.length; i++) {
								logTable.setTooltip([arr[i][0],date[i]+" 在线 "+arr[i][1]+" 人"]);
							}
							logTable.setSize(1100, 700);



							logTable.draw();



						}
					}
				})
			}
		})

		function toTwo(num){
        	return num<10?"0"+num:num;
    		}
		function getLocalTime(date) {     
       			return date.getFullYear()+"-"+toTwo(date.getMonth()+1)+"-"+toTwo(date.getDate());     
    		}


	// var myData = new Array([1997, 7.80], [1998, 4.80], [1999, 6.50], [2000, 6.10], [2001, 4.40], [2002, 5.80], [2003, 4.00], [2004, 8.50], [2005, 8.90], [2006, 9.20]);
	// var myChart = new JSChart('graph', 'line');
	// myChart.setDataArray(myData);
	// myChart.setTitle('Online role statistics');
	// myChart.setTitleColor('#8E8E8E');
	// myChart.setTitleFontSize(18);
	// myChart.setAxisNameX('');
	// myChart.setAxisNameY('');
	// myChart.setAxisColor('#8420CA');
	// myChart.setAxisValuesColor('#f00');
	// myChart.setAxisPaddingLeft(100);
	// myChart.setAxisPaddingRight(120);
	// myChart.setAxisPaddingTop(50);
	// myChart.setAxisPaddingBottom(40);
	// myChart.setAxisValuesDecimals(0);
	// myChart.setAxisValuesNumberX(10);//x轴点的距离
	// myChart.setShowXValues(false);
	// myChart.setGridColor('#C5A2DE');
	// myChart.setLineColor('#BBBBBB');//线的颜色
	// myChart.setLineWidth(2);
	// myChart.setFlagColor('#9D12FD');//圈的颜色
	// myChart.setFlagRadius(3);
	// myChart.setTooltip([1997, 'GDP 7.80']);
	// myChart.setTooltip([1998, 'GDP 4.80']);
	// myChart.setTooltip([1999, 'GDP 6.50']);
	// myChart.setTooltip([2000, 'GDP 6.10']);
	// myChart.setTooltip([2001, 'GDP 4.40']);
	// myChart.setTooltip([2002, 'GDP 5.80']);
	// myChart.setTooltip([2003, 'GDP 4.00']);
	// myChart.setTooltip([2004, 'GDP 8.50']);
	// myChart.setTooltip([2005, 'GDP 8.90']);
	// myChart.setTooltip([2006, 'GDP 9.20']);
	// // myChart.setLabelX([1997, '1997']);
	// // myChart.setLabelX([1998, '1998']);
	// // myChart.setLabelX([1999, '1999']);
	// // myChart.setLabelX([2000, '2000']);
	// // myChart.setLabelX([2001, '2001']);
	// // myChart.setLabelX([2002, '2002']);
	// // myChart.setLabelX([2003, '2003']);
	// // myChart.setLabelX([2004, '2004']);
	// // myChart.setLabelX([2005, '2005']);
	// // myChart.setLabelX([2006, '2006']);
	// myChart.setSize(900, 600);
	// // myChart.setBackgroundImage('/images/chart_bg.jpg');
	// myChart.draw();
	})()
})