$(document).ready(function(){
	var oFlash=$("#videoBox");
	var body=$("body");
	var oShip1=$(".banner_bg .ban_ship .ship1_bg");
	var oClose=$("#videogame .close")
	oShip1.click(function(){
		oFlash.css("display","block");
		body.addClass("overflowhide");
	})
	oClose.click(function(){
		oFlash.css("display","none");
		body.removeClass("overflowhide");

	});
	autoWidth();
	$(window).resize(function () {         
  		autoWidth();
});
	function autoWidth(){
		var w=$(window).width(),
    		h=0.64*w;
    	if(w<599){
    	$("#Mobile").css("width",w+"px");
    	}
	}
	// mflash();
	// function mflash(){
	// 		var video=$("#mContainer .videoBox .video"),
	// 			btn=$("#mContainer .videoBox .btn");
	// 	btn.click(function(){
	// 		video.css("display","block");
	// 		btn.css("display","none");
	// 	});
	// }

	
	var mess,pcmess;
	function attach_youku($message){
		mess=$(".mvideo").html();
		pcmess=$(".ship1").html();
	    $pattern = "/\[media\](.*?)\[\/media\]/ies";
	    if(strpos($message, '[/media]') !== FALSE) {
	        preg_match($pattern,$message,$matches,PREG_OFFSET_CAPTURE);
	        if($matches){
	            preg_match("/\/sid\/(.*)\/v.swf/i",$matches[0][0],$urlMatches);
	            if($urlMatches){
	                $embed = "<iframe height='100%' width='100%' src='http://player.youku.com/embed/{$urlMatches[1]}' frameborder=0 'allowfullscreen'></iframe>";
	                $message = substr($message,0,$matches[0][1]) .$embed. substr($message,$matches[0][1]+strlen($matches[0][0]));
	            }
	        }
	        return attach_youku($message);
	    }else{
	        return $message;
	    }
	}
	attach_youku(mess);
	attach_youku(pcmess);
});
