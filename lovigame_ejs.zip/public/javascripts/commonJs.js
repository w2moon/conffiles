$(document).ready(function(){
	// btn-nav点击效果
	$(function(){
		var oNavbar=$(".navbar"),
			oBtn=$(".mzTop .btn-nav"),
			oli=$(".mzTop .btn-nav i"),
			hid=$("#hid"),
			ifshow=false;
		oBtn.click(function(){
			if (ifshow) {
				oli.eq(1).show();
				hid.show();
				oBtn.removeClass("close");
				oNavbar.removeClass("nav-show");
				oNavbar.addClass("nav-hide");
				ifshow=!ifshow;
			}else{
				oli.eq(1).hide();
				hid.hide();
				oBtn.addClass("close");
				oNavbar.removeClass("nav-hide");
				oNavbar.addClass("nav-show");
				ifshow=!ifshow;
			}
			
		})
	})
	// 点击返回顶部效果
	$(function(){
		var oBacktop=$("#mzFoot a.backtop");
		oBacktop.click(function(){
			$("html,body").animate({
				scrollTop:0
			},400);
			return false;
		})
	})
	
})