$(document).ready(function(){
	(function(){
		var emails=$("#emails");
		var keys=$("#keys");
		var sendemail=$("#addresserMess .inputBox .email");
		var accreditCode=$("#addresserMess .inputBox .code");
		var eTitle=$("#addresserMess .inputBox .eTitle");
		var eContent=$("#addresserMess .inputBox .eContent");
		var btn9=$("#btn9");
		var upload=$("#filePath");
		var btn7=$("#grantCode .topBox .btn7");
		btn7.click(function(){
			var filepath='./emailMould/example.xlsx';
			var name='example.xlsx'
			$.ajax({
    				type: 'GET',
				    url: '/downModule',
				    // data: 'filepath='+filepath+'&name='+name,
				    success:function(){
				    	window.open("/downModule");
				    	

				    }
    			})
		});
		upload.click(function(){
			var time=setInterval(function(){
				var filename = $("#filePath").val();
				if (filename!="") {
					alert("上传成功");
					$("#fileName").html(getFileName(filename));
					clearInterval(time);
				}
			},50)
			
			
		})
		function getFileName(path){
			var pos1 = path.lastIndexOf('/');
			var pos2 = path.lastIndexOf('\\');
			var pos  = Math.max(pos1, pos2)
			if( pos<0 ){
				return path;
			}else{
				return path.substring(pos+1);
			}
			
		}
		btn9.click(function(){
			emails=emails.val();
			keys=keys.val();
			sendemail=sendemail.val();
			accreditCode=accreditCode.val();
			eTitle=eTitle.val();
			eContent=eContent.val();
			if (emails!="" && keys!="" && sendemail!="" && accreditCode!="") {
				var emailsArr=emails.split('\n');
				var keysArr=keys.split("\n");
				var length=emailsArr.length;
				var email,key;
				if (length!=keysArr.length) {
					alert("邮箱和兑换码数量不对应");
				} else {
					for (var i = 0; i <length; i++) {
						email=emailsArr[i];
						key=keysArr[i];
						sendEmail(email,key,sendemail,accreditCode,eTitle,eContent);
					}
					
				}
			}else{
				readExcel();

			}
			


		});

		 function readExcel(){
		    // var oXL = new ActiveXObject("Excel.Application");
		     try {
		          var oXL = new ActiveXObject("Excel.Application");
		        }
		        catch(e) {
		          alert( "要打印该表，您必须安装Excel电子表格软件，同时浏览器须使用“ActiveX 控件”，您的浏览器须允许执行控件。请点击【帮助】了解浏览器设置方法！");
		            return "";
		        }
			 try{
			    var path = document.getElementById("filePath");
			    var oWB = oXL.Workbooks.open(path.value);
			 }catch(e){
			  alert('打开文件失败！');
			 }
			    var oSheet = oWB.ActiveSheet;
			    var nRows=oSheet.usedrange.rows.count;
			    var nColumns =oSheet.usedrange.columns.count;
			    for(var i=1;i<nRows;i++)
			    {
		           var emai=oSheet.Cells(i+1,1).value;
		           var code=oSheet.Cells(i+1,2).value;
		           if (emai!="" && code !="") {
		           	sendEmail(emai,code);
		           } else {
		           	alert("邮箱和兑换码数量不对应");
		           }
		           
			    }
			 oSheet=null;
			 oWB.close();
			 oXL=null;
		}

		function sendEmail(email,key){
			$.ajax({
				type:'POST',
				url:'/grantCode',
				data: 'email='+email+'&key='+key+'&sendemail='+sendemail+'&accreditCode='+accreditCode+'&eTitle='+eTitle+'&eContent='+eContent,
				success:function(data){
					if (data) {
						alert("发送成功");
					} else {
						alert("发送失败");
					}
				}
			});
		}


		$("#emailSubmit").click(function(){
			var emailVal=$("#addresserMess .email").val(),
				codeVal=$("#addresserMess .code").val(),
				eTitleVal=$("#addresserMess .eTitle").val(),
				eContentVal=$("#addresserMess .eContent").val();
			var inputs=$("#addresserMess input");
			var textarea=$("#addresserMess textarea");
			// var emailTitle=$("#showMess .emailTitle"),
			// 	sendPerson=$("#showMess .sendPerson"),
			// 	content=$("#showMess .content");
				// emailTitle.html(eTitleVal);
				// sendPerson.html(emailVal);
				// content.html(eContentVal);
				if (emailVal=="") {
					alert("请输入发件人邮箱");
				} else if(codeVal==""){
					alert("请输入授权码");
				}else{
					inputs.css({"border":"1px solid #999","color":"#999"});
					inputs.attr("onfocus","this.blur()");
					textarea.css({"border":"1px solid #999","color":"#999"});
					textarea.attr("onfocus","this.blur()");
				}

		});
		$("#revise").click(function(){
			var inputs=$("#addresserMess input");
			var textarea=$("#addresserMess textarea");
			inputs.css({"border":"1px solid #000","color":"#000"});
			textarea.css({"border":"1px solid #000","color":"#000"});
			inputs.attr("onfocus","");
			textarea.attr("onfocus","");

		});

	})()
})