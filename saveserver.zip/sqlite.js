var util = require('util'); 
var sqlite3 = require('sqlite3');
var path = require('path');
var cdb=require('./db');
var fs = require('fs');
var crypto = require('crypto');

exports.connectA = function(name,filepath,obj,callback){
    if (!fs.existsSync(path.resolve(__dirname,"upload"))) {
        fs.mkdirSync(path.resolve(__dirname,"upload"));
    }
    var filename = path.resolve(__dirname,"upload/"+name);
    var db = new sqlite3.Database(filepath, sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE,
        function(err){
            if (err){
                util.log('FAIL on creating database' + err);
                return;
            } else {
                db.all("select value from data where key='_wl'",function(err,res){
                    if(!err && res[0]){
                        db.close();
                        connectB(filename,obj,res[0].value,function(result){
                            if(result){
                                callback(true);
                            }else{
                                callback(true);
                            }
                        });
                        
                    }else{
                        db.close();
                        console.log(err);
                        callback(false);
                        return;
                    }
                });  


                   
            }
     });
}




function connectB(filepath,obj,val,cb) {
    console.log("filepath",filepath);
    console.log("val",val);
    var db = new sqlite3.Database(filepath, sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE,
        function(err){
            if (err){
                util.log('FAIL on creating database' + err);
            } else {
                db.run("UPDATE data SET value = '"+val+"' WHERE key = '_wl'",function(err){
                    if(!err){
                        db.close(function(){
                            fs.readFile(filepath,function(err, buffer) {
                                if(err) {
                                    console("readFile");
                                    console.error(err);
                                    cb(false);
                                } else {
                                    replaceMess(obj,buffer,function(result){
                                        if (result) {
                                            cb(true);
                                        }else{
                                            cb(false);
                                        }
                                    });
                                }
                            });
                        });
                    }else{
                        db.close();
                        console.log(err);
                        cb(false);
                        return;
                    }
                });  
            
        }
     });
}

function replaceMess(obj,buffer,cb) {
    console.log("replaceMess")
    var md5sum = crypto.createHash('md5');
    md5sum.update(buffer);
    var md5 = md5sum.digest('hex');
    var time=new Date().getTime();
    var strver=obj.strver;
    var strverObj = JSON.parse(strver);

    strverObj.version=time;
    strverObj.assets["data.sav"]["md5"]=md5;
    var newStrver = JSON.stringify(strverObj);

    cdb.upDate(obj,buffer,newStrver,function(result){
        if (result) {
            console.log("修改成功");
            cb(true);
        }else{
            console.log("修改失败");
            cb(false);
        }
    });
}

exports.findData = function(obj,callback) {
    cdb.seqencing(obj,-1,function(data){
        if (data) {
            if (!fs.existsSync(path.resolve(__dirname,"temp"))) {
                fs.mkdirSync(path.resolve(__dirname,"temp"));
            }
            var filename = path.resolve(__dirname,"temp/"+data[0].userId+"_"+data[0].date+".sav");

            fs.writeFileSync(filename,data[0].buffer.buffer);
            callback(filename,data[0]);
        }else{
            callback(false,false);
        }
    });
}

exports.bfMess = function(obj,callback) {
    cdb.seqencing(obj,-1,function(data){
        if (data) {
            var filename = data[0].userId+"_"+data[0].date+".sav";
            callback(filename,data[0]);
        }else{
            callback(false,false);
        }
    });
}

