var mongodb = require('mongodb');
var server = new mongodb.Server('localhost',27017,{auto_reconnect:true});
var db = new mongodb.Db('freshbody_demo',server,{safe:true});


// db.open(function(err,db){
//     if(err){
//         console.log(err);
//         return;
//     }
//     console.log("inited");
  
// });


exports.init = function(cb){
    db.open(function(err,db){
        if(err){
            console.log(err);
            cb(err);
            return;
        }
        console.log("inited");
        cb(true);
      
    });
}


exports.saveBufferVer = function (obj,cb) {
    db.collection('bufferVer', { safe: true }, function (err, collection) {
        if (err) {
            console.log(err);
            cb(false);
            return;
        }
        collection.insert(obj, { safe: true }, function (err, result) {
            if (err) {
                console.log(err);
                cb(false);
            }
            else {
                console.log("inserted");
                cb(true);
            }
        })
    });
};

exports.findMess = function (obj,cb) {
    db.collection('bufferVer', { safe: true }, function (err, collection) {
        if (err) {
            console.log(err);
            cb(false);
            return;
        }
        collection.find(obj).toArray(function(err, docs) {
            // console.log(docs);
            cb(docs);
        });
    });
};

exports.delCampaign = function(obj,cb){
    db.collection('bufferVer',{safe:true},function(err,cams){
        cams.deleteOne(obj,function(err,data){
            if(err){
                cb(false);
                return;
            }
            if(!data){
               cb(true);
            }
            else{
                 cb(true);
            }

        });
    })
};

//删除多个数据
exports.delList = function(obj,cb){
    db.collection('bufferVer', { safe: true }, function (err, collection) {
        if (err) {
            console.log(err);
            cb(false);
            return;
        }
        var fdata = collection.find({userId:obj.userId});
            var data = fdata.sort({date:-1}).skip(obj.num);
            data.forEach(d=>{
                collection.remove(d);
            });
            cb(true);
            

    });

    
};



//排序
exports.seqencing = function(obj,n,cb){
    db.collection('bufferVer', { safe: true }, function (err, collection) {
        if (err) {
            console.log(err);
            cb(null);
            return;
        }
      var fdata=collection.find(obj); 
        fdata.sort({date:n}).toArray(function(err, docs) {
            if (docs.length==0) {
                cb(null);
            }else{
                cb(docs);

            }
        });
        

    });

};


exports.upDate = function (obj,buffer,newStrver,cb) {
    db.collection('bufferVer', { safe: true }, function (err, collection) {
        if (err) {
            console.log(err);
            cb(false);
            return;
        }
        collection.update({userId:obj.userId,date:obj.date},{$set:{buffer:buffer,strver:newStrver}},{},function(err){
            if(err){
            console.log(err);
            cb(false);
            }else{


            cb(true);
            }
        });
        
    });

}


exports.deleteList = function(data,cb){
    db.collection('bufferVer', { safe: true }, function (err, collection) {
        if (err) {
            console.log(err);
            cb(false);
            return;
        }
            data.forEach(d=>{
                collection.remove(d);
            });
            cb(true);

    });

    
};