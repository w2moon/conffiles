var express = require('express');
var app = express();
var http = require('http');
var fs = require('fs');
var multer = require('multer');
var upload = multer({storage:multer.memoryStorage()});
var path = require('path');
var dataPath = path.resolve("data")+"/";
var crypto = require('crypto');
var mkdirp = require('mkdirp');
var PORT = 8888;
var MY_URL = "http://www.lovigame.com:"+PORT;
var saveManager=require('./SaveManager');
var num=7;
var cdb=require('./db');
var fileup = require('./fileuploads');
var sqlite = require('./sqlite');
cdb.init(function(result){});

var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({extended: true}))

app.use(express.static(path.join(__dirname, 'public')));
app.get('/sav',function(req,res){
    var userId = req.query.userId;
    saveManager.findSav({userId:userId},function(data){
        if (data) {

           
            res.send(data.buffer);
        }else{
            res.send("");
        }
        
    });
    
});


app.post('/sav',upload.single('data.sav'),function(req,res){
    var userId = req.query.userId;
    var reqmd5 = req.query.md5;
    var buffer=req.file.buffer;
    // var userName = req.query.userName;
    var userName="jian"
    var currFilePath = dataPath+userId+"/data.sav";
    var md5sum = crypto.createHash('md5');
    md5sum.update(buffer);
    var md5 = md5sum.digest('hex');
    if(reqmd5 !== md5){
        console.log("md5 error");
        res.send("");
        return;
    }
    var ver = saveManager.createVersionFile(userId,md5,MY_URL);
    var strver = JSON.stringify(ver);
    var time=new Date().getTime();
    var timeStamp = new Date(new Date().setHours(0, 0, 0, 0)).getTime();
    var mess={
        userId:userId,
        num:num,
        md5:md5,
        timeStamp:timeStamp,
        obj:{
            userId:userId,
            userName:userName,
            buffer:buffer,
            strver:strver,
            date:time
        }

    }

    saveManager.addMessage(mess,function(result,flog,md5){
        if (result) {
            res.send(result);
        }else{
            res.send("");
        }
    });




});

app.get('/ver',function(req,res){
    var userId = req.query.userId;
    saveManager.findVer({userId:userId},function(data){
        if (data) {
            res.send(data);
        }else{
            // var ver = saveManager.createVersionFile(userId,0,MY_URL);
            // res.send(ver);
            res.send("");
        }
        
    });
});

app.post('/find',function(req,res){
    var userName = req.body.userName;
    cdb.seqencing({userName:userName},1,function(data){
        if (data) {
            res.send(data);
        }else{
            res.send("");
        }
    })
    
    
});

app.get('/downfile',function(req,res){
    var userName = req.query.userName;
    var name=parseInt(req.query.name);
    cdb.findMess({userName:userName,date:name},function(data) {
        console.log("downfile_data",data);
        var times=new Date(data[0].date);
        var fileNameSav=userName+"_"+formatDate(times)+'.sav';
        if (data) {
            downSav(data[0].buffer.buffer,fileNameSav);
        } else {
            console.log("result not found");
            res.end();
        }

    })
    function downSav(savBuffer,fileName) {
        res.set({
            "Content-type":"application/octet-stream",
            "Content-Disposition":"attachment;filename="+encodeURI(fileName)
        });
        res.write(savBuffer);
        res.end();
    }
    function   formatDate(now)   {     
        var  year=now.getFullYear();
        var  month=now.getMonth()+1;     
        var  date=now.getDate();     
        var  hour=now.getHours();     
        var  minute=now.getMinutes();     
        var  second=now.getSeconds();     
        return   year+""+toTwo(month)+""+toTwo(date)+""+toTwo(hour)+""+toTwo(minute)+""+toTwo(second);     
      }
      
      function toTwo(time) {
          return time<10?("0"+time):time;
      }
});

app.post('/upload', fileup.single('buffer'), function (req, res, next) {
    var userName=req.body.userName;
    sqlite.findData({userName:userName},function(data,obj){
        if (data) {
            if (req.file) {
                var name=req.file.originalname;
                sqlite.connectA(name,data,obj,function(result) {
                    if (result) {
                        res.send("修改成功");
                    }else{
                        res.send("修改失败");
                        return;
                    }
                });
            }else{
                res.send("文件上传失败");
                return;
            }
        }else{
            res.send("用户名未找到");
            return;
        }
    });

   
    
});

app.get('/backups',function (req, res, next) {
    var userName=req.query.userName;
    sqlite.bfMess({userName:userName},function(fileName,data){
        if (data) {
            console.log(data);
            var bufferBackups=data.buffer.buffer;
            backup(bufferBackups,fileName);
        }else{
            console.log("数据没找到");
            res.send("数据未找到");
        }
    });
    
    function backup(savBuffer,fileName) {
        res.set({
            "Content-type":"application/octet-stream",
            "Content-Disposition":"attachment;filename="+encodeURI(fileName)
        });
        res.write(savBuffer);
        res.end();
    }

});

http.createServer(app).listen(PORT,function(){
    console.log("server started");
});


