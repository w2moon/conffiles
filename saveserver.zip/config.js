module.exports = {
    upload: {
        path: process.cwd() + '/upload'
    }
}