var multer = require('multer');
var config = require('./config')

var storage = multer.diskStorage({
    destination: config.upload.path,
    filename: function (req, file, cb) {
        var fileFormat =file.originalname;
        cb(null,fileFormat);
    }
});

var upload = multer({
    storage: storage,
});
module.exports = upload;