var cdb=require('./db');
var crypto = require('crypto');

exports.createVersionFile=function(sysUserId,md5,url){
    var obj = {
        packageUrl:url+"/sav?userId="+sysUserId,
        remoteManifestUrl:url+"/ver?userId="+sysUserId,
        remoteVersionUrl:url+"/ver?userId="+sysUserId,
        version:new Date().getTime().toString(),
        engineVersion:"1.0",
        assets:{
            "data.sav":{

                md5:md5
            }
        },
        searchPaths:[]
    };
    return obj;
};

    exports.findSav = function (obj,cb) {
        var length=0;
        cdb.seqencing(obj,-1,function(data){
            if (data!==null) {
                length=data.length;
            }
            if (length>0) {
                cb(data[0].buffer);
            } else {
                cb(false);
            }
            
            
        });

    }
    exports.findVer = function (obj,cb) {
        var length=0;
        cdb.seqencing(obj,-1,function(data){
            if (data!==null) {
                length=data.length;
            }
            if (length>0) {
                cb(data[0].strver);
            } else {
                cb(null);
            }
            
        });

    }
    exports.addMessage = function (mess,cb) {
        var userId=mess.userId;
        var obj=mess.obj;
        var md5=mess.md5;
        var num=mess.num;
        var timeStamp=mess.timeStamp;
        var time=mess.obj.date;
        insertBufferVer(obj,function(result){
            if(result){
                deleteSameDay(userId,time,timeStamp,function(flog){
                    if (flog) {
                        outNum({userId:userId},num,function(del){
                            if (del) {
                                cb(mess.obj.strver);
                            }else{
                                cb(false);
                            }
                        })
                    }else{
                        cb(false);
                    }
                })
            }else{
                cb(false);
            }
        });


    }


    //删除同一天的数据
    function deleteSameDay(userId,time,timeStamp,cb){
        var recentTime;
        var difTime=time-timeStamp;
        var deleteLis=[];
        cdb.seqencing({userId:userId},-1,function(result){
            if (result.length>1) {
                for (var i = 1; i < result.length; i++) {
                    recentTime=time-result[i].date;
                    if (recentTime<difTime) {
                        deleteLis.push(result[i]);
                    }
                }
                cdb.deleteList(deleteLis,function(del){
                    if (del) {
                        cb(true)
                    }else{
                        cb(false);
                    }
                });


            }else{
                cb(true);
            }
            
        });

};

    //插入数据
    function insertBufferVer(obj,cb){
        cdb.saveBufferVer(obj,function(result){
            if (result) {
                console.log("insert success");
                cb(true);
            }else{
                cb(false);
                console.log('insert error');
            }
            
        })
};

//判断玩家数据的总数大于num的则删除
function outNum(obj,num,cb) {
    cdb.findMess(obj,function(result){
        var length=result.length;
        if (length>num) {
            cdb.delList({userId:obj.userId,num:num},function(result){
                if (result) {
                    console.log("delete success");
                    cb(true);
                }else{
                    console.log("delete fail");
                    cb(false);
                }
            });

        }else{
            console.log(length+"<"+num);
            cb(true);
        }
        
    })
}


